# XAI - AI Explainability Landing Page

This project is a recreation of the XAI landing page, adapted to focus on AI Explainability. It is built using **React** with **Vite** as the build tool, styled with **Material-UI (MUI)**, and uses **Redux Toolkit** for state management.

## Features

- **Modern Frontend Stack:** React + Vite for a fast and efficient development experience.
- **Material-UI (MUI):** Utilizes Google's Material Design principles for a consistent and accessible UI, with extensive customization via a custom theme.
- **Redux Toolkit:** For robust and predictable state management (though its full potential might be more visible in a larger application with more complex data flows).
- **Responsive Design:** Components are built with responsiveness in mind using MUI's `sx` prop and Grid system.
- **Modular Component Structure:** The landing page is broken down into reusable components for better organization and maintainability.
- **AI Explainability Focus:** Content adapted to highlight features relevant to AI explainability, understanding, and trust.

## Technologies Used

- **React.js:** A JavaScript library for building user interfaces.
- **Vite:** A fast build tool that provides a lightning-fast development experience.
- **Material-UI (MUI):** A comprehensive React UI library implementing Google's Material Design.
    - `@mui/material`
    - `@emotion/react`
    - `@emotion/styled`
    - `@mui/icons-material`
- **React Router DOM:** For declarative routing in a React application.
- **Redux Toolkit:** The official, opinionated, batteries-included toolset for efficient Redux development.
    - `react-redux`

## Project Structure

```properties
src/
├── App.jsx // Main component handling routing
├── index.jsx // Entry point, wraps App with ThemeProvider and Redux Provider
├── theme.js // Custom Material-UI theme definition
├── components/ // Reusable UI components for different sections
│ ├── Header.jsx
│ ├── HeroSection.jsx
│ ├── ContentPreviewSection.jsx
│ ├── StatsSection.jsx
│ ├── WhyAIFailsSection.jsx
│ ├── LLMEvaluationPlatformSection.jsx
│ ├── LLMEvalsSection.jsx
│ ├── UseCasesSection.jsx
│ ├── TestimonialsSection.jsx
│ └── Footer.jsx
├── pages/ // Page-level components
│ ├── LandingPage.jsx // The main landing page
│ ├── LoginPage.jsx
│ └── HomePage.jsx
├── store/ // Redux store configuration
│ └── store.js
└── assets/ // Static assets like images (logo, avatars)
├── evidently-ai-logo.svg
├── user-avatar-1.jpg
└── ...
```

## Getting Started

Follow these instructions to set up and run the project locally.

### Prerequisites

- Node.js (LTS version recommended)
- npm or Yarn package manager

### Installation

1.  **Clone the repository:**

    ```bash
    git clone [your-repo-url]
    cd [your-repo-name]
    ```

2.  **Install dependencies:**

    ```bash
    npm install
    # or
    yarn install
    ```

3.  **Install Material-UI specific dependencies:**

    ```bash
    npm install @mui/material @emotion/react @emotion/styled @mui/icons-material
    # or
    yarn add @mui/material @emotion/react @emotion/styled @mui/icons-material
    ```

4.  **Install React Router DOM and Redux Toolkit:**
    ```bash
    npm install react-router-dom @reduxjs/toolkit react-redux
    # or
    yarn add react-router-dom @reduxjs/toolkit react-redux
    ```

### Running the Development Server

To start the development server and view the project in your browser:

```bash
npm run dev
# or
yarn dev
```
