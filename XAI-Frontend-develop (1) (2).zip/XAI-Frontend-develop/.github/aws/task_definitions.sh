#!/bin/bash

# Enable better error handling
set -o pipefail

# Configuration
cluster=""
keep_count=10
region=""
dry_run=true
log_file="cleanup_ecs_task_defs.log"

# Initialize log file
echo "$(date): Starting ECS task definition cleanup script" > "$log_file"
echo "Cluster: $cluster, Region: $region, Keep count: $keep_count, Dry run: $dry_run" >> "$log_file"

# Function to log messages
log_message() {
  local message="$1"
  echo "$(date): $message" >> "$log_file"
  echo "$message"
}

# Function to handle errors
handle_error() {
  local exit_code=$?
  local command="$BASH_COMMAND"
  log_message "ERROR: Command '$command' failed with exit code $exit_code"
  log_message "Script execution will continue..."
}

# Set up error trap
trap 'handle_error' ERR

log_message "Analyzing task definitions for cluster: $cluster"
log_message "Dry run mode: $dry_run"

# Get task definitions used by services in the cluster
log_message "Checking which task definitions are used by services..."
used_task_defs=()

# Get services with error handling
services_output=$(aws ecs list-services --cluster $cluster --query 'serviceArns[]' --output text --region $region 2>> "$log_file")
if [ $? -ne 0 ]; then
  log_message "WARNING: Failed to list services in cluster $cluster"
  services=()
else
  # Convert output to array - handle empty output
  if [ -z "$services_output" ]; then
    services=()
  else
    # Split by whitespace
    services=($services_output)
  fi
fi

for service in "${services[@]}"; do
  service_name=$(basename $service)
  log_message "Checking service: $service_name"
  
  # Get task definition with error handling
  service_task_def_output=$(aws ecs describe-services --cluster $cluster --services $service --query 'services[].taskDefinition' --output text --region $region 2>> "$log_file")
  if [ $? -ne 0 ]; then
    log_message "WARNING: Failed to describe service $service_name"
    continue
  fi
  
  service_task_def=$service_task_def_output
  used_task_defs+=("$service_task_def")
  log_message "Service $service_name uses task definition: $(basename $service_task_def)"
done

# Check for running tasks using task definitions in the cluster
log_message "Checking for running tasks..."

# Get tasks with error handling
running_tasks_output=$(aws ecs list-tasks --cluster $cluster --query 'taskArns[]' --output text --region $region 2>> "$log_file")
if [ $? -ne 0 ]; then
  log_message "WARNING: Failed to list tasks in cluster $cluster"
  running_tasks=()
else
  # Convert output to array - handle empty output
  if [ -z "$running_tasks_output" ]; then
    running_tasks=()
  else
    # Split by whitespace
    running_tasks=($running_tasks_output)
  fi
fi

for task in "${running_tasks[@]}"; do
  task_name=$(basename $task)
  
  # Get task definition with error handling
  task_def_output=$(aws ecs describe-tasks --cluster $cluster --tasks $task --query 'tasks[].taskDefinitionArn' --output text --region $region 2>> "$log_file")
  if [ $? -ne 0 ]; then
    log_message "WARNING: Failed to describe task $task_name"
    continue
  fi
  
  task_def=$task_def_output
  used_task_defs+=("$task_def")
  log_message "Task $task_name uses task definition: $(basename $task_def)"
done

# Get unique task definition families used in this cluster
task_def_families=()
for task_def in "${used_task_defs[@]}"; do
  family=$(echo $task_def | cut -d'/' -f2 | cut -d':' -f1)
  if [[ ! " ${task_def_families[@]} " =~ " ${family} " ]]; then
    task_def_families+=("$family")
  fi
done

log_message "Found ${#task_def_families[@]} task definition families used in cluster $cluster"

# Process each family
for family in "${task_def_families[@]}"; do
  log_message "Processing family: $family"
  
  # Get all revisions for this family with error handling
  family_revisions_output=$(aws ecs list-task-definitions --family-prefix $family --sort DESC --status ACTIVE --query 'taskDefinitionArns[]' --output text --region $region 2>> "$log_file")
  if [ $? -ne 0 ]; then
    log_message "WARNING: Failed to list task definitions for family $family"
    continue
  fi
  
  # Convert output to array - handle empty output properly
  if [ -z "$family_revisions_output" ]; then
    family_revisions=()
  else
    # Split by whitespace (tab, newline, space)
    family_revisions=($family_revisions_output)
  fi
  
  total_revisions=${#family_revisions[@]}
  log_message "  Found $total_revisions revisions for family $family"
  
  # Initialize removal count for this family
  removal_count=0
  
  # Process each revision
  for i in "${!family_revisions[@]}"; do
    revision="${family_revisions[$i]}"
    is_used=false
    
    # Check if revision is used
    for used_task_def in "${used_task_defs[@]}"; do
      if [ "$revision" == "$used_task_def" ]; then
        is_used=true
        break
      fi
    done
    
    # Keep the most recent revisions and remove unused older ones
    if [ "$is_used" == false ] && [ "$i" -ge $keep_count ]; then
      task_def_name=$(basename $revision)
      log_message "  Unused revision (removing): $task_def_name"
      
      if [ "$dry_run" = false ]; then
        log_message "  Deregistering task definition: $task_def_name"
        
        # Deregister with error handling
        if ! aws ecs deregister-task-definition --task-definition $task_def_name --region $region >> "$log_file" 2>&1; then
          log_message "  ERROR: Failed to deregister task definition $task_def_name"
          continue
        fi
        
        log_message "  Waiting for task definition to become INACTIVE..."
        sleep 5  # Give AWS a moment to process the deregistration
        
        log_message "  Deleting task definition: $task_def_name"
        
        # Delete with error handling
        if ! aws ecs delete-task-definitions --task-definitions $task_def_name --region $region >> "$log_file" 2>&1; then
          log_message "  ERROR: Failed to delete task definition $task_def_name"
        fi
        
        # Add a small delay to avoid API rate limiting
        sleep 2
      fi
      
      # Increment removal count safely
      removal_count=$((removal_count + 1))
    elif [ "$is_used" == true ]; then
      log_message "  Revision in use (keeping): $(basename $revision)"
    else
      log_message "  Recent revision (keeping): $(basename $revision)"
    fi
  done
  
  log_message "  Summary for family $family: $removal_count revisions marked for removal out of $total_revisions total"
  
  # Add a delay between processing families to avoid API rate limiting
  sleep 1
done

if [ "$dry_run" = true ]; then
  log_message "Script completed in DRY RUN mode. No task definitions were actually deregistered or deleted."
  log_message "Set dry_run=false to perform actual deletions."
else
  log_message "Script completed. Task definitions were deregistered and deleted as indicated."
fi

log_message "See $log_file for detailed execution log."
