// Tab labels for the main dashboard
export const tabLabels = [
    'What if...',
    'Data drift',
    'Fairness',
    'Regression',
    'Classification',
    'Feature Importances',
    'Individual Predictions',
    'Feature Dependence',
    'Feature Interactions',
    'Decision Trees',
]

// Mock data for Titanic features and SHAP values (for Feature Importances)
export const MOCK_TITANIC_SHAP_DATA = [
    {
        feature: 'Sex',
        description: 'Gender of passenger (male/female)',
        importance: 0.28,
        type: 'Categorical',
    },
    {
        feature: 'PassengerClass',
        description: 'Ticket class (1st, 2nd, 3rd)',
        importance: 0.22,
        type: 'Categorical',
    },
    {
        feature: 'Age',
        description: 'Age in years',
        importance: 0.18,
        type: 'Numerical',
    },
    {
        feature: 'Fare',
        description: 'Passenger fare',
        importance: 0.15,
        type: 'Numerical',
    },
    {
        feature: 'Embarked',
        description: 'Port of embarkation (C, Q, S)',
        importance: 0.1,
        type: 'Categorical',
    },
    {
        feature: 'SibSp',
        description: 'Number of siblings/spouses aboard',
        importance: 0.07,
        type: 'Numerical',
    },
    {
        feature: 'Parch',
        description: 'Number of parents/children aboard',
        importance: 0.05,
        type: 'Numerical',
    },
    {
        feature: 'Deck',
        description: 'Deck level (A-G, T)',
        importance: 0.03,
        type: 'Categorical',
    },
].sort((a, b) => b.importance - a.importance) // Sort by importance descending

// UI Constants
export const drawerWidthOpen = 300
export const drawerWidthClosed = 60

// Asset paths
export const logoSrc = '/logo-nav.png' // Adjust path if using assets folder and import

// Default form values
export const DEFAULT_FORM_VALUES = {
    whatIfAge: 25,
    whatIfSex: 'female',
    whatIfClass: '3rd',
    selectedIndividual: 'Passenger 1234',
    dependencyFeature: 'Age',
    interactionFeature1: 'Sex',
    interactionFeature2: 'PassengerClass',
    importanceType: 'SHAP values',
    depth: 'All',
    percentage: 70,
    modelFormat: 'pkl',
}
