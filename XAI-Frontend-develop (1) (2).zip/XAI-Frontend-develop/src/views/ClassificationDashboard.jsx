import React, { useState, useEffect } from 'react'
import {
    Container,
    Typography,
    Box,
    Button,
    Paper,
    Stack,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
} from '@mui/material'
import { Dashboard, Launch, InfoOutline } from '@mui/icons-material'
import { useSelector, useDispatch } from 'react-redux'
import SummaryLoaderPlaceholder from '../components/SummaryLoaderPlaceholder'
import ReactMarkdown from 'react-markdown'

const ClassificationDashboard = ({
    setOpenSideBar,
    selectedProject,
    setSelectedProject,
    selectedTargetColumn,
    setSelectedTargetColumn,
}) => {
    const dispatch = useDispatch()
    const { token, user } = useSelector((state) => state?.auth)
    const {
        classificationReport,
        classificationAnalysis,
        // classificationDashboard,
        loading,
        columns,
    } = useSelector((state) => state.classification)
    const { datasets } = useSelector((state) => state.fairness)

    const [htmlBlobUrl, setHtmlBlobUrl] = useState(null)
    const [dashboardUrl, setDashboardUrl] = useState(null)

    // Add target column selection handler
    const handleTargetColumnChange = (event) => {
        setSelectedTargetColumn(event.target.value)
    }
    console.log(classificationReport)
    useEffect(() => {
        if (classificationReport) {
            const blob = new Blob([classificationReport?.html], {
                type: 'text/html',
            })
            const url = URL.createObjectURL(blob)
            setHtmlBlobUrl(url)
            return () => URL.revokeObjectURL(url)
        }
    }, [classificationReport])

    if (loading) return <SummaryLoaderPlaceholder />

    // If we have an HTML report, show it in iframe
    if (htmlBlobUrl) {
        return (
            <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
                <Box sx={{ mb: 4 }}>
                    <Typography
                        variant="h4"
                        sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                    >
                        Classification Report
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Detailed classification model performance report
                    </Typography>
                </Box>
                <iframe
                    src={htmlBlobUrl}
                    title="Classification Report"
                    style={{
                        width: '100%',
                        height: '100vh',
                        border: 'none',
                    }}
                />
            </Container>
        )
    }
    console.log('Classification Analysis:', classificationAnalysis)
    if (!classificationAnalysis) {
        return (
            <Container
                maxWidth="xl"
                sx={{
                    mt: 4,
                    mb: 4,
                    fontFamily: 'Inter, sans-serif',
                    '& .MuiPaper-root': {
                        boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
                    },
                }}
            >
                {/* Page Header */}
                <Box sx={{ mb: 4 }}>
                    <Typography
                        variant="h4"
                        sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                    >
                        AI classification Analysis Platform
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Analyze classification model performance across various
                        demographic segments to detect disparities in accuracy,
                        precision, recall, and other key metrics—helping
                        identify and mitigate potential algorithmic bias.{' '}
                        <Button
                            // onClick={() => setShowDescription(true)}
                            variant="text"
                            color="primary.dark"
                            sx={{ fontSize: '1rem', padding: 0 }}
                        >
                            Learn More
                            <InfoOutline
                                sx={{
                                    fontSize: '1rem',
                                    ml: '4px',
                                }}
                            />
                        </Button>
                    </Typography>
                </Box>
                <Box>
                    {datasets && datasets?.classification?.files?.length > 0 ? (
                        <Box
                            sx={{
                                mt: 2,
                                display: 'flex',
                                flexDirection: 'column',
                                overflowX: 'auto',
                                gap: 2,
                                pb: 1,
                                width: '100%',
                            }}
                        >
                            <Typography>Files</Typography>
                            {datasets?.classification?.files?.map(
                                (project, i) => (
                                    <Paper
                                        key={i}
                                        elevation={1}
                                        sx={{
                                            minWidth: 300,
                                            px: 3,
                                            py: 2,
                                            borderRadius: 2,
                                            display: 'flex',
                                            flexDirection: 'row',
                                            alignItems: 'center',
                                            justifyContent: 'space-between',
                                            border: '1px solid #e0e0e0',
                                            position: 'relative',
                                        }}
                                    >
                                        <Box
                                            sx={{
                                                display: 'flex',
                                                alignItems: 'center',
                                                gap: 1,
                                            }}
                                        >
                                            <Dashboard
                                                sx={{
                                                    color: 'green',
                                                    fontSize: '1.6rem',
                                                }}
                                            />
                                            <Typography
                                                variant="subtitle1"
                                                fontWeight={600}
                                            >
                                                {project.file_name}
                                            </Typography>
                                        </Box>

                                        <Box
                                            sx={{
                                                display: 'flex',
                                                justifyContent: 'flex-end',
                                                gap: 1,
                                            }}
                                        >
                                            <Button
                                                variant="outlined"
                                                // onClick={() =>
                                                //     startAnalysisHandler(project)
                                                // }
                                                disabled
                                                sx={{ color: 'primary.dark' }}
                                            >
                                                View Details
                                                <Launch fontSize="small" />
                                            </Button>
                                        </Box>
                                    </Paper>
                                )
                            )}
                        </Box>
                    ) : (
                        <Box
                            sx={{
                                border: '1px dashed #ccc',
                                borderRadius: 2,
                                p: 4,
                                mt: 4,
                                textAlign: 'center',
                                backgroundColor: '#fafafa',
                            }}
                        >
                            <Typography
                                variant="subtitle1"
                                fontWeight={500}
                                gutterBottom
                            >
                                No Past Analysis Found
                            </Typography>
                            <Typography
                                variant="body2"
                                color="text.secondary"
                                sx={{ maxWidth: 500, margin: '0 auto' }}
                            >
                                You haven’t created any drift monitoring
                                projects yet. Create one to begin analyzing
                                model stability over time.
                            </Typography>
                            <Button
                                variant="contained"
                                sx={{ mt: 3 }}
                                onClick={() => setOpenSideBar(true)}
                            >
                                Create Analysis
                            </Button>
                        </Box>
                    )}
                </Box>
            </Container>
        )
    } // If we have a dashboard URL, show it in iframe
    if (classificationAnalysis?.dashboard_url) {
        return (
            <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
                {renderTargetColumnSelector()}
                <Box sx={{ mb: 4 }}>
                    <Typography
                        variant="h4"
                        sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                    >
                        Classification Dashboard
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Interactive classification analysis dashboard
                    </Typography>
                </Box>
                <iframe
                    src={classificationAnalysis.dashboard_url}
                    title="Classification Dashboard"
                    style={{
                        width: '100%',
                        height: '100vh',
                        border: 'none',
                    }}
                />
            </Container>
        )
    }
    // Default state - no analysis yet
    return (
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
            {/* Target Column Selector */}
            {datasets?.classification?.files?.length > 0 &&
                renderTargetColumnSelector()}

            {/* Page Header */}
            <Box sx={{ mb: 4 }}>
                <Typography
                    variant="h4"
                    sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                >
                    AI Classification Analysis Platform
                </Typography>
                <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                    Evaluate classification model performance, generate reports,
                    and analyze predictions.
                </Typography>
            </Box>

            <Box>
                {datasets && datasets?.classification?.files?.length > 0 ? (
                    <Box
                        sx={{
                            mt: 2,
                            display: 'flex',
                            flexDirection: 'column',
                            gap: 2,
                        }}
                    >
                        <Typography variant="h6">Available Datasets</Typography>
                        {datasets.classification.files.map((project, i) => (
                            <Paper
                                key={i}
                                elevation={1}
                                sx={{
                                    p: 2,
                                    borderRadius: 2,
                                    display: 'flex',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 2,
                                    }}
                                >
                                    <Dashboard color="primary" />
                                    <Typography variant="subtitle1">
                                        {project.file_name}
                                    </Typography>
                                </Box>
                                <Button
                                    variant="contained"
                                    onClick={() => setSelectedProject(project)}
                                    startIcon={<Launch />}
                                >
                                    Analyze
                                </Button>
                            </Paper>
                        ))}
                    </Box>
                ) : (
                    <Box
                        sx={{
                            border: '1px dashed #ccc',
                            borderRadius: 2,
                            p: 4,
                            textAlign: 'center',
                        }}
                    >
                        <Typography variant="h6" gutterBottom>
                            No Classification Datasets
                        </Typography>
                        <Typography color="text.secondary" sx={{ mb: 2 }}>
                            Upload your classification dataset to begin analysis
                        </Typography>
                        <Button
                            variant="contained"
                            onClick={() => setOpenSideBar(true)}
                        >
                            Upload Dataset
                        </Button>
                    </Box>
                )}
            </Box>
        </Container>
    )
}

export default ClassificationDashboard
