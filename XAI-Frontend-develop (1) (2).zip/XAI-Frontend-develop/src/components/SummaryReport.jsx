import React, { useEffect, useState } from 'react'
import ReactMarkdown from 'react-markdown'
import SummaryLoaderPlaceholder from './SummaryLoaderPlaceholder'
const SummaryReport = ({ summary }) => {
    const [report, setReport] = useState(null)
    useEffect(() => {
        if (summary) {
            const result = summary.replace('##', '###').replace('#', '###')

            // setChatMessages((prev) => [...prev, { text: result }])
            setReport(result)
        }
    }, [summary])

    if (!summary) {
        return <SummaryLoaderPlaceholder />
    }
    return <ReactMarkdown>{report}</ReactMarkdown>
}

export default SummaryReport
