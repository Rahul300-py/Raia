import React from 'react'
import {
    ListItem,
    Typography,
    Card,
    CardContent,
    Stack,
    Button,
} from '@mui/material'
import { Assessment, Dashboard, Description } from '@mui/icons-material'
import { useSelector } from 'react-redux'
import ModelUploadSection from '../common/ModelUploadSection'
import ColumnSelector from '../common/ColumnSelector'
import DrawerIconList from '../common/DrawerIconList'

function ClassificationDrawer({
    open,
    setOpen,
    loading,
    handleBrowseFairness,
    fairnessfileState,
    modelFormat,
    setModelFormat,
    selectedTargetColumn,
    setSelectedTargetColumn,
    handleSaveClassificationData,
    runClassificationReport,
    runClassificationAnalysis,
    runClassificationDashboard,
}) {
    const { availableColumns, availableColumnsLoading } = useSelector(
        (state) => state.classification
    )

    return open ? (
        <ListItem disablePadding sx={{ display: 'block', px: 2.5, mt: 3 }}>
            <Typography
                variant="subtitle"
                sx={{ color: '#fff', fontWeight: 'bold' }}
            >
                Classification Analysis
            </Typography>
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <ModelUploadSection
                        fileState={fairnessfileState}
                        handleBrowse={handleBrowseFairness}
                        modelFormat={modelFormat}
                        setModelFormat={setModelFormat}
                        handleSaveData={handleSaveClassificationData}
                    />
                </CardContent>
            </Card>
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <Stack spacing={3} my={2}>
                        <Typography
                            variant="subtitle2"
                            sx={{ fontWeight: 'bold' }}
                        >
                            Select Target Column
                        </Typography>
                        <ColumnSelector
                            label="Target Column"
                            value={selectedTargetColumn}
                            onChange={(e) =>
                                setSelectedTargetColumn(e.target.value)
                            }
                            options={availableColumns}
                            loading={availableColumnsLoading}
                            placeholder="Select Target Column"
                        />
                        <Button
                            variant="contained"
                            startIcon={<Description />}
                            onClick={runClassificationReport}
                            sx={{
                                width: '100%',
                                padding: 1,
                                backgroundColor: '#232f3e',
                                '&:hover': { backgroundColor: '#3a475b' },
                            }}
                        >
                            Generate Report
                        </Button>
                        <Button
                            variant="contained"
                            startIcon={<Assessment />}
                            onClick={runClassificationAnalysis}
                            sx={{
                                width: '100%',
                                padding: 1,
                                backgroundColor: '#232f3e',
                                '&:hover': { backgroundColor: '#3a475b' },
                            }}
                        >
                            Run Analysis
                        </Button>
                        <Button
                            variant="contained"
                            startIcon={<Dashboard />}
                            onClick={runClassificationDashboard}
                            sx={{
                                width: '100%',
                                padding: 1,
                                backgroundColor: '#232f3e',
                                '&:hover': { backgroundColor: '#3a475b' },
                            }}
                        >
                            View Dashboard
                        </Button>
                    </Stack>
                </CardContent>
            </Card>
        </ListItem>
    ) : (
        <DrawerIconList onIconClick={() => setOpen(true)} />
    )
}

export default ClassificationDrawer
