/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import {
    AppBar,
    Box,
    Toolbar,
    IconButton,
    Typography,
    InputBase,
    MenuItem,
    Menu,
    Tooltip,
} from '@mui/material'
import { styled, alpha } from '@mui/material/styles'
import {
    AccountCircle,
    MoreVert as MoreIcon,
    Search as SearchIcon,
    Settings as SettingsIcon,
    Logout,
    Close as CloseIcon,
    Chat as ChatIcon,
} from '@mui/icons-material'
import { useNavigate } from 'react-router-dom'
import { useDispatch } from 'react-redux'
import { logout } from '../store/authSlice'

const logoSrc = '/logo-nav.png'

/** Styled search bar */
const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha('#ebedf3', 0.75),
    '&:hover': { backgroundColor: alpha('#ebedf3', 1) },
    marginRight: theme.spacing(2),
    marginLeft: theme.spacing(2),
    width: '100%',
    maxWidth: 300,
}))

const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
}))

const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
        padding: theme.spacing(1, 1, 1, 0),
        paddingLeft: `calc(1em + ${theme.spacing(4)})`,
        transition: theme.transitions.create('width'),
        width: '100%',
    },
}))

/** Dashboard navbar component */
export default function DashboardNavBar() {
    const dispatch = useDispatch()
    const navigate = useNavigate()

    const [anchorEl, setAnchorEl] = useState(null)
    const [mobileAnchorEl, setMobileAnchorEl] = useState(null)
    const [showChatBot, setShowChatBot] = useState(false)
    const [chatMessages, setChatMessages] = useState([])
    const [chatInput, setChatInput] = useState('')

    const isMenuOpen = Boolean(anchorEl)
    const isMobileMenuOpen = Boolean(mobileAnchorEl)

    const handleProfileMenuOpen = (e) => setAnchorEl(e.currentTarget)
    const handleMobileMenuOpen = (e) => setMobileAnchorEl(e.currentTarget)
    const handleMenuClose = () => {
        setAnchorEl(null)
        setMobileAnchorEl(null)
    }

    return (
        <>
            <Box sx={{ flexGrow: 1 }}>
                <AppBar position="static" sx={{ bgcolor: '#0d0d2b' }}>
                    <Toolbar
                        sx={{
                            justifyContent: 'space-between',
                            marginLeft: '50px',
                        }}
                    >
                        <img
                            src={logoSrc}
                            alt="XAI Logo"
                            onClick={() => navigate('/')}
                            style={{ width: '100px', cursor: 'pointer' }}
                        />
                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                            {/* <Search>
                                <SearchIconWrapper>
                                    <SearchIcon />
                                </SearchIconWrapper>
                                <StyledInputBase
                                    placeholder="Search…"
                                    inputProps={{ 'aria-label': 'search' }}
                                />
                            </Search> */}
                            <Tooltip title="Settings">
                                <IconButton size="large" color="inherit">
                                    <SettingsIcon />
                                </IconButton>
                            </Tooltip>
                            <Tooltip title="Profile">
                                <IconButton
                                    size="large"
                                    color="inherit"
                                    onClick={handleProfileMenuOpen}
                                >
                                    <AccountCircle />
                                </IconButton>
                            </Tooltip>

                            <Box sx={{ display: { xs: 'flex', md: 'none' } }}>
                                <IconButton
                                    size="large"
                                    onClick={handleMobileMenuOpen}
                                    color="inherit"
                                >
                                    <MoreIcon />
                                </IconButton>
                            </Box>
                        </Box>
                    </Toolbar>
                </AppBar>
            </Box>

            {/* Mobile Menu */}
            <Menu
                anchorEl={mobileAnchorEl}
                open={isMobileMenuOpen}
                onClose={handleMenuClose}
                anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
                transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            >
                <MenuItem onClick={handleProfileMenuOpen}>
                    <AccountCircle /> &nbsp; Profile
                </MenuItem>
                <MenuItem>
                    <SettingsIcon /> &nbsp; Settings
                </MenuItem>
            </Menu>
        </>
    )
}
