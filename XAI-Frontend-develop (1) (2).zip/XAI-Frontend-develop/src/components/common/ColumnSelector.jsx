import React from 'react'
import {
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    CircularProgress,
} from '@mui/material'

/**
 * A generic dropdown selector for a list of options.
 * @param {object} props - The component props.
 * @param {string} props.label - The label for the dropdown.
 * @param {string} props.value - The currently selected value.
 * @param {Function} props.onChange - The function to call on selection change.
 * @param {Array<string|object>} props.options - The list of options. Can be an array of strings or objects.
 * @param {boolean} props.loading - If true, shows a loading spinner.
 * @param {string} props.placeholder - The placeholder text to show.
 * @param {string} [props.optionValueKey='value'] - The key for the option's value if options are objects.
 * @param {string} [props.optionLabelKey='label'] - The key for the option's label if options are objects.
 */
function ColumnSelector({
    label,
    value,
    onChange,
    options,
    loading,
    placeholder,
    optionValueKey = 'value',
    optionLabelKey = 'label',
}) {
    const isObjectArray = options?.length > 0 && typeof options[0] === 'object'

    return (
        <FormControl sx={{ minWidth: 180, width: '100%' }} size="small">
            <InputLabel>{label}</InputLabel>
            <Select value={value} label={label} onChange={onChange}>
                {placeholder && (
                    <MenuItem value="">
                        <em>{placeholder}</em>
                    </MenuItem>
                )}
                {loading ? (
                    <MenuItem disabled>
                        <CircularProgress size={20} />
                    </MenuItem>
                ) : (
                    options?.map((opt) => (
                        <MenuItem
                            key={isObjectArray ? opt[optionValueKey] : opt}
                            value={isObjectArray ? opt[optionValueKey] : opt}
                        >
                            {isObjectArray ? opt[optionLabelKey] : opt}
                        </MenuItem>
                    ))
                )}
            </Select>
        </FormControl>
    )
}

export default ColumnSelector
