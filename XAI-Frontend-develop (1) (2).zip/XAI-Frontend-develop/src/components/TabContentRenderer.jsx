import React from 'react'
import { Typography } from '@mui/material'
import WhatIfAnalysis from '../components/WhatIfAnalysis'
import DataDriftDashboard from '../views/DriftReportViewer'
import FairnessDashboard from '../views/FairnessMatrix'
import RegressionDashboard from '../views/RegressionDashboard'
import ClassificationDashboard from '../views/ClassificationDashboard'
import FeatureImportancesDashboard from '../views/FeatureImportancesDashboard'
import IndividualPredictionsDashboard from '../views/IndividualPredictionsDashboard'
import FeatureDependenceDashboard from '../views/FeatureDependenceDashboard'
import FeatureInteractionsDashboard from '../views/FeatureInteractionsDashboard'
import DecisionTreesDashboard from '../views/DecisionTreesDashboard'

const TabContentRenderer = ({
    activeTab,
    // Data Drift props
    fetchRecord,
    setFetchRecord,
    setOpen,
    setSelectedProject,
    selectedProject,

    // Fairness props
    selectedSensitiveFeature,
    selectedTargetColumn,

    // Feature Importances props
    importanceType,
    setImportanceType,
    depth,
    setDepth,

    // Individual Predictions props
    selectedIndividual,
    setSelectedIndividual,

    // Feature Dependence props
    dependencyFeature,
    setDependencyFeature,

    // Feature Interactions props
    interactionFeature1,
    setInteractionFeature1,
    interactionFeature2,
    setInteractionFeature2,
}) => {
    const renderTabContent = () => {
        switch (activeTab) {
            case 0: // What if...
                return <WhatIfAnalysis />

            case 1: // Data drift
                return (
                    <DataDriftDashboard
                        RefreshFetchRecord={fetchRecord}
                        setFetchRecord={setFetchRecord}
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                    />
                )

            case 2: // Fairness
                return (
                    <FairnessDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedSensitiveFeature={selectedSensitiveFeature}
                        selectedTargetColumn={selectedTargetColumn}
                    />
                )

            case 3: // Regression
                return (
                    <RegressionDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedSensitiveFeature={selectedSensitiveFeature}
                    />
                )

            case 4: // Classification
                return (
                    <ClassificationDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                    />
                )

            case 5: // Feature Importances
                return (
                    <FeatureImportancesDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedTargetColumn={selectedTargetColumn}
                        importanceType={importanceType}
                        setImportanceType={setImportanceType}
                        depth={depth}
                        setDepth={setDepth}
                    />
                )

            case 6: // Individual Predictions
                return (
                    <IndividualPredictionsDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedTargetColumn={selectedTargetColumn}
                        selectedIndividual={selectedIndividual}
                        setSelectedIndividual={setSelectedIndividual}
                    />
                )

            case 7: // Feature Dependence
                return (
                    <FeatureDependenceDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedTargetColumn={selectedTargetColumn}
                        dependencyFeature={dependencyFeature}
                        setDependencyFeature={setDependencyFeature}
                    />
                )

            case 8: // Feature Interactions
                return (
                    <FeatureInteractionsDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedTargetColumn={selectedTargetColumn}
                        interactionFeature1={interactionFeature1}
                        setInteractionFeature1={setInteractionFeature1}
                        interactionFeature2={interactionFeature2}
                        setInteractionFeature2={setInteractionFeature2}
                    />
                )

            case 9: // Decision Trees
                return (
                    <DecisionTreesDashboard
                        setOpenSideBar={setOpen}
                        setSelectedProject={setSelectedProject}
                        selectedProject={selectedProject}
                        selectedTargetColumn={selectedTargetColumn}
                    />
                )

            default:
                return (
                    <Typography
                        variant="h6"
                        sx={{
                            textAlign: 'center',
                            py: 5,
                            color: 'text.secondary',
                        }}
                    >
                        Select a tab to view content.
                    </Typography>
                )
        }
    }

    return renderTabContent()
}

export default TabContentRenderer
