/* eslint-disable no-unused-vars */
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import {
    Box,
    Typography,
    Paper,
    Button,
    CircularProgress,
    IconButton,
    TableContainer,
    Table,
    TableHead,
    TableRow,
    TableCell,
    TableBody,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    List,
    ListItem,
    ListItemButton,
    ListItemText,
    Divider,
    Grid,
    Chip,
    Stack,
} from '@mui/material'
import ErrorOutlineIcon from '@mui/icons-material/ErrorOutline'
import SummaryLoaderPlaceholder from '../components/SummaryLoaderPlaceholder'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    CropFree,
    Close,
    Dashboard,
    Folder,
    InfoOutline,
    ExpandCircleDown,
    ArrowDropDownCircle,
} from '@mui/icons-material'
import { useSearchParams } from 'react-router-dom'
import { useDispatch, useSelector } from 'react-redux'
import { selectDriftConfig, setProjectList } from '../store/driftConfigSlice'
import { Delete, Launch } from '@mui/icons-material'
import Tooltip from '@mui/material/Tooltip'

// const dummyProjects = [
//     {
//         id: 'project-001',
//         name: 'BANK.CSV',
//     },
//     // You can later add more projects here
// ]

const DriftReportViewer = ({
    RefreshFetchRecord,
    setFetchRecord,
    setOpenSideBar,
    selectedProject,
    setSelectedProject,
}) => {
    const { token, user } = useSelector((state) => state?.auth)
    const { datasets, dataPreview, fairnessAnalysis } = useSelector(
        (state) => state.fairness
    )
    const driftConfig = useSelector(selectDriftConfig)
    const [searchParams] = useSearchParams()
    const dispatch = useDispatch()
    const [htmlBlobUrl, setHtmlBlobUrl] = useState(null)
    const [loading, setLoading] = useState(false)
    const [errorStatus, setErrorStatus] = useState(null)
    const [error, setError] = useState(false)
    const [referencePreviewData, setReferencePreviewData] = useState([])
    const [currentPreviewData, setCurrentPreviewData] = useState([])
    const [referencePreviewColumns, setReferencePreviewColumns] = useState([])
    const [currentPreviewColumns, setCurrentPreviewColumns] = useState([])
    const [openModal, setOpenModal] = useState(false)
    const [modalTitle, setModalTitle] = useState('')
    const [modalData, setModalData] = useState([])
    const [modalColumns, setModalColumns] = useState([])
    const [showDescription, setShowDescription] = useState(false)

    const overrideCSS = `
    body {
      font-family: Arial, sans-serif !important;
      background: white !important;
      color: #111 !important;
    }
    p {
      font-size: 1rem !important;
      text-align: left !important;
      font-weight: bold !important;
    }
    h1, h2, h3, h5 {
      color: #0d0d2b !important;
      font-size: 1rem !important;
      text-align: left !important;
    }
  `

    const fetchReport = () => {
        setLoading(true)
        setError(null)

        const {
            excludedColumns,
            useDateColumnSplit,
            selectedDateColumn,
            referenceStartDate,
            currentStartDate,
        } = driftConfig

        let payload = {
            split_pct: 70,
        }

        if (excludedColumns.length) {
            payload.drop_cols = excludedColumns
        }

        if (useDateColumnSplit && selectedDateColumn) {
            payload.date_col = [selectedDateColumn]
        }

        if (referenceStartDate && currentStartDate) {
            payload.ref_range = [referenceStartDate, referenceStartDate]
            payload.cur_range = [currentStartDate, currentStartDate]
        }

        axios
            .post(
                'http://13.235.248.104:8000/api/data_drift/full_drift_report',
                payload,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )
            .then((res) => {
                const originalHtml = res.data.drift_summary
                const styledHtml = originalHtml.replace(
                    '</head>',
                    `<style>${overrideCSS}</style></head>`
                )
                const blob = new Blob([styledHtml], { type: 'text/html' })
                const url = URL.createObjectURL(blob)
                setHtmlBlobUrl(url)

                const refData = res.data.data_preview.ref_preview || []
                const curData = res.data.data_preview.cur_preview || []
                setReferencePreviewData(refData)
                setCurrentPreviewData(curData)

                if (refData.length > 0) {
                    setReferencePreviewColumns(Object.keys(refData[0]))
                }
                if (curData.length > 0) {
                    setCurrentPreviewColumns(Object.keys(curData[0]))
                }
            })
            .catch((err) => {
                if (err.response) {
                    console.error('Error Status Code:', err.response.status)
                    setError(
                        `Error ${err.response.status}: ${err.response.data?.detail || 'Something went wrong'}`
                    )
                } else {
                    console.error('No response from server')
                    setError('Network error or server not reachable')
                }
            })
            .finally(() => setTimeout(() => setLoading(false), 1000))
    }

    const handleOpenModal = (label, data, cols) => {
        setModalTitle(`${label} Preview`)
        setModalData(data)
        setModalColumns(cols)
        setOpenModal(true)
    }

    const handleCloseModal = () => {
        setOpenModal(false)
    }

    useEffect(() => {
        if (selectedProject) fetchReport()
    }, [selectedProject])

    useEffect(() => {
        if (RefreshFetchRecord) {
            fetchReport()
            setFetchRecord(false)
        }
    }, [RefreshFetchRecord])
    if (!selectedProject) {
        return (
            <Box sx={{ px: 6, py: 4 }}>
                {/* SECTION 1: DATA DRIFT OVERVIEW */}

                <Box>
                    {datasets && datasets?.datadrift?.files?.length > 0 ? (
                        <Stack
                            sx={{
                                flexDirection: 'row',
                                alignItems: 'center',
                                width: 'fit-content',
                                px: 0,
                            }}
                        >
                            <Box sx={{ mb: 4 }}>
                                <Typography
                                    variant="h4"
                                    sx={{
                                        fontWeight: 600,
                                        mb: 1,
                                        color: '#232f3e',
                                    }}
                                >
                                    Data Drift Analysis
                                </Typography>
                                <Typography
                                    variant="body1"
                                    sx={{ color: 'text.secondary' }}
                                >
                                    Data drift refers to unexpected and
                                    undocumented changes to input data that can
                                    significantly impact the performance of
                                    machine learning models. This system helps
                                    you detect, analyze, and mitigate drift in
                                    real-time.{' '}
                                    <Button
                                        onClick={() => setShowDescription(true)}
                                        variant="text"
                                        color="primary.dark"
                                        sx={{ fontSize: '1rem', padding: 0 }}
                                    >
                                        Learn More
                                        <InfoOutline
                                            sx={{
                                                fontSize: '1rem',
                                                ml: '4px',
                                            }}
                                        />
                                    </Button>
                                </Typography>
                            </Box>
                        </Stack>
                    ) : (
                        <Paper sx={{ p: 3 }} elevation={1}>
                            <Stack
                                sx={{
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    alignItems: 'center',
                                }}
                            >
                                <Typography
                                    variant="h4"
                                    fontWeight={600}
                                    gutterBottom
                                >
                                    Data Drift Analysis
                                </Typography>
                                {/* <Button
                                    color="primary.dark"
                                    onClick={() => setShowDescription(false)}
                                >
                                    <ArrowDropDownCircle />
                                </Button> */}
                            </Stack>
                            <Typography
                                variant="body1"
                                color="text.secondary"
                                sx={{ maxWidth: 900, mb: 2 }}
                            >
                                Data drift refers to unexpected and undocumented
                                changes to input data that can significantly
                                impact the performance of machine learning
                                models. This system helps you detect, analyze,
                                and mitigate drift in real-time.
                            </Typography>
                            <Divider sx={{ my: 3 }} />
                            <Grid container spacing={4}>
                                <Grid item xs={12} md={6}>
                                    <Typography
                                        variant="h6"
                                        fontWeight={500}
                                        gutterBottom
                                    >
                                        Why It Matters
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        color="text.secondary"
                                        paragraph
                                    >
                                        - Ensures model accuracy and fairness
                                        over time
                                        <br />
                                        - Triggers model retraining at the right
                                        time
                                        <br />
                                        - Supports data governance and
                                        compliance
                                        <br />- Prevents silent model failure in
                                        production
                                    </Typography>
                                </Grid>

                                <Grid item xs={12} md={6}>
                                    <Typography
                                        variant="h6"
                                        fontWeight={500}
                                        gutterBottom
                                    >
                                        Typical Use Cases
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        color="text.secondary"
                                        paragraph
                                    >
                                        - Customer behavior prediction (e.g.,
                                        churn, credit risk)
                                        <br />
                                        - Fraud detection systems
                                        <br />
                                        - Anomaly detection in real-time logs
                                        <br />- Product recommendation pipelines
                                    </Typography>
                                </Grid>
                            </Grid>
                        </Paper>
                    )}
                </Box>
                {/* SECTION 2: PROJECTS */}
                <Box>
                    <Typography
                        variant="h6"
                        fontWeight={600}
                        gutterBottom
                        sx={{
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                    >
                        <Folder
                            sx={{
                                color: 'orange',
                                fontSize: '1.5rem',
                                mr: '4px',
                            }}
                        />
                        Browse Projects
                    </Typography>
                    <Typography
                        variant="body2"
                        color="text.secondary"
                        gutterBottom
                    >
                        Select an existing project to view its data drift
                        report, or create a new one to get started.
                    </Typography>

                    {datasets && datasets?.datadrift?.files?.length > 0 ? (
                        <Box
                            sx={{
                                mt: 2,
                                display: 'flex',
                                flexDirection: 'column',
                                overflowX: 'auto',
                                gap: 2,
                                pb: 1,
                                width: '100%',
                            }}
                        >
                            {datasets?.datadrift.files?.map((project, i) => (
                                <Paper
                                    key={i}
                                    elevation={1}
                                    sx={{
                                        minWidth: 300,
                                        px: 3,
                                        py: 2,
                                        borderRadius: 2,
                                        display: 'flex',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        border: '1px solid #e0e0e0',
                                        position: 'relative',
                                    }}
                                >
                                    <Box
                                        sx={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 1,
                                        }}
                                    >
                                        <Dashboard
                                            sx={{
                                                color: 'green',
                                                fontSize: '1.6rem',
                                            }}
                                        />
                                        <Typography
                                            variant="subtitle1"
                                            fontWeight={600}
                                        >
                                            {project.file_name}
                                        </Typography>
                                    </Box>

                                    <Box
                                        sx={{
                                            display: 'flex',
                                            justifyContent: 'flex-end',
                                            gap: 1,
                                        }}
                                    >
                                        <Button
                                            variant="outlined"
                                            onClick={() =>
                                                setSelectedProject(project)
                                            }
                                            // disabled={
                                            //     i < projectList.length - 1
                                            // }
                                            sx={{ color: 'primary.dark' }}
                                        >
                                            Run Analysis{' '}
                                            <Launch fontSize="small" />
                                        </Button>
                                    </Box>
                                </Paper>
                            ))}
                        </Box>
                    ) : (
                        <Box
                            sx={{
                                border: '1px dashed #ccc',
                                borderRadius: 2,
                                p: 4,
                                mt: 4,
                                textAlign: 'center',
                                backgroundColor: '#fafafa',
                            }}
                        >
                            <Typography
                                variant="subtitle1"
                                fontWeight={500}
                                gutterBottom
                            >
                                No Past Analysis Found
                            </Typography>
                            <Typography
                                variant="body2"
                                color="text.secondary"
                                sx={{ maxWidth: 500, margin: '0 auto' }}
                            >
                                You haven’t created any drift monitoring
                                projects yet. Create one to begin analyzing
                                model stability over time.
                            </Typography>
                            <Button
                                variant="contained"
                                sx={{ mt: 3 }}
                                onClick={() => setOpenSideBar(true)}
                            >
                                Create Analysis
                            </Button>
                        </Box>
                    )}
                </Box>

                <Dialog
                    open={showDescription}
                    onClose={() => setShowDescription(false)}
                    fullWidth
                    maxWidth="lg"
                >
                    <DialogTitle
                        sx={{
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                        }}
                    >
                        What is Data Drift Analysis ?
                        <IconButton onClick={() => setShowDescription(false)}>
                            <Close />
                        </IconButton>
                    </DialogTitle>
                    <DialogContent dividers>
                        <Typography
                            variant="body1"
                            color="text.secondary"
                            sx={{ maxWidth: 900, mb: 2 }}
                        >
                            Data drift refers to unexpected and undocumented
                            changes to input data that can significantly impact
                            the performance of machine learning models. This
                            system helps you detect, analyze, and mitigate drift
                            in real-time.
                        </Typography>
                        <Divider sx={{ my: 3 }} />
                        <Grid container spacing={4}>
                            <Grid item xs={12} md={6}>
                                <Typography
                                    variant="h6"
                                    fontWeight={500}
                                    gutterBottom
                                >
                                    Why It Matters
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    paragraph
                                >
                                    - Ensures model accuracy and fairness over
                                    time
                                    <br />
                                    - Triggers model retraining at the right
                                    time
                                    <br />
                                    - Supports data governance and compliance
                                    <br />- Prevents silent model failure in
                                    production
                                </Typography>
                            </Grid>

                            <Grid item xs={12} md={6}>
                                <Typography
                                    variant="h6"
                                    fontWeight={500}
                                    gutterBottom
                                >
                                    Typical Use Cases
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    paragraph
                                >
                                    - Customer behavior prediction (e.g., churn,
                                    credit risk)
                                    <br />
                                    - Fraud detection systems
                                    <br />
                                    - Anomaly detection in real-time logs
                                    <br />- Product recommendation pipelines
                                </Typography>
                            </Grid>
                        </Grid>
                    </DialogContent>
                </Dialog>
            </Box>
        )
    }

    if (loading) return <SummaryLoaderPlaceholder />

    return (
        <Box>
            {/* PREVIEW BLOCKS + REPORT IFRAME */}
            {htmlBlobUrl ? (
                <>
                    <Box
                        sx={{
                            display: 'flex',
                            flexWrap: 'wrap',
                            gap: 3,
                            mb: 1,
                            px: 3,
                        }}
                    >
                        {[
                            {
                                label: 'Reference',
                                data: referencePreviewData,
                                cols: referencePreviewColumns,
                            },
                            {
                                label: 'Current',
                                data: currentPreviewData,
                                cols: currentPreviewColumns,
                            },
                        ].map(({ label, data, cols }, idx) => (
                            <Paper
                                key={idx}
                                elevation={1}
                                sx={{
                                    p: 2,
                                    flex: 1,
                                    minWidth: 300,
                                    overflow: 'hidden',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        mb: 1,
                                    }}
                                >
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 'bold' }}
                                    >
                                        {label} preview
                                    </Typography>
                                    <IconButton
                                        size="small"
                                        onClick={() =>
                                            handleOpenModal(label, data, cols)
                                        }
                                    >
                                        <CropFree fontSize="small" />
                                    </IconButton>
                                </Box>
                                <TableContainer
                                    sx={{ maxHeight: 200, overflowX: 'auto' }}
                                >
                                    <Table size="small" stickyHeader>
                                        <TableHead>
                                            <TableRow>
                                                {cols.map((col) => (
                                                    <TableCell
                                                        key={col}
                                                        sx={{
                                                            fontWeight: 'bold',
                                                            minWidth: 80,
                                                        }}
                                                    >
                                                        {col}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {data
                                                .slice(0, 5)
                                                .map((row, rowIdx) => (
                                                    <TableRow key={rowIdx}>
                                                        {cols.map((col) => (
                                                            <TableCell
                                                                key={col}
                                                            >
                                                                {row[col]}
                                                            </TableCell>
                                                        ))}
                                                    </TableRow>
                                                ))}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        ))}
                    </Box>
                    <iframe
                        src={htmlBlobUrl}
                        title="Drift Report"
                        style={{
                            width: '100%',
                            height: '100vh',
                            border: 'none',
                        }}
                    />
                </>
            ) : (
                <Box p={4}>
                    <Typography variant="h5" gutterBottom>
                        Drift Report Preview
                    </Typography>
                    <Paper
                        variant="outlined"
                        sx={{
                            p: 3,
                            maxHeight: '80vh',
                            overflowY: 'auto',
                            backgroundColor: '#fafafa',
                            display: 'flex',
                            flexDirection: 'column',
                            alignItems: 'center',
                            justifyContent: 'center',
                            textAlign: 'center',
                        }}
                    >
                        <ErrorOutlineIcon
                            color="warning"
                            sx={{ fontSize: 48, mb: 1 }}
                        />
                        <Typography variant="body1" sx={{ fontWeight: 500 }}>
                            No report content available
                        </Typography>

                        <Typography variant="body2" color="error" mt={1} mb={2}>
                            {error}
                        </Typography>
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={fetchReport}
                            disabled={loading}
                        >
                            {loading ? (
                                <CircularProgress size={20} color="inherit" />
                            ) : (
                                'Reload | Try Again'
                            )}
                        </Button>
                    </Paper>
                </Box>
            )}

            {/* MODAL DIALOG */}
            <Dialog
                open={openModal}
                onClose={handleCloseModal}
                fullWidth
                maxWidth="lg"
            >
                <DialogTitle
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'center',
                    }}
                >
                    {modalTitle}
                    <IconButton onClick={handleCloseModal}>
                        <Close />
                    </IconButton>
                </DialogTitle>
                <DialogContent dividers>
                    <TableContainer sx={{ maxHeight: '70vh' }}>
                        <Table stickyHeader size="small">
                            <TableHead>
                                <TableRow>
                                    {modalColumns.map((col) => (
                                        <TableCell
                                            key={col}
                                            sx={{
                                                fontWeight: 'bold',
                                                minWidth: 100,
                                            }}
                                        >
                                            {col}
                                        </TableCell>
                                    ))}
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {modalData.map((row, idx) => (
                                    <TableRow key={idx}>
                                        {modalColumns.map((col) => (
                                            <TableCell key={col}>
                                                {row[col]}
                                            </TableCell>
                                        ))}
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseModal} color="primary">
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </Box>
    )
}

export default DriftReportViewer
