/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import { useSelector } from 'react-redux'
import performAnalysisData from '../../mockdata/performanalysis.json' // Corrected import for performanalysis.json
import mitigationStrategiesData from '../../mockdata/mitigation_strategies.json'
import listDatasetsData from '../../mockdata/listdatasets.json'
/* eslint-disable no-unused-vars */

import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
    CircularProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    LinearProgress,
    Stack,
} from '@mui/material'
import { TabContext, TabList, TabPanel } from '@mui/lab'
import Tab from '@mui/material/Tab'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import AssessmentIcon from '@mui/icons-material/Assessment'
import PreviewIcon from '@mui/icons-material/Preview'
import DownloadIcon from '@mui/icons-material/Download'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    Radar,
    RadarChart,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    Legend,
    CartesianGrid,
} from 'recharts'

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
} from 'recharts'

import {
    Dashboard,
    DocumentScanner,
    Folder,
    InfoOutline,
    Launch,
} from '@mui/icons-material'
import SummaryLoaderPlaceholder from '../../components/SummaryLoaderPlaceholder'
import axios from 'axios'

function NoDataFound({ setOpenSideBar }) {
    const { datasets } = useSelector((state) => state.fairness)

    return (
        <Container
            maxWidth="xl"
            sx={{
                mt: 4,
                mb: 4,
                fontFamily: 'Inter, sans-serif',
                '& .MuiPaper-root': {
                    boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
                },
            }}
        >
            {/* Page Header */}
            <Box sx={{ mb: 4 }}>
                <Typography
                    variant="h4"
                    sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                >
                    AI Fairness Analysis Platform
                </Typography>
                <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                    Evaluate model performance across different demographic
                    groups to assess fairness and identify potential biases.{' '}
                    <Button
                        // onClick={() => setShowDescription(true)}
                        variant="text"
                        color="primary.dark"
                        sx={{ fontSize: '1rem', padding: 0 }}
                    >
                        Learn More
                        <InfoOutline
                            sx={{
                                fontSize: '1rem',
                                ml: '4px',
                            }}
                        />
                    </Button>
                </Typography>
            </Box>
            <Box>
                {datasets && datasets?.fairness?.files?.length > 0 ? (
                    <Box
                        sx={{
                            mt: 2,
                            display: 'flex',
                            flexDirection: 'column',
                            overflowX: 'auto',
                            gap: 2,
                            pb: 1,
                            width: '100%',
                        }}
                    >
                        <Typography>Files</Typography>
                        {datasets?.fairness?.files?.map((project, i) => (
                            <Paper
                                key={i}
                                elevation={1}
                                sx={{
                                    minWidth: 300,
                                    px: 3,
                                    py: 2,
                                    borderRadius: 2,
                                    display: 'flex',
                                    flexDirection: 'row',
                                    alignItems: 'center',
                                    justifyContent: 'space-between',
                                    border: '1px solid #e0e0e0',
                                    position: 'relative',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 1,
                                    }}
                                >
                                    <Dashboard
                                        sx={{
                                            color: 'green',
                                            fontSize: '1.6rem',
                                        }}
                                    />
                                    <Typography
                                        variant="subtitle1"
                                        fontWeight={600}
                                    >
                                        {project.file_name}
                                    </Typography>
                                </Box>

                                <Box
                                    sx={{
                                        display: 'flex',
                                        justifyContent: 'flex-end',
                                        gap: 1,
                                    }}
                                >
                                    <Button
                                        variant="outlined"
                                        // onClick={() =>
                                        //     startAnalysisHandler(project)
                                        // }
                                        disabled
                                        sx={{ color: 'primary.dark' }}
                                    >
                                        View Details
                                        <Launch fontSize="small" />
                                    </Button>
                                </Box>
                            </Paper>
                        ))}
                    </Box>
                ) : (
                    <Box
                        sx={{
                            border: '1px dashed #ccc',
                            borderRadius: 2,
                            p: 4,
                            mt: 4,
                            textAlign: 'center',
                            backgroundColor: '#fafafa',
                        }}
                    >
                        <Typography
                            variant="subtitle1"
                            fontWeight={500}
                            gutterBottom
                        >
                            No Past Analysis Found
                        </Typography>
                        <Typography
                            variant="body2"
                            color="text.secondary"
                            sx={{ maxWidth: 500, margin: '0 auto' }}
                        >
                            You haven’t created any drift monitoring projects
                            yet. Create one to begin analyzing model stability
                            over time.
                        </Typography>
                        <Button
                            variant="contained"
                            sx={{ mt: 3 }}
                            onClick={() => setOpenSideBar(true)}
                        >
                            Create Analysis
                        </Button>
                    </Box>
                )}
            </Box>
        </Container>
    )
}

export default NoDataFound
