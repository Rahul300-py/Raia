/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import { useSelector } from 'react-redux'
import performAnalysisData from '../../mockdata/performanalysis.json' // Corrected import for performanalysis.json
import mitigationStrategiesData from '../../mockdata/mitigation_strategies.json'
import listDatasetsData from '../../mockdata/listdatasets.json'
/* eslint-disable no-unused-vars */

import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
    CircularProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    LinearProgress,
    Stack,
} from '@mui/material'
import { TabContext, TabList, TabPanel } from '@mui/lab'
import Tab from '@mui/material/Tab'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import AssessmentIcon from '@mui/icons-material/Assessment'
import PreviewIcon from '@mui/icons-material/Preview'
import DownloadIcon from '@mui/icons-material/Download'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    Radar,
    RadarChart,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    Legend,
    CartesianGrid,
} from 'recharts'

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
} from 'recharts'

import {
    Dashboard,
    DocumentScanner,
    Folder,
    InfoOutline,
    Launch,
} from '@mui/icons-material'
import SummaryLoaderPlaceholder from '../../components/SummaryLoaderPlaceholder'
import axios from 'axios'
// Helper for status color mapping (e.g., for disparity)
const getDisparityColor = (value) => {
    // These thresholds are examples; adjust based on domain knowledge
    if (Math.abs(value) > 0.1) return 'error' // High disparity
    if (Math.abs(value) > 0.03) return 'warning' // Moderate disparity
    return 'success' // Low disparity/good
}

// Helper for improvement percentage color mapping
const getImprovementColor = (percentage) => {
    if (percentage > 5) return 'success' // Significant positive improvement
    if (percentage > 0) return 'info' // Some positive improvement
    if (percentage < 0) return 'error' // Degradation or negative impact
    return 'default' // No change
}

function FairnessMitigation({ selectedTargetColumn }) {
    const { token, user } = useSelector((state) => state?.auth)
    const projectList = useSelector((state) => state.driftConfig.projectList)
    const { fairnessAnalysis, loading, datasets } = useSelector(
        (state) => state.fairness
    )

    const { features, metrics, llm_analysis_report, overview, plots } =
        fairnessAnalysis || {}

    const [selectedTab, setSelectedTab] = useState('overview')
    const [selectedAttribute, setSelectedAttribute] = useState(
        performAnalysisData?.features?.[0] || 'Age_Group'
    )

    const [selectedMitigationStrategy, setSelectedMitigationStrategy] =
        useState(
            mitigationStrategiesData?.strategies?.[0]?.value ||
                'exponentiated_gradient'
        )
    const [selectedDataset, setSelectedDataset] = useState(
        listDatasetsData?.files?.[0]?.file_name || 'ref_biased_age.csv'
    )

    const [llmExplanation, setLlmExplanation] = useState('')
    const [isLlmLoading, setIsLlmLoading] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)

    // Extract data for the currently selected sensitive attribute
    const currentAttributeMetrics =
        performAnalysisData?.metrics?.[selectedAttribute] || {}
    const llmAnalysisReport = llm_analysis_report || ''

    // Prepare data for the comparison bar charts (Before vs After Mitigation)
    const prepareChartData = (beforeData, afterData, metricKey) => {
        const data = []
        for (const group in beforeData) {
            data.push({
                name: group,
                'Before Mitigation': beforeData[group][metricKey],
                'After Mitigation': afterData[group][metricKey],
            })
        }
        return data
    }

    const accuracyChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'accuracy_score'
    )
    const selectionRateChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'selection_rate'
    )
    const tprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'tpr'
    )
    const fprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'fpr'
    )

    const grpWisePerfornameChartData = (data) =>
        Object.entries(data).map(([group, beforeMetrics]) => {
            const afterMetrics =
                metrics[selectedTargetColumn].group_performance_after?.[
                    group
                ] || {}

            return {
                group,
                'Accuracy (Before)': beforeMetrics.accuracy_score || 0,
                'Accuracy (After)': afterMetrics.accuracy_score || 0,
                'Selection Rate (Before)': beforeMetrics.selection_rate || 0,
                'Selection Rate (After)': afterMetrics.selection_rate || 0,
                'TPR (Before)': beforeMetrics.tpr || 0,
                'TPR (After)': afterMetrics.tpr || 0,
                'FPR (Before)': beforeMetrics.fpr || 0,
                'FPR (After)': afterMetrics.fpr || 0,
            }
        })

    const radarChartData = [
        {
            metric: 'Accuracy',
            Before: accuracyChartData[0]?.['Before Mitigation'] || 0,
            After: accuracyChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'Selection Rate',
            Before: selectionRateChartData[0]?.['Before Mitigation'] || 0,
            After: selectionRateChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'TPR',
            Before: tprChartData[0]?.['Before Mitigation'] || 0,
            After: tprChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'FPR',
            Before: fprChartData[0]?.['Before Mitigation'] || 0,
            After: fprChartData[0]?.['After Mitigation'] || 0,
        },
    ]

    // Helper to render markdown content
    const renderMarkdown = (markdownText) => {
        let html = markdownText
            // Headings
            .replace(/^### (.*$)/gim, '<h4 class="md-h4">$1</h4>')
            .replace(/^## (.*$)/gim, '<h3 class="md-h3">$1</h3>')
            .replace(/^# (.*$)/gim, '<h2 class="md-h2">$1</h2>')

            // Lists
            .replace(/^\* (.*$)/gim, '<li>$1</li>')
            .replace(/^- (.*$)/gim, '<li>$1</li>')

            // Bold & Italic
            .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/gim, '<em>$1</em>')

            // Inline code
            .replace(/`([^`]+)`/gim, '<code class="md-code-inline">$1</code>')

            // Paragraphs (wrap isolated text blocks)
            .replace(
                /^(?!<h|<ul|<li|<code|<strong|<em|<p|<blockquote)(.+)$/gim,
                '<p class="md-paragraph">$1</p>'
            )

        // Wrap <li> blocks in <ul> only once
        html = html.replace(/(<li>.*?<\/li>)/gims, '<ul class="md-ul">$1</ul>')

        return (
            <div
                className="markdown-container"
                dangerouslySetInnerHTML={{ __html: html }}
            />
        )
    }
    return (
        <TabPanel value="mitigation" sx={{ p: 0 }}>
            <Grid container spacing={3}>
                {/* Bias Mitigation Strategies */}
                <Grid item xs={12} width="100%">
                    <Paper
                        elevation={1}
                        sx={{
                            p: 3,
                            borderRadius: 3,
                            boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                            backgroundColor: '#fff',
                            border: '1px solid #f1f3f5',
                        }}
                    >
                        <Typography
                            variant="h6"
                            fontWeight={700}
                            sx={{ mb: 1.5, color: '#1a1a1a' }}
                        >
                            Bias Mitigation Strategies Overview
                        </Typography>
                        <Typography
                            variant="body2"
                            color="text.secondary"
                            sx={{ mb: 3 }}
                        >
                            Techniques applied at different stages to reduce
                            algorithmic bias.
                        </Typography>
                        <Grid container spacing={4}>
                            {[
                                {
                                    title: 'Pre-processing Techniques',
                                    items: [
                                        {
                                            label: 'Reweighing samples',
                                            status: 'Implemented',
                                        },
                                        {
                                            label: 'Disparate impact remover',
                                            status: 'Implemented',
                                        },
                                        {
                                            label: 'Data augmentation',
                                            status: 'Implemented',
                                        },
                                    ],
                                    color: '#388e3c',
                                    bg: '#e8f5e9',
                                    border: '#c8e6c9',
                                },
                                {
                                    title: 'In-processing Techniques',
                                    items: [
                                        {
                                            label: 'Fairness constraints',
                                            status: 'Under Review',
                                        },
                                        {
                                            label: 'Adversarial debiasing',
                                            status: 'Under Review',
                                        },
                                        {
                                            label: 'Fair representation learning',
                                            status: 'Under Review',
                                        },
                                    ],
                                    color: '#0277bd',
                                    bg: '#e1f5fe',
                                    border: '#b3e5fc',
                                },
                                {
                                    title: 'Post-processing Techniques',
                                    items: [
                                        {
                                            label: 'Threshold optimization',
                                            status: 'Implemented',
                                        },
                                        {
                                            label: 'Calibrated equalized odds',
                                            status: 'Implemented',
                                        },
                                        {
                                            label: 'Output modification',
                                            status: 'Implemented',
                                        },
                                    ],
                                    color: '#388e3c',
                                    bg: '#e8f5e9',
                                    border: '#c8e6c9',
                                },
                            ].map((section, index) => (
                                <Grid
                                    item
                                    xs={12}
                                    md={4}
                                    key={index}
                                    sx={{
                                        flex: 1,
                                        border: '2px dotted grey',
                                        padding: '1rem',
                                        borderRadius: '8px',
                                    }}
                                >
                                    <Typography
                                        variant="subtitle1"
                                        fontWeight={600}
                                        gutterBottom
                                    >
                                        {section.title}
                                    </Typography>
                                    <Stack spacing={1}>
                                        {section.items.map((item, idx) => (
                                            <Stack
                                                key={idx}
                                                direction="row"
                                                alignItems="center"
                                                spacing={1}
                                                sx={{
                                                    display: 'flex',
                                                    flexDirection: 'row',
                                                    justifyContent:
                                                        'space-between',
                                                }}
                                            >
                                                <Typography variant="body2">
                                                    {item.label}
                                                </Typography>
                                                <Chip
                                                    label={item.status}
                                                    size="small"
                                                    variant="outlined"
                                                    sx={{
                                                        fontSize: '0.75rem',
                                                        color: section.color,
                                                        backgroundColor:
                                                            section.bg,
                                                        borderColor:
                                                            section.border,
                                                        fontWeight: 500,
                                                    }}
                                                />
                                            </Stack>
                                        ))}
                                    </Stack>
                                </Grid>
                            ))}
                        </Grid>
                    </Paper>
                </Grid>

                {/* Fairness Metrics Table and Recommendations Side by Side */}
                <Grid item xs={12} sx={{ width: '100%' }}>
                    <Grid container spacing={3}>
                        {/* Table */}
                        <Grid item xs={12} md={6} flex={1}>
                            <Paper
                                elevation={1}
                                sx={{
                                    p: 3,
                                    borderRadius: 3,
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                                    backgroundColor: '#fff',
                                    border: '1px solid #f1f3f5',
                                    height: '100%',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    fontWeight={700}
                                    sx={{ mb: 1.5, color: '#1a1a1a' }}
                                >
                                    Impact of Mitigation on Overall Fairness
                                    Metrics
                                </Typography>
                                <TableContainer>
                                    <Table size="medium">
                                        <TableHead
                                            sx={{
                                                backgroundColor: '#f9f9f9',
                                            }}
                                        >
                                            <TableRow>
                                                {[
                                                    'Metric',
                                                    'Before',
                                                    'After',
                                                    'Improvement (%)',
                                                ].map((head, idx) => (
                                                    <TableCell
                                                        key={idx}
                                                        sx={{
                                                            fontWeight: 600,
                                                        }}
                                                    >
                                                        {head}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {Object.entries(
                                                metrics[selectedTargetColumn]
                                                    ?.fairness_metrics_before ||
                                                    {}
                                            ).map(([metric, value]) => {
                                                const after =
                                                    currentAttributeMetrics
                                                        ?.fairness_metrics_after?.[
                                                        metric
                                                    ]
                                                const improvement =
                                                    value !== 0 &&
                                                    after !== undefined
                                                        ? (
                                                              ((value - after) /
                                                                  value) *
                                                              100
                                                          ).toFixed(2)
                                                        : 'N/A'
                                                const isPositive =
                                                    improvement !== 'N/A' &&
                                                    parseFloat(improvement) > 0

                                                return (
                                                    <TableRow
                                                        key={metric}
                                                        hover
                                                    >
                                                        <TableCell>
                                                            {metric.replace(
                                                                /_/g,
                                                                ' '
                                                            )}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            {value?.toFixed(4)}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            {after?.toFixed(4)}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            <Chip
                                                                label={`${improvement}%`}
                                                                size="small"
                                                                sx={{
                                                                    color: isPositive
                                                                        ? '#2e7d32'
                                                                        : '#c62828',
                                                                    backgroundColor:
                                                                        isPositive
                                                                            ? '#e8f5e9'
                                                                            : '#ffebee',
                                                                    fontWeight: 600,
                                                                    fontSize:
                                                                        '0.75rem',
                                                                }}
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                )
                                            })}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Grid>

                        {/* Recommendations */}
                        <Grid item xs={12} md={6} flex={1}>
                            <Paper
                                elevation={1}
                                sx={{
                                    p: 3,
                                    borderRadius: 3,
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                                    backgroundColor: '#fff',
                                    border: '1px solid #f1f3f5',
                                    height: '100%',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    fontWeight={700}
                                    sx={{ mb: 1.5, color: '#1a1a1a' }}
                                >
                                    Recommended Strategies Based on Analysis
                                </Typography>

                                {metrics[selectedTargetColumn]?.recommendations
                                    ?.length > 0 ? (
                                    <Stack spacing={3}>
                                        {metrics[
                                            selectedTargetColumn
                                        ].recommendations.map((rec, index) => (
                                            <Box key={index}>
                                                <Typography
                                                    variant="subtitle2"
                                                    fontWeight={600}
                                                >
                                                    Affected Metric:{' '}
                                                    <Chip
                                                        label={rec.metric.replace(
                                                            /_/g,
                                                            ' '
                                                        )}
                                                        size="small"
                                                        sx={{
                                                            ml: 1,
                                                            backgroundColor:
                                                                '#eceff1',
                                                            fontWeight: 500,
                                                        }}
                                                    />
                                                </Typography>
                                                <Typography
                                                    variant="body2"
                                                    color="text.secondary"
                                                    sx={{ mt: 0.5 }}
                                                >
                                                    <strong>
                                                        Issue Identified:
                                                    </strong>{' '}
                                                    {rec.issue}
                                                </Typography>
                                                <Typography
                                                    variant="body2"
                                                    fontWeight={600}
                                                    sx={{ mt: 1 }}
                                                >
                                                    Suggested Strategies:
                                                </Typography>
                                                <ul
                                                    style={{
                                                        paddingLeft: '20px',
                                                        margin: 0,
                                                    }}
                                                >
                                                    {rec.strategies.map(
                                                        (strategy, sIndex) => (
                                                            <li key={sIndex}>
                                                                <Typography variant="body2">
                                                                    {strategy}
                                                                </Typography>
                                                            </li>
                                                        )
                                                    )}
                                                </ul>
                                            </Box>
                                        ))}
                                    </Stack>
                                ) : (
                                    <Typography
                                        variant="body2"
                                        color="text.secondary"
                                    >
                                        No specific recommendations available
                                        based on current analysis.
                                    </Typography>
                                )}
                            </Paper>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </TabPanel>
    )
}

export default FairnessMitigation
