import React, { useState } from 'react'
import { Box } from '@mui/material'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'

// Components
import DashboardHeader from '../components/DashboardHeader'
import TabContentRenderer from '../components/TabContentRenderer'
import ChatBot from '../components/ChatBot'
import UploadDrawer from '../components/UploadDrawer'
import { useAnalysisActions } from '../components/AnalysisActions'

// Hooks
import { useFileUpload } from '../hooks/FileUpload'

// Constants
import { tabLabels, logoSrc, DEFAULT_FORM_VALUES } from '../constants/mockdata'

// Store actions
import { fetchFullLLMDrift } from '../store/llmSlice'

function XAIDashboardPage() {
    const dispatch = useDispatch()
    const navigate = useNavigate()

    // Redux selectors
    const { datasets } = useSelector((state) => state.fairness)
    const { fullDriftAnalysis } = useSelector((state) => state.llm)

    // Core dashboard state
    const [activeTab, setActiveTab] = useState(1)
    const [open, setOpen] = useState(false)
    const [showChatBot, setShowChatBot] = useState(false)
    const [fetchRecord, setFetchRecord] = useState(false)
    const [selectedProject, setSelectedProject] = useState(null)

    // Form state using default values
    const [selectedSensitiveFeature, setSelectedSensitiveFeature] =
        useState(null)
    const [selectedMitigationStrategy, setSlectedMitigationStrategy] =
        useState(null)
    const [selectedTargetColumn, setSelectedTargetColumn] = useState(null)
    const [importanceType, setImportanceType] = useState(
        DEFAULT_FORM_VALUES.importanceType
    )
    const [depth, setDepth] = useState(DEFAULT_FORM_VALUES.depth)
    const [selectedIndividual, setSelectedIndividual] = useState(
        DEFAULT_FORM_VALUES.selectedIndividual
    )
    const [dependencyFeature, setDependencyFeature] = useState(
        DEFAULT_FORM_VALUES.dependencyFeature
    )
    const [interactionFeature1, setInteractionFeature1] = useState(
        DEFAULT_FORM_VALUES.interactionFeature1
    )
    const [interactionFeature2, setInteractionFeature2] = useState(
        DEFAULT_FORM_VALUES.interactionFeature2
    )

    // Custom hooks
    const fileUploadHandlers = useFileUpload()
    const analysisActions = useAnalysisActions({
        selectedTargetColumn,
        selectedSensitiveFeature,
        selectedMitigationStrategy,
    })

    // Event handlers
    const handleTabChange = (event, newValue) => {
        setActiveTab(newValue)
        if (newValue === 1) {
            setFetchRecord(true)
        }
    }

    const handleGoBack = () => {
        navigate(-1)
    }

    const handleAIMessageSend = () => {
        if (!fullDriftAnalysis) {
            dispatch(fetchFullLLMDrift())
        }
    }

    const handleExplainClick = () => {
        setShowChatBot(true)
        handleAIMessageSend()
    }

    const fetchRecordHandler = () => {
        setFetchRecord(true)
        setActiveTab(1)
        setSelectedProject(datasets?.datadrift?.files[0])
    }

    // Props for child components
    const headerProps = {
        activeTab,
        handleTabChange,
        tabLabels,
        open,
        logoSrc,
        handleGoBack,
        selectedProject,
        setSelectedProject,
        showExplainButton: activeTab === 1,
        onExplainClick: handleExplainClick,
    }

    const tabContentProps = {
        activeTab,
        fetchRecord,
        setFetchRecord,
        setOpen,
        setSelectedProject,
        selectedProject,
        selectedSensitiveFeature,
        selectedTargetColumn,
        importanceType,
        setImportanceType,
        depth,
        setDepth,
        selectedIndividual,
        setSelectedIndividual,
        dependencyFeature,
        setDependencyFeature,
        interactionFeature1,
        setInteractionFeature1,
        interactionFeature2,
        setInteractionFeature2,
    }

    const uploadDrawerProps = {
        open,
        setOpen,
        fileState: fileUploadHandlers.fileState,
        fairnessfileState: fileUploadHandlers.fairnessfileState,
        handleBrowse: fileUploadHandlers.handleBrowse,
        handleBrowseFairness: fileUploadHandlers.handleBrowseFairness,
        handleSave: fileUploadHandlers.handleSave,
        handleSavefairnessData: fileUploadHandlers.handleSavefairnessData,
        handleSaveRegressionData: fileUploadHandlers.handleSaveRegressionData,
        handleSaveClassificationData:
            fileUploadHandlers.handleSaveClassificationData,
        loading: fileUploadHandlers.loading,
        percentage: fileUploadHandlers.percentage,
        setPercentage: fileUploadHandlers.setPercentage,
        logoSrc,
        navigate,
        setActiveTab,
        selectedTargetColumn,
        setSelectedTargetColumn,
        setSelectedSensitiveFeature,
        selectedSensitiveFeature,
        fetchRecord: fetchRecordHandler,
        activeTab,
        runFairnessAnalysis: analysisActions.runFairnessAnalysis,
        runRegressionAnalysis: analysisActions.runRegressionAnalysis,
        runRegressionModelExplainibility:
            analysisActions.runRegressionModelExplainibility,
        selectedMitigationStrategy,
        setSlectedMitigationStrategy,
        runClassificationReport: analysisActions.runClassificationReport,
        runClassificationAnalysis: analysisActions.runClassificationAnalysis,
        runClassificationDashboard: analysisActions.runClassificationDashboard,
        modelFormat: fileUploadHandlers.modelFormat,
        setModelFormat: fileUploadHandlers.setModelFormat,
    }

    const chatBotProps = {
        showChatBot,
        setShowChatBot,
        fullDriftAnalysis,
    }

    return (
        <Box sx={{ display: 'flex', height: '100vh' }}>
            {/* Sidebar Drawer */}
            <UploadDrawer {...uploadDrawerProps} />

            {/* Main Content Area */}
            <Box
                sx={{
                    flexGrow: 1,
                    display: 'flex',
                    flexDirection: 'column',
                    bgcolor: 'background.default',
                    pb: 4,
                    px: 0,
                    overflow: 'auto',
                    pt: 0,
                }}
            >
                {/* Header with tabs and breadcrumb */}
                <DashboardHeader {...headerProps} />

                {/* Tab Content */}
                <Box
                    sx={{
                        p: 3,
                        pt: 0,
                        bgcolor: 'background.paper',
                        borderRadius: '0 0 8px 8px',
                        boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
                        flexGrow: 1,
                        overflowY: 'auto',
                    }}
                >
                    <TabContentRenderer {...tabContentProps} />
                </Box>
            </Box>

            {/* ChatBot Drawer */}
            <ChatBot {...chatBotProps} />
        </Box>
    )
}

export default XAIDashboardPage
