import { Box } from '@mui/material'
import NewNavbar from '../components/NewNavbar'
import NewHeroSection from '../components/NewHeroSection'
import NewFeatures from '../components/NewFeatures'
import NewFooter from '../components/NewFooter'
import ContentPreviewSection from '../components/ContentPreviewSection'
import ExplainabilitySuiteSection from '../components/ExplainabilitySuiteSection'
import ComprehensiveModelEvalute from '../components/comprehensiveModelEvalute'
import RealTimeMonitoringSection from '../components/RealTimeMonitoringSection'
import RagEvaluationFramework from '../components/ragEvauationFramework'
import RagSystemEvaluation from '../components/RagSystemEvaluation'
import SupportedLLMFramework from '../components/SupportedLLMFramework'
import InteractiveEvaluation from '../components/InteractiveEvaluation'
import FairnessMitigationSection from '../components/FairnessMitigationSection'
import StatsSection from '../components/StatsSection'

export default function NewLandingPage() {
    return (
        <Box>
            {/* <NewNavbar /> */}
            <NewHeroSection />
            <ContentPreviewSection />
            <ExplainabilitySuiteSection />
            <ComprehensiveModelEvalute />
            <RealTimeMonitoringSection />
            <RagEvaluationFramework />
            <RagSystemEvaluation />
            <SupportedLLMFramework />
            <InteractiveEvaluation />
            {/* <FairnessMitigationSection /> */}
            {/* <StatsSection /> */}
            <NewFooter />
        </Box>
    )
}
