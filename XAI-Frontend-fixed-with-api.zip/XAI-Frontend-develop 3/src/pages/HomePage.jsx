import { useState } from 'react'
import {
    Box,
    Typography,
    Button,
    Container,
    Card,
    CardMedia,
    Stack,
    Drawer,
    List,
    Toolbar,
    IconButton,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogContentText,
    DialogActions,
    useMediaQuery,
    Paper,
    Tooltip,
} from '@mui/material'
import { useTheme } from '@mui/material/styles'
import {
    Settings,
    Folder,
    BarChart,
    DashboardCustomize,
    Home,
    Menu as MenuIcon,
    ChevronLeft,
    Logout as LogoutIcon,
    Info,
    Dashboard,
    Delete,
    Launch,
    DocumentScanner,
    Cloud,
} from '@mui/icons-material'
import { useSelector, useDispatch } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import DashboardNavBar from '../components/DashboardNavbar'
import FolderOpenIcon from '@mui/icons-material/FolderOpen'
import SidebarItem from '../components/SidebarItem'
import { logout } from '../store/authSlice'
import FileExplorer from '../components/FileExplorer'

const logoSrc = '/logo-nav.png'

function HomePage() {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const user_name = useSelector((state) => state?.auth?.user?.name)
    const { datasets } = useSelector((state) => state.fairness)

    const [mobileOpen, setMobileOpen] = useState(false)
    const [collapsed, setCollapsed] = useState(true)
    const [activeSection, setActiveSection] = useState('Home')
    const [logoutDialogOpen, setLogoutDialogOpen] = useState(false)

    const theme = useTheme()
    const fullScreen = useMediaQuery(theme.breakpoints.down('sm'))
    const drawerWidth = collapsed ? 72 : 240

    const menuItems = [
        { text: 'Home', icon: <Home /> },
        { text: 'Dashboard', icon: <DashboardCustomize />, href: '/dashboard' },
        { text: 'Uploads', icon: <Cloud /> },
        { text: 'Old Explainability', icon: <BarChart />, href: '/demo' },
        { text: 'Settings', icon: <Settings /> },
    ]

    const handleDrawerToggle = () => {
        setMobileOpen(!mobileOpen)
    }

    const handleToggleCollapse = () => {
        setCollapsed(!collapsed)
    }

    const handleLogoutClick = () => setLogoutDialogOpen(true)
    const confirmLogout = () => {
        dispatch(logout())
        navigate('/')
        setLogoutDialogOpen(false)
    }

    const drawer = (
        <Box
            sx={{
                textAlign: 'center',
                color: '#fff',
                display: 'flex',
                flexDirection: 'column',
                height: '100%',
            }}
        >
            <Toolbar
                sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: collapsed ? 'center' : 'space-between',
                    px: collapsed ? 1 : 2,
                }}
            >
                {!collapsed && (
                    <img src={logoSrc} alt="Logo" style={{ width: '100px' }} />
                )}
                <IconButton
                    onClick={handleToggleCollapse}
                    sx={{ color: '#fff' }}
                >
                    {collapsed ? <MenuIcon /> : <ChevronLeft />}
                </IconButton>
            </Toolbar>

            <Box sx={{ flexGrow: 1 }}>
                <List>
                    {menuItems.map(({ text, icon, href }) => (
                        <SidebarItem
                            key={text}
                            text={text}
                            icon={icon}
                            href={href}
                            collapsed={collapsed}
                            onClick={() => {
                                href ? navigate(href) : setActiveSection(text)
                            }}
                        />
                    ))}
                </List>
            </Box>

            <Box sx={{ mb: 2 }}>
                <SidebarItem
                    text="Logout"
                    icon={<LogoutIcon />}
                    collapsed={collapsed}
                    onClick={handleLogoutClick}
                />
            </Box>
        </Box>
    )

    const renderContent = () => {
        switch (activeSection) {
            case 'Home':
                return (
                    <>
                        <Typography variant="h6" gutterBottom fontWeight="bold">
                            Recent Projects
                        </Typography>
                        <Stack spacing={3} mt={2}>
                            {datasets && datasets?.all?.length > 0 ? (
                                <Box
                                    sx={{
                                        mt: 2,
                                        display: 'flex',
                                        flexDirection: 'column',
                                        overflowX: 'auto',
                                        gap: 2,
                                        pb: 1,
                                    }}
                                >
                                    <Typography variant="caption">
                                        Files
                                    </Typography>
                                    {datasets &&
                                        datasets?.all?.map((project, i) => (
                                            <Paper
                                                key={i}
                                                elevation={2}
                                                sx={{
                                                    minWidth: 300,
                                                    px: 3,
                                                    py: 2,
                                                    borderRadius: 2,
                                                    display: 'flex',
                                                    flexDirection: 'row',
                                                    alignItems: 'center',
                                                    justifyContent:
                                                        'space-between',
                                                    border: '1px solid #e0e0e0',
                                                    position: 'relative',
                                                }}
                                            >
                                                <Box
                                                    sx={{
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        gap: 1,
                                                    }}
                                                >
                                                    <Dashboard
                                                        sx={{
                                                            color: 'green',
                                                            fontSize: '1.6rem',
                                                        }}
                                                    />
                                                    <Typography
                                                        variant="subtitle1"
                                                        fontWeight={600}
                                                    >
                                                        {project.file_name}
                                                    </Typography>
                                                </Box>

                                                <Box
                                                    sx={{
                                                        display: 'flex',
                                                        justifyContent:
                                                            'flex-end',
                                                        gap: 1,
                                                    }}
                                                >
                                                    <Tooltip title="Open">
                                                        <IconButton
                                                            size="small"
                                                            onClick={() =>
                                                                navigate(
                                                                    '/dashboard'
                                                                )
                                                            }
                                                        >
                                                            <Launch fontSize="small" />
                                                        </IconButton>
                                                    </Tooltip>
                                                </Box>
                                            </Paper>
                                        ))}
                                </Box>
                            ) : (
                                <Box
                                    textAlign="center"
                                    py={6}
                                    px={2}
                                    border="1px dashed"
                                    borderColor="divider"
                                    borderRadius={2}
                                    bgcolor="#f9fafc"
                                >
                                    <FolderOpenIcon
                                        sx={{
                                            fontSize: 60,
                                            color: 'text.secondary',
                                            mb: 2,
                                        }}
                                    />
                                    <Typography
                                        variant="h6"
                                        color="text.secondary"
                                        gutterBottom
                                    >
                                        No Projects Found
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        color="text.secondary"
                                    >
                                        You haven’t created any projects yet.
                                        Click below to start.
                                    </Typography>
                                    <Button
                                        variant="contained"
                                        sx={{ mt: 3, textTransform: 'none' }}
                                        href="/new-analysis"
                                    >
                                        Create New Project
                                    </Button>
                                </Box>
                            )}
                        </Stack>
                    </>
                )
            case 'Projects':
                return <Typography variant="h6">Projects Section</Typography>
            case 'Settings':
                return (
                    <Typography variant="h6">
                        Update your preferences here.
                    </Typography>
                )

            case 'Uploads':
                return <FileExplorer />
            default:
                return null
        }
    }

    /** Styled Logout confirmation dialog */
    function LogoutDialog({ open, onConfirm, onCancel }) {
        return (
            <Dialog
                open={open}
                onClose={onCancel}
                fullScreen={fullScreen}
                PaperProps={{
                    sx: {
                        borderRadius: 3,
                        backgroundColor: theme.palette.background.paper,
                        p: 2,
                        boxShadow: '0 4px 20px rgba(0, 0, 0, 0.15)',
                    },
                }}
            >
                <Box sx={{ textAlign: 'center' }}>
                    <Info
                        fontSize="large"
                        sx={{
                            color: 'orange',
                        }}
                    />
                </Box>
                <DialogTitle
                    sx={{
                        color: theme.palette.secondary.main,
                        fontWeight: 'bold',
                        textAlign: 'center',
                    }}
                >
                    Confirm Logout?
                </DialogTitle>

                <DialogContent>
                    <DialogContentText
                        sx={{
                            color: theme.palette.text.primary,
                            textAlign: 'center',
                            fontSize: '1rem',
                            mb: 1,
                        }}
                    >
                        Are you sure you want to logout?
                    </DialogContentText>
                </DialogContent>

                <DialogActions
                    sx={{
                        justifyContent: 'center',
                        gap: 2,
                        pb: 2,
                    }}
                >
                    <Button
                        onClick={onCancel}
                        variant="outlined"
                        sx={{
                            color: theme.palette.primary.main,
                            borderColor: theme.palette.primary.main,
                            '&:hover': {
                                backgroundColor: theme.palette.primary.light,
                                borderColor: theme.palette.primary.main,
                            },
                        }}
                    >
                        Cancel
                    </Button>

                    <Button
                        onClick={onConfirm}
                        variant="contained"
                        sx={{
                            backgroundColor: theme.palette.highlight.main,
                            color: theme.palette.text.light,
                            '&:hover': {
                                backgroundColor: theme.palette.secondary.main,
                            },
                        }}
                        autoFocus
                    >
                        Logout
                    </Button>
                </DialogActions>
            </Dialog>
        )
    }

    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <Drawer
                    variant="temporary"
                    open={mobileOpen}
                    onClose={handleDrawerToggle}
                    ModalProps={{ keepMounted: true }}
                    sx={{
                        display: { xs: 'block', sm: 'none' },
                        '& .MuiDrawer-paper': {
                            boxSizing: 'border-box',
                            width: 240,
                        },
                    }}
                >
                    {drawer}
                </Drawer>

                <Drawer
                    variant="permanent"
                    sx={{
                        display: { xs: 'none', sm: 'block' },
                        '& .MuiDrawer-paper': {
                            width: drawerWidth,
                            boxSizing: 'border-box',
                            backgroundColor: 'primary.dark',
                            color: '#fff',
                            transition: 'width 0.3s ease',
                            overflowX: 'hidden',
                        },
                    }}
                    open
                >
                    {drawer}
                </Drawer>

                <Box
                    component="main"
                    sx={{
                        flexGrow: 1,
                        width: `calc(100% - ${drawerWidth}px)`,
                        transition: 'width 0.3s ease',
                    }}
                >
                    <DashboardNavBar />
                    <Box sx={{ mt: 8, marginLeft: '72px' }}>
                        {activeSection === 'Home' && (
                            <Container maxWidth="md">
                                <Card
                                    sx={{
                                        borderRadius: 4,
                                        background:
                                            'linear-gradient(to right, #0d0d2b, rgb(186, 195, 255))',
                                        color: 'white',
                                        p: { xs: 4, sm: 6 },
                                        mb: 6,
                                    }}
                                >
                                    <Typography
                                        variant="h4"
                                        fontWeight="bold"
                                        gutterBottom
                                    >
                                        Welcome back, {user_name}!
                                    </Typography>
                                    <Typography variant="body1" maxWidth={500}>
                                        Dive back into your projects or start a
                                        new analysis.
                                    </Typography>
                                    <Button
                                        variant="contained"
                                        sx={{
                                            mt: 3,
                                            bgcolor: '#dae4ef',
                                            color: '#000',
                                            fontWeight: 'bold',
                                            '&:hover': { bgcolor: '#cbd8e2' },
                                        }}
                                        href="/new-analysis"
                                    >
                                        Start New Analysis
                                    </Button>
                                </Card>
                            </Container>
                        )}
                        <Container maxWidth="md">{renderContent()}</Container>
                    </Box>
                </Box>
            </Box>

            <LogoutDialog
                open={logoutDialogOpen}
                onConfirm={confirmLogout}
                onCancel={() => setLogoutDialogOpen(false)}
            />
        </>
    )
}

export default HomePage
