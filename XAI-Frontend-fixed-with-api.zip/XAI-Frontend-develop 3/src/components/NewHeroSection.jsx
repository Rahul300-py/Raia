// src/components/NewHeroSection.jsx
import React from 'react'
import { Box, Typography, Button, Stack } from '@mui/material'

const NewHeroSection = () => {
    const logoSrc = '/logo-nav.png'
    return (
        <Box
            sx={{
                position: 'relative',
                minHeight: '94vh',
                overflow: 'hidden',
                // backgroundColor: '#0d0d2b',
                background:
                    'linear-gradient(to right, #0d0d2b 0%, #4e4e8a 60%, rgb(186, 195, 255) 100%)',
                display: 'flex',
                justifyContent: 'center',
                px: 4,
            }}
        >
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: { xs: 'column', md: 'row' },
                    alignItems: 'center',
                    justifyContent: 'space-between',
                    width: '100%',
                    maxWidth: '1300px',
                    zIndex: 2,
                }}
            >
                {/* Left Text Section */}
                <Box
                    sx={{
                        maxWidth: { xs: '100%', md: '50%' },
                        color: 'white',
                        textAlign: { xs: 'center', md: 'left' },
                        mb: { xs: 6, md: 0 },
                        // Added padding-left for better alignment on larger screens
                        // This ensures content within the left Box isn't against the edge
                        pl: { md: 4 }, // Add left padding on medium and up screens
                    }}
                >
                    <Button
                        size="small"
                        sx={{
                            backgroundColor: '#1d1d50',
                            color: '#aab0ff',
                            borderRadius: '20px',
                            textTransform: 'none',
                            mb: 2,
                            px: 2,
                        }}
                        endIcon={<span style={{ fontSize: '1rem' }}>➔</span>}
                    >
                        Evaluate, Test & Monitor.
                    </Button>

                    <Typography
                        variant="h3"
                        fontWeight={700}
                        sx={{ color: 'rgb(186, 195, 255)', mb: 2 }}
                    >
                        Next-Generation{' '}
                        <Box component="span" sx={{ color: '#ff66c4' }}>
                            AI Explainability{' '}
                        </Box>{' '}
                        &{' '}
                        <Box component="span" sx={{ color: '#ff66c4' }}>
                            Monitoring
                        </Box>{' '}
                        Platform
                    </Typography>
                    <Typography variant="body1" sx={{ mb: 3 }}>
                        Unlock the black box of AI with advanced
                        interpretability tools, real-time monitoring, and
                        comprehensive bias detection. asset issuers to
                        participate in the Interchain economy
                    </Typography>
                    <Stack
                        direction="row"
                        spacing={2}
                        justifyContent={{ xs: 'center', md: 'flex-start' }}
                    >
                        <Button
                            variant="contained"
                            sx={{
                                backgroundColor: 'white',
                                color: '#0d0d2b',
                                borderRadius: '30px',
                                textTransform: 'none',
                                fontWeight: 600,
                            }}
                        >
                            Get in touch
                        </Button>
                        <Button
                            href="/demo"
                            variant="text"
                            sx={{
                                color: 'white',
                                textTransform: 'none',
                            }}
                            endIcon={
                                <span style={{ fontSize: '1rem' }}>➔</span>
                            }
                        >
                            See how it works
                        </Button>
                    </Stack>
                </Box>

                {/* Right Rotating Background */}
                <Box
                    sx={{
                        position: 'relative',
                        width: { xs: '100%', md: '50%' },
                        height: { xs: '300px', md: '500px' },
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                    }}
                >
                    <Box
                        sx={{
                            position: 'absolute',
                            width: '150%',
                            height: '150%',
                            backgroundImage:
                                'radial-gradient(circle at center, transparent 0%, transparent 10%, #0d0d2b 30%, transparent 31%, transparent 49%, rgba(255,255,255,0.05) 50%, transparent 51%, transparent 69%, rgba(255,255,255,0.05) 70%, transparent 71%, transparent 89%, rgba(255,255,255,0.05) 90%, transparent 91%)',
                            borderRadius: '50%',
                            animation: 'rotateLines 10s linear infinite',
                        }}
                    />

                    <Box
                        component="img"
                        src={logoSrc}
                        alt="center logo"
                        sx={{ width: '300px', zIndex: 2 }}
                    />
                </Box>
            </Box>

            <style>{`
                @keyframes rotateLines {
                    from {
                        transform: rotate(0deg);
                    }
                    to {
                        transform: rotate(360deg);
                    }
                }
            `}</style>
        </Box>
    )
}

export default NewHeroSection
