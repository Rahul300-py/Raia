import React, { useEffect, useState } from 'react'
import {
    Box,
    Drawer,
    Typography,
    IconButton,
    Stack,
    CircularProgress,
} from '@mui/material'
import CloseIcon from '@mui/icons-material/Close'
import { HorizontalRule, CropSquare } from '@mui/icons-material'
import ReactMarkdown from 'react-markdown'

const ChatBot = ({ showChatBot, setShowChatBot, fullDriftAnalysis }) => {
    const [chatMessages, setChatMessages] = useState([])
    const [chatBotView, setChatBotView] = useState(500)

    useEffect(() => {
        if (fullDriftAnalysis) {
            const result = fullDriftAnalysis
                .replace('##', '###')
                .replace('#', '###')

            setChatMessages([{ text: result }])
        }
    }, [fullDriftAnalysis])

    if (!showChatBot) return null

    return (
        <Drawer
            variant="permanent"
            anchor="right"
            elevation={5}
            sx={{
                width: showChatBot ? chatBotView : 0,
                flexShrink: 0,
                whiteSpace: 'nowrap',
                transition: 'width 0.3s',
                position: 'relative',
                [`& .MuiDrawer-paper`]: {
                    width: showChatBot ? chatBotView : 0,
                    transition: 'width 0.3s',
                    overflowX: 'hidden',
                    boxSizing: 'border-box',
                    color: '#000',
                    bgcolor: 'paper.default',
                },
            }}
        >
            <Box
                sx={{
                    p: 1.5,
                    bgcolor: 'primary.dark',
                    color: 'white',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                }}
            >
                <Typography variant="h6">RAIA Companion</Typography>
                <Stack flexDirection="row">
                    <IconButton
                        onClick={() => setChatBotView(500)}
                        sx={{ color: 'white' }}
                    >
                        <HorizontalRule />
                    </IconButton>
                    <IconButton
                        onClick={() => setChatBotView('100%')}
                        sx={{ color: 'white' }}
                    >
                        <CropSquare />
                    </IconButton>
                    <IconButton
                        onClick={() => setShowChatBot(false)}
                        sx={{ color: 'white' }}
                    >
                        <CloseIcon />
                    </IconButton>
                </Stack>
            </Box>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'column',
                    gap: 2,
                    mt: 1,
                    height: 'calc(100% - 80px)',
                    mb: 1,
                }}
            >
                <Box
                    sx={{
                        borderRadius: 2,
                        p: 1,
                        height: '100%',
                        overflowY: 'auto',
                        width: '100%',
                    }}
                >
                    {chatMessages.length > 0 ? (
                        chatMessages.map((msg, i) => (
                            <Box
                                key={i}
                                sx={{
                                    textAlign: 'left',
                                    mb: 1,
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'inline-block',
                                        px: 2,
                                        py: 1,
                                        borderRadius: 2,
                                        bgcolor:
                                            msg.sender === 'user'
                                                ? '#1976d2'
                                                : '#eee',
                                        color:
                                            msg.sender === 'user'
                                                ? '#fff'
                                                : '#333',
                                        maxWidth: '100%',
                                        wordWrap: 'break-word',
                                        overflowWrap: 'break-word',
                                        whiteSpace: 'pre-wrap',
                                    }}
                                >
                                    <ReactMarkdown>{msg.text}</ReactMarkdown>
                                </Box>
                            </Box>
                        ))
                    ) : (
                        <Box
                            sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                height: '300px',
                            }}
                        >
                            <CircularProgress color="primary.dark" />
                        </Box>
                    )}
                </Box>
            </Box>
        </Drawer>
    )
}

export default ChatBot
