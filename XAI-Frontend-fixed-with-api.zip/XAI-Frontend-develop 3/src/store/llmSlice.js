import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const BASE_URL =
    'http://13.235.248.104:8000/api/data_drift'

// Fetch full LLM drift analysis
export const fetchFullLLMDrift = createAsyncThunk(
    'llm/fetchFullLLMDrift',
    async (split_pct = 70, thunkAPI) => {
        const token = await localStorage.getItem('token')
        try {
            const response = await axios.post(`${BASE_URL}/llm_report/`, null, {
                params: { split_pct },
                headers: {
                    Authorization: `Bearer ${token}`,
                },
            })
            return response.data.llm_analysis
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail ||
                    'Failed to fetch full LLM report'
            )
        }
    }
)

// Fetch column-wise LLM drift analysis
export const fetchLLMColumnDrift = createAsyncThunk(
    'llm/fetchLLMColumnDrift',
    async (column, thunkAPI) => {
        try {
            const response = await axios.post(
                `${BASE_URL}/llm_column_report/${column}`
            )
            return response.data.llm_analysis
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail ||
                    `Failed to fetch column drift for ${column}`
            )
        }
    }
)

const llmSlice = createSlice({
    name: 'llm',
    initialState: {
        loading: false,
        error: null,
        fullDriftAnalysis: null,
        columnDriftAnalysis: null,
    },
    reducers: {
        clearLLMState: (state) => {
            state.fullDriftAnalysis = null
            state.columnDriftAnalysis = null
            state.error = null
        },
    },
    extraReducers: (builder) => {
        builder
            // Full Drift Analysis
            .addCase(fetchFullLLMDrift.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchFullLLMDrift.fulfilled, (state, action) => {
                state.loading = false
                state.fullDriftAnalysis = action.payload
            })
            .addCase(fetchFullLLMDrift.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Column Drift Analysis
            .addCase(fetchLLMColumnDrift.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchLLMColumnDrift.fulfilled, (state, action) => {
                state.loading = false
                state.columnDriftAnalysis = action.payload
            })
            .addCase(fetchLLMColumnDrift.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
    },
})

export const { clearLLMState } = llmSlice.actions
export default llmSlice.reducer
