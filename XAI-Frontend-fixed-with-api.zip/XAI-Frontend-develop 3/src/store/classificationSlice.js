import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const BASE_URL = 'http://13.204.101.134:8000'

export const fetchClassificationDataPreview = createAsyncThunk(
    'classification/fetchDataPreview',
    async (_, thunkAPI) => {
        const file =
            thunkAPI.getState().classification?.datasets?.classification
                ?.files[0]
        try {
            const token = thunkAPI.getState().auth.token
            const response = await axios.get(
                `${BASE_URL}/classification/preview_dataset`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    params: {
                        file_url: file.url,
                    },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch datasets'
            )
        }
    }
)

export const fetchClassificationHealth = createAsyncThunk(
    'classification/fetchClassificationHealth',
    async (_, thunkAPI) => {
        try {
            const token = localStorage.getItem('token')
            const response = await axios.get(
                `${BASE_URL}/classification/health`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Classification service health check failed'
            )
        }
    }
)

export const fetchClassificationColumns = createAsyncThunk(
    'classification/fetchClassificationColumns',
    async (_, { rejectWithValue }) => {
        try {
            const token = localStorage.getItem('token')

            const response = await axios.get(
                'http://13.235.248.104:8000/api/data_drift/columns/Classification',
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )

            // Check if response.data is an object and has keys
            if (response.data.error) return []
            const data = response?.data

            const keys =
                data && typeof data === 'object' ? Object.keys(data) : []

            // Safely extract the first key's value or fallback to empty array
            const payload = keys.length > 0 ? data[keys[0]] || [] : []
            console.log('Classification columns fetched:', payload)
            return payload
        } catch (error) {
            console.error('Error fetching classification columns:', error)
            return rejectWithValue(
                error?.response?.data || 'Failed to fetch columns'
            )
        }
    }
)

export const fetchClassificationReport = createAsyncThunk(
    'classification/fetchClassificationReport',
    async (targetColumn, thunkAPI) => {
        try {
            const token = thunkAPI.getState().auth.token
            const response = await axios.post(
                `${BASE_URL}/classification/report/html`,
                {
                    target_column: targetColumn,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch classification report'
            )
        }
    }
)

export const fetchClassificationAnalysis = createAsyncThunk(
    'classification/fetchClassificationAnalysis',
    async (targetColumn, thunkAPI) => {
        try {
            const token = thunkAPI.getState().auth.token
            const response = await axios.post(
                `${BASE_URL}/classification/analysis/markdown`,
                {
                    target_column: targetColumn,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch classification analysis'
            )
        }
    }
)

export const fetchClassificationDashboard = createAsyncThunk(
    'classification/fetchClassificationDashboard',
    async (targetColumn, thunkAPI) => {
        try {
            const token = thunkAPI.getState().auth.token
            const response = await axios.post(
                `${BASE_URL}/classification/dashboard/url`,
                {
                    target_column: targetColumn,
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch classification dashboard'
            )
        }
    }
)

// Initial state
const initialState = {
    health: null,
    availableColumns: [],
    datasets: [],
    dataPreview: null,
    classificationAnalysis: null,
    classificationReport: null,
    classificationModelExplainibility: null,
    loading: false,
    error: null,
}

const classificationSlice = createSlice({
    name: 'classification',
    initialState,
    reducers: {
        setClassificationAnalysis: (state, action) => {
            state.classificationAnalysis = action.payload
        },
        setClassificationReport: (state, action) => {
            state.classificationReport = action.payload
        },
        setClassificationDashboard: (state, action) => {
            state.classificationAnalysis = action.payload
        },
        setClassificationModelExplainibility: (state, action) => {
            state.classificationModelExplainibility = action.payload
        },
        setClassificationAnalysisLoading: (state, action) => {
            state.loading = action.payload
        },
        setClassificationModelExplainibilityLoading: (state, action) => {
            state.loading = action.payload
        },
        clearClassificationData: (state) => {
            state.classificationAnalysis = null
            state.classificationReport = null
            //state.classificationDashboard = null
            state.classificationModelExplainibility = null
            state.error = null
        },
        setClassificationLoading: (state, action) => {
            state.loading = action.payload
        },
    },
    extraReducers: (builder) => {
        // Data Preview
        builder
            .addCase(fetchClassificationDataPreview.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(
                fetchClassificationDataPreview.fulfilled,
                (state, action) => {
                    state.loading = false
                    state.dataPreview = action.payload || []
                }
            )
            .addCase(
                fetchClassificationDataPreview.rejected,
                (state, action) => {
                    state.loading = false
                    state.error = action.payload
                }
            )

            // Health
            .addCase(fetchClassificationHealth.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchClassificationHealth.fulfilled, (state, action) => {
                state.loading = false
                state.health = action.payload
            })
            .addCase(fetchClassificationHealth.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Columns
            .addCase(fetchClassificationColumns.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchClassificationColumns.fulfilled, (state, action) => {
                state.loading = false
                state.availableColumns = action.payload
            })
            .addCase(fetchClassificationColumns.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Report
            .addCase(fetchClassificationReport.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchClassificationReport.fulfilled, (state, action) => {
                state.loading = false
                state.classificationReport = action.payload
            })
            .addCase(fetchClassificationReport.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Analysis
            .addCase(fetchClassificationAnalysis.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchClassificationAnalysis.fulfilled, (state, action) => {
                state.loading = false
                state.classificationAnalysis = action.payload
            })
            .addCase(fetchClassificationAnalysis.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Dashboard
            .addCase(fetchClassificationDashboard.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(
                fetchClassificationDashboard.fulfilled,
                (state, action) => {
                    state.loading = false
                    state.classificationDashboard = action.payload
                }
            )
            .addCase(fetchClassificationDashboard.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
    },
})

export const {
    setClassificationAnalysis,
    setClassificationReport,
    setClassificationDashboard,
    setClassificationAnalysisLoading,
    setClassificationModelExplainibility,
    setClassificationModelExplainibilityLoading,
    clearClassificationData,
    setClassificationLoading,
} = classificationSlice.actions

export default classificationSlice.reducer
