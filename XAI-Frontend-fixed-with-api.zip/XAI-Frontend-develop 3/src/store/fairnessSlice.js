import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const BASE_URL = 'http://13.204.101.134:8000'

// Fetch mitigation strategies
export const fetchMitigationStrategies = createAsyncThunk(
    'fairness/fetchMitigationStrategies',
    async (_, thunkAPI) => {
        try {
            const token = localStorage.getItem('token')
            const response = await axios.get(
                `${BASE_URL}/fairness/mitigation_strategies`,
                {
                    headers: { Authorization: `Bearer ${token}` },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch mitigation strategies'
            )
        }
    }
)

// Fetch available datasets
export const fetchDatasets = createAsyncThunk(
    'fairness/fetchDatasets',
    async (_, thunkAPI) => {
        try {
            const token = thunkAPI.getState().auth.token
            const headers = { Authorization: `Bearer ${token}` }

            const [
                fairnessResult,
                datadriftResult,
                regressionResult,
                classificationResult,
            ] = await Promise.allSettled([
                axios.get(`${BASE_URL}/api/files_download/Fairness`, {
                    headers,
                }),
                axios.get(`${BASE_URL}/api/files_download/Data Drift`, {
                    headers,
                }),
                axios.get(`${BASE_URL}/api/files_download/Regression`, {
                    headers,
                }),
                axios.get(`${BASE_URL}/api/files_download/Classification`, {
                    headers,
                }),
            ])

            // Normalize response
            const fairness =
                fairnessResult.status === 'fulfilled' &&
                fairnessResult.value?.data
                    ? {
                          ...fairnessResult.value.data,
                          files: Array.isArray(fairnessResult.value.data.files)
                              ? fairnessResult.value.data.files
                              : [],
                      }
                    : { files: [] }

            const regression =
                regressionResult.status === 'fulfilled' &&
                regressionResult.value?.data
                    ? {
                          ...regressionResult.value.data,
                          files: Array.isArray(
                              regressionResult.value.data.files
                          )
                              ? regressionResult.value.data.files
                              : [],
                      }
                    : { files: [] }

            const classification =
                classificationResult.status === 'fulfilled' &&
                classificationResult.value?.data
                    ? {
                          ...classificationResult.value.data,
                          files: Array.isArray(
                              classificationResult.value.data.files
                          )
                              ? classificationResult.value.data.files
                              : [],
                      }
                    : { files: [] }

            const datadrift =
                datadriftResult.status === 'fulfilled' &&
                datadriftResult.value?.data
                    ? {
                          ...datadriftResult.value.data,
                          files: Array.isArray(datadriftResult.value.data.files)
                              ? datadriftResult.value.data.files
                              : [],
                      }
                    : { files: [] }

            return {
                fairness,
                datadrift,
                regression,
                classification,
                all: [
                    ...fairness.files,
                    ...datadrift.files,
                    ...regression.files,
                    ...classification.files,
                ],
            }
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch datasets'
            )
        }
    }
)

export const fetchDataPreview = createAsyncThunk(
    'fairness/fetchDataPreview',

    async (_, thunkAPI) => {
        const file = thunkAPI.getState().fairness?.datasets?.fairness?.files[0]
        try {
            const token = thunkAPI.getState().auth.token
            const response = await axios.get(
                `${BASE_URL}/fairness/preview_dataset`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    params: {
                        file_url: file.url,
                    },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch datasets'
            )
        }
    }
)

export const fetchFairnessHealth = createAsyncThunk(
    'fairness/fetchFairnessHealth',
    async (_, thunkAPI) => {
        try {
            const token = localStorage.getItem('token')
            const response = await axios.get(`${BASE_URL}/fairness/health`, {
                headers: { Authorization: `Bearer ${token}` },
            })
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Fairness service health check failed'
            )
        }
    }
)

export const fetchAllFairnessData = createAsyncThunk(
    'fairness/fetchAll',
    async (_, { dispatch }) => {
        await Promise.all([
            dispatch(fetchMitigationStrategies()),
            dispatch(fetchDatasets()),
            dispatch(fetchFairnessHealth()),
        ])
    }
)

// Initial state
const initialState = {
    health: null,
    mitigationStrategies: [],
    datasets: [],
    dataPreview: null,
    fairnessAnalysis: null,
    loading: false,
    error: null,
}

const fairnessSlice = createSlice({
    name: 'fairness',
    initialState,
    reducers: {
        setFairnessAnalysis: (state, action) => {
            state.fairnessAnalysis = action.payload
        },
        setFairnessAnalysisLoading: (state, action) => {
            state.loading = action.payload
        },
    },
    extraReducers: (builder) => {
        // Mitigation Strategies
        builder
            .addCase(fetchMitigationStrategies.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchMitigationStrategies.fulfilled, (state, action) => {
                state.loading = false
                state.mitigationStrategies = action.payload.strategies || []
            })
            .addCase(fetchMitigationStrategies.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Datasets
            .addCase(fetchDatasets.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchDatasets.fulfilled, (state, action) => {
                state.loading = false
                state.datasets = action.payload || []
            })
            .addCase(fetchDatasets.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            .addCase(fetchDataPreview.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchDataPreview.fulfilled, (state, action) => {
                state.loading = false
                state.dataPreview = action.payload || []
            })
            .addCase(fetchDataPreview.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Health
            .addCase(fetchFairnessHealth.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchFairnessHealth.fulfilled, (state, action) => {
                state.loading = false
                state.health = action.payload
            })
            .addCase(fetchFairnessHealth.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
    },
})

export const { setFairnessAnalysis, setFairnessAnalysisLoading } =
    fairnessSlice.actions

export default fairnessSlice.reducer
