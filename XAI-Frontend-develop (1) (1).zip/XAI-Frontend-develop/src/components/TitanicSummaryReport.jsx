import React from 'react'
import {
    Card,
    CardContent,
    Typography,
    Divider,
    Box,
    Button,
    List, // Import List for structured lists
    ListItem, // Import ListItem
    ListItemIcon, // Import ListItemIcon
    ListItemText, // Import ListItemText
    Stack, // For consistent vertical/horizontal spacing
    Grid, // For structured layout of metrics
    useTheme, // To access theme properties
} from '@mui/material'

// Import Icons
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutline' // For insights/features
import BarChartIcon from '@mui/icons-material/BarChart' // For feature importance
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents' // For model performance
import InsightsIcon from '@mui/icons-material/Insights' // For LLM observations
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined' // For general info/executive summary
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
const TitanicSummaryReport = () => {
    const theme = useTheme() // Access the theme

    return (
        <Card
            sx={{
                mx: 'auto', // Center the card
                my: { xs: 2, md: 4 }, // Responsive vertical margin
                p: { xs: 2, sm: 3, md: 4 }, // Responsive padding

                bgcolor: theme.palette.background.paper, // Ensure background is paper color
                overflow: 'hidden', // Hide any potential overflow from rounded corners
            }}
        >
            {/* Header Section */}
            <Box
                sx={{
                    bgcolor: theme.palette.primary.light, // Light primary background
                    py: { xs: 2, sm: 3 }, // Vertical padding
                    px: { xs: 2, sm: 4 }, // Horizontal padding
                    mb: { xs: 2, sm: 4 }, // Margin bottom
                    borderRadius: theme.shape.borderRadius, // Rounded corners for header box
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    gap: 2, // Space between icon and text
                }}
            >
                <Stack flexDirection="row">
                    <InsightsIcon
                        sx={{
                            fontSize: { xs: 36, sm: 48 },
                            color: theme.palette.primary.dark,
                        }}
                    />
                    <Typography
                        variant="h4"
                        component="h1"
                        sx={{
                            fontWeight: 700,
                            color: theme.palette.text.primary,
                        }}
                    >
                        Titanic Dataset Analysis Summary
                    </Typography>
                </Stack>
                <Button variant="contained" startIcon={<PlayArrowIcon />}>
                    Explain with AI
                </Button>
            </Box>

            <CardContent sx={{ p: 0 }}>
                {' '}
                {/* Reset CardContent padding to manage it manually */}
                {/* Executive Summary Section */}
                <Stack
                    direction="row"
                    alignItems="center"
                    spacing={1}
                    sx={{ mb: 2 }}
                >
                    <InfoOutlinedIcon color="info" />
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                            color: theme.palette.text.primary,
                        }}
                    >
                        Executive Summary
                    </Typography>
                </Stack>
                <Typography
                    paragraph
                    sx={{
                        lineHeight: 1.7,
                        color: theme.palette.text.secondary,
                    }}
                >
                    The Titanic dataset, comprising demographic and travel
                    information for passengers aboard the RMS Titanic, serves as
                    a classic benchmark for predictive modeling. This
                    comprehensive analysis focuses on predicting survival
                    likelihood based on critical features such as age, gender,
                    passenger class, and family relations. Our advanced machine
                    learning models consistently reveal that socio-economic
                    status and gender were the predominant factors influencing
                    survival outcomes during the disaster.
                </Typography>
                <Divider
                    sx={{
                        my: { xs: 3, sm: 4 },
                        borderColor: theme.palette.grey[300],
                    }}
                />
                {/* Key Insights Section */}
                <Stack
                    direction="row"
                    alignItems="center"
                    spacing={1}
                    sx={{ mb: 2 }}
                >
                    <InsightsIcon color="success" />
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                            color: theme.palette.text.primary,
                        }}
                    >
                        Key Insights
                    </Typography>
                </Stack>
                <List disablePadding>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="primary"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            Overall survival rate:{' '}
                            <Typography
                                component="span"
                                variant="body1"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.success.main,
                                }}
                            >
                                38.4%
                            </Typography>
                        </ListItemText>
                    </ListItem>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="primary"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            Women had a significantly higher survival rate (≈{' '}
                            <Typography
                                component="span"
                                variant="body1"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.success.main,
                                }}
                            >
                                74%
                            </Typography>
                            ) compared to men (≈{' '}
                            <Typography
                                component="span"
                                variant="body1"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.error.main,
                                }}
                            >
                                19%
                            </Typography>
                            ).
                        </ListItemText>
                    </ListItem>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="primary"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            First-class passengers demonstrated the highest
                            survival rate at{' '}
                            <Typography
                                component="span"
                                variant="body1"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.success.main,
                                }}
                            >
                                63%
                            </Typography>
                            .
                        </ListItemText>
                    </ListItem>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="primary"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            Children (
                            <Typography
                                component="span"
                                variant="body1"
                                sx={{ fontWeight: 'bold' }}
                            >
                                &lt;10 years
                            </Typography>
                            ) also exhibited a relatively high survival rate.
                        </ListItemText>
                    </ListItem>
                </List>
                <Divider
                    sx={{
                        my: { xs: 3, sm: 4 },
                        borderColor: theme.palette.grey[300],
                    }}
                />
                {/* Feature Importance Section */}
                <Stack
                    direction="row"
                    alignItems="center"
                    spacing={1}
                    sx={{ mb: 2 }}
                >
                    <BarChartIcon color="primary" />
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                            color: theme.palette.text.primary,
                        }}
                    >
                        Feature Importance
                    </Typography>
                </Stack>
                <List disablePadding>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="action"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.primary.dark,
                                }}
                            >
                                Sex
                            </Typography>{' '}
                            — The most significant predictor of survival,
                            aligning with 'women and children first' protocols.
                        </ListItemText>
                    </ListItem>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="action"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.primary.dark,
                                }}
                            >
                                Pclass
                            </Typography>{' '}
                            — First class status was strongly associated with
                            higher survival odds.
                        </ListItemText>
                    </ListItem>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="action"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.primary.dark,
                                }}
                            >
                                Age
                            </Typography>{' '}
                            — Younger passengers generally had higher survival
                            rates.
                        </ListItemText>
                    </ListItem>
                    <ListItem disablePadding sx={{ py: 0.5 }}>
                        <ListItemIcon sx={{ minWidth: 35 }}>
                            <CheckCircleOutlineIcon
                                color="action"
                                fontSize="small"
                            />
                        </ListItemIcon>
                        <ListItemText>
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.primary.dark,
                                }}
                            >
                                SibSp & Parch
                            </Typography>{' '}
                            — Passengers with larger family groups aboard
                            experienced lower survival chances.
                        </ListItemText>
                    </ListItem>
                </List>
                <Divider
                    sx={{
                        my: { xs: 3, sm: 4 },
                        borderColor: theme.palette.grey[300],
                    }}
                />
                {/* Model Performance Summary Section */}
                <Stack
                    direction="row"
                    alignItems="center"
                    spacing={1}
                    sx={{ mb: 2 }}
                >
                    <EmojiEventsIcon color="secondary" />
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                            color: theme.palette.text.primary,
                        }}
                    >
                        Model Performance Summary
                    </Typography>
                </Stack>
                <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                        <Typography
                            variant="body1"
                            sx={{
                                fontWeight: 500,
                                color: theme.palette.text.primary,
                            }}
                        >
                            Model Used:{' '}
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.primary.main,
                                }}
                            >
                                Random Forest Classifier
                            </Typography>
                        </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <Typography
                            variant="body1"
                            sx={{
                                fontWeight: 500,
                                color: theme.palette.text.primary,
                            }}
                        >
                            Accuracy:{' '}
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.success.main,
                                }}
                            >
                                82.6%
                            </Typography>
                        </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <Typography
                            variant="body1"
                            sx={{
                                fontWeight: 500,
                                color: theme.palette.text.primary,
                            }}
                        >
                            Precision:{' '}
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.info.main,
                                }}
                            >
                                78.4%
                            </Typography>
                        </Typography>
                    </Grid>
                    <Grid item xs={12} sm={6}>
                        <Typography
                            variant="body1"
                            sx={{
                                fontWeight: 500,
                                color: theme.palette.text.primary,
                            }}
                        >
                            Recall:{' '}
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.info.main,
                                }}
                            >
                                76.1%
                            </Typography>
                        </Typography>
                    </Grid>
                    <Grid item xs={12}>
                        <Typography
                            variant="body1"
                            sx={{
                                fontWeight: 500,
                                color: theme.palette.text.primary,
                            }}
                        >
                            AUC-ROC:{' '}
                            <Typography
                                component="span"
                                sx={{
                                    fontWeight: 'bold',
                                    color: theme.palette.warning.main,
                                }}
                            >
                                0.87
                            </Typography>{' '}
                            (indicating strong model separation)
                        </Typography>
                    </Grid>
                </Grid>
                <Divider
                    sx={{
                        my: { xs: 3, sm: 4 },
                        borderColor: theme.palette.grey[300],
                    }}
                />
                {/* LLM Observations Section */}
                <Stack
                    direction="row"
                    alignItems="center"
                    spacing={1}
                    sx={{ mb: 2 }}
                >
                    <EmojiEventsIcon color="action" />
                    <Typography
                        variant="h6"
                        sx={{
                            fontWeight: 600,
                            color: theme.palette.text.primary,
                        }}
                    >
                        AI Interpretations
                    </Typography>
                </Stack>
                <Typography
                    paragraph
                    sx={{
                        lineHeight: 1.7,
                        color: theme.palette.text.secondary,
                    }}
                >
                    Based on linguistic and statistical reasoning, the dataset
                    demonstrates clear patterns related to social hierarchy and
                    gender norms prevalent during the Titanic disaster. The
                    model's behavior suggests that the 'women and children
                    first' directive played a significant role, particularly for
                    those in higher social strata. The strong interaction
                    between `Pclass` and `Sex` explicitly highlights how both
                    wealth and gender collectively influenced survival outcomes.
                    Note that the handling of missing values, especially in
                    `Age` and `Cabin`, required careful imputation or removal,
                    which could subtly influence specific model reliability
                    aspects in edge-case scenarios.
                </Typography>
                {/* Footer and Button */}
                <Box
                    sx={{
                        mt: { xs: 3, sm: 4 },
                        display: 'flex',
                        justifyContent: 'space-between',
                        alignItems: 'flex-end',
                        flexWrap: 'wrap',
                        gap: 2,
                    }}
                >
                    <Button
                        variant="contained"
                        href="/dashboard"
                        sx={{
                            fontWeight: 'bold',
                            textTransform: 'none',
                            px: { xs: 3, sm: 4 }, // More padding
                            py: { xs: 1, sm: 1.5 }, // More padding
                            fontSize: { xs: '0.9rem', sm: '1rem' },
                            borderRadius: theme.shape.borderRadius * 2, // Match card rounding
                            boxShadow: theme.shadows[4], // Stronger shadow
                            '&:hover': {
                                boxShadow: theme.shadows[6],
                            },
                        }}
                    >
                        Go To Dashboard
                    </Button>
                    <Typography
                        variant="caption"
                        color="text.secondary"
                        sx={{
                            textAlign: 'right',
                            flexGrow: 1,
                            mt: { xs: 2, sm: 0 },
                        }}
                    >
                        Report Generated:{' '}
                        {new Date().toLocaleDateString('en-US', {
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                        })}{' '}
                        <br />
                        <Typography
                            component="span"
                            sx={{
                                color: theme.palette.primary.main,
                                fontWeight: 'bold',
                            }}
                        >
                            LLM-Powered Automated Analysis
                        </Typography>
                    </Typography>
                </Box>
            </CardContent>
        </Card>
    )
}

export default TitanicSummaryReport
