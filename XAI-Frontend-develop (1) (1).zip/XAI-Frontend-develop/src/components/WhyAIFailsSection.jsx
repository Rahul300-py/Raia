// src/components/WhyAIFailsSection.js
import React from 'react'
import { Box, Typography, Container, Grid, Stack } from '@mui/material'
import EmojiObjectsOutlinedIcon from '@mui/icons-material/EmojiObjectsOutlined' // Placeholder icon
import BorderClearOutlinedIcon from '@mui/icons-material/BorderClearOutlined' // Placeholder icon
import DataUsageOutlinedIcon from '@mui/icons-material/DataUsageOutlined' // Placeholder icon

const WhyAIFailsSection = () => {
    return (
        <Box
            sx={{
                backgroundColor: '#f1f3f6',
                py: { xs: 8, md: 12 },
                width: '100%',
            }}
        >
            <Container maxWidth="lg">
                <Grid container spacing={5} alignItems="center">
                    <Grid item xs={12} md={6}>
                        <Typography
                            variant="overline"
                            display="block"
                            color="error.main"
                            sx={{ mb: 2, textTransform: 'uppercase' }}
                        >
                            Why AI Testing Matters
                        </Typography>
                        <Typography
                            variant="h3"
                            component="h2"
                            sx={{ fontWeight: 'bold', lineHeight: 1.2 }}
                        >
                            AI{' '}
                            <Box
                                component="span"
                                sx={{ color: 'secondary.main' }}
                            >
                                fails differently
                            </Box>
                        </Typography>
                    </Grid>
                    <Grid item xs={12} md={6}>
                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary' }}
                        >
                            Non-deterministic AI systems break in ways
                            traditional software doesn't.
                        </Typography>
                    </Grid>
                </Grid>

                <Grid container spacing={4} sx={{ mt: { xs: 5, md: 8 } }}>
                    <Grid item xs={12} sm={6} md={4}>
                        <Stack spacing={2}>
                            <EmojiObjectsOutlinedIcon
                                sx={{ fontSize: 40, color: 'highlight.main' }}
                            />
                            <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                Hallucinations
                            </Typography>
                            <Typography
                                variant="body2"
                                sx={{ color: 'text.secondary' }}
                            >
                                LLMs confidently make things up
                            </Typography>
                        </Stack>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                        <Stack spacing={2}>
                            <BorderClearOutlinedIcon
                                sx={{ fontSize: 40, color: 'highlight.main' }}
                            />
                            <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                Edge cases
                            </Typography>
                            <Typography
                                variant="body2"
                                sx={{ color: 'text.secondary' }}
                            >
                                Unexpected inputs bring the quality down.
                            </Typography>
                        </Stack>
                    </Grid>
                    <Grid item xs={12} sm={6} md={4}>
                        <Stack spacing={2}>
                            <DataUsageOutlinedIcon
                                sx={{ fontSize: 40, color: 'highlight.main' }}
                            />
                            <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                Data & PII leaks
                            </Typography>
                            <Typography
                                variant="body2"
                                sx={{ color: 'text.secondary' }}
                            >
                                Sensitive data slips into responses.
                            </Typography>
                        </Stack>
                    </Grid>
                </Grid>
            </Container>
        </Box>
    )
}

export default WhyAIFailsSection
