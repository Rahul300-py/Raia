// src/index.js (or src/main.jsx for Vite)
import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import { Provider } from 'react-redux'
import { store } from './store/store' // Assuming this path is correct

// Material-UI imports
import { ThemeProvider } from '@mui/material/styles'
import CssBaseline from '@mui/material/CssBaseline' // Optional: for consistent baseline styles
import theme from './theme' // Import your custom MUI theme

ReactDOM.createRoot(document.getElementById('root')).render(
    <>
        <ThemeProvider theme={theme}>
            <CssBaseline />
            <Provider store={store}>
                <App />
            </Provider>
        </ThemeProvider>
    </>
)
