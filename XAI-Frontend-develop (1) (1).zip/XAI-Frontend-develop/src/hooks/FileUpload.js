import { useState, useEffect, useRef } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { uploadFiles, clearUploadStatus } from '../store/uploadSlice'
import {
    showSuccessToast,
    showErrorToast,
    showInfoToast,
} from '../utils/toastUtility'

export const useFileUpload = () => {
    const dispatch = useDispatch()
    const { success, error, loading } = useSelector((state) => state.upload)
    const { user } = useSelector((state) => state.auth)

    const fileInputRef = useRef()

    const [fileState, setFileState] = useState({
        train: null,
        test: null,
        combined: null,
    })

    const [fairnessfileState, setFairnessfileState] = useState({
        train: null,
        test: null,
        model: null,
    })

    const [percentage, setPercentage] = useState(70)
    const [modelFormat, setModelFormat] = useState('pkl')

    // Handle file selection
    const handleFileChange = (e, type) => {
        const file = e.target.files[0]
        if (file) {
            setFileState((prev) => ({ ...prev, [type]: file }))
        }
    }

    const handleFairnessFileChange = (e, type, modelFormat) => {
        const file = e.target.files[0]
        if (file) {
            setFairnessfileState((prev) => ({ ...prev, [type]: file }))
        }
    }

    // File browsing handlers
    const handleBrowse = (type) => {
        const input = document.createElement('input')
        input.type = 'file'
        input.accept = '.csv'
        input.onchange = (e) => handleFileChange(e, type)
        input.click()
    }

    const handleBrowseFairness = (type, modelFormat) => {
        const input = document.createElement('input')
        input.type = 'file'
        if (modelFormat) {
            input.accept =
                modelFormat === 'onnx'
                    ? '.onnx'
                    : modelFormat === 'pkl'
                      ? '.pkl'
                      : '.joblib'
        } else {
            input.accept = '.csv'
        }

        input.onchange = (e) => handleFairnessFileChange(e, type, modelFormat)
        input.click()
    }

    const handleButtonClick = () => {
        fileInputRef.current.click()
    }

    // Save handlers for different analysis types
    const handleSave = () => {
        const fileList = []
        const newFiles = []

        if (fileState.combined) {
            fileList.push(fileState.combined)
            newFiles.push({
                name: fileState.combined.name,
                type: 'combined',
                timestamp: Date.now(),
            })
        } else {
            if (fileState.train) {
                fileList.push(fileState.train)
                newFiles.push({
                    name: fileState.train.name,
                    type: 'train',
                    timestamp: Date.now(),
                })
            }
            if (fileState.test) {
                fileList.push(fileState.test)
                newFiles.push({
                    name: fileState.test.name,
                    type: 'test',
                    timestamp: Date.now(),
                })
            }
        }

        if (fileList.length === 0) {
            showInfoToast('Please select at least one file.')
            return
        }

        dispatch(
            uploadFiles({
                user_id: user?.user_id,
                tenant_id: user?.tenant_id,
                files: fileList,
                analysis_type: 'Data Drift',
            })
        )
    }

    const handleSavefairnessData = () => {
        const fileList = []
        const newFiles = []

        if (fairnessfileState.train) {
            fileList.push(fairnessfileState.train)
            newFiles.push({
                name: fairnessfileState.train.name,
                type: 'train',
                timestamp: Date.now(),
            })
        }
        if (fairnessfileState.test) {
            fileList.push(fairnessfileState.test)
            newFiles.push({
                name: fairnessfileState.test.name,
                type: 'test',
                timestamp: Date.now(),
            })
        }
        if (fairnessfileState.model) {
            fileList.push(fairnessfileState.model)
            newFiles.push({
                name: fairnessfileState.model.name,
                type: 'model',
                timestamp: Date.now(),
            })
        }

        if (fileList.length === 0) {
            showInfoToast('Please select at least one file.')
            return
        }

        dispatch(
            uploadFiles({
                user_id: user?.user_id,
                tenant_id: user?.tenant_id,
                files: fileList,
                analysis_type: 'Fairness',
            })
        )
    }

    const handleSaveRegressionData = () => {
        const fileList = []
        const newFiles = []

        if (fairnessfileState.train) {
            fileList.push(fairnessfileState.train)
            newFiles.push({
                name: fairnessfileState.train.name,
                type: 'train',
                timestamp: Date.now(),
            })
        }
        if (fairnessfileState.test) {
            fileList.push(fairnessfileState.test)
            newFiles.push({
                name: fairnessfileState.test.name,
                type: 'test',
                timestamp: Date.now(),
            })
        }
        if (fairnessfileState.model) {
            fileList.push(fairnessfileState.model)
            newFiles.push({
                name: fairnessfileState.model.name,
                type: 'model',
                timestamp: Date.now(),
            })
        }

        if (fileList.length === 0) {
            showInfoToast('Please select at least one file.')
            return
        }

        dispatch(
            uploadFiles({
                user_id: user?.user_id,
                tenant_id: user?.tenant_id,
                files: fileList,
                analysis_type: 'Regression',
            })
        )
    }

    const handleSaveClassificationData = () => {
        const fileList = []
        const newFiles = []

        if (fairnessfileState.train) {
            fileList.push(fairnessfileState.train)
            newFiles.push({
                name: fairnessfileState.train.name,
                type: 'train',
                timestamp: Date.now(),
            })
        }
        if (fairnessfileState.test) {
            fileList.push(fairnessfileState.test)
            newFiles.push({
                name: fairnessfileState.test.name,
                type: 'test',
                timestamp: Date.now(),
            })
        }
        if (fairnessfileState.model) {
            fileList.push(fairnessfileState.model)
            newFiles.push({
                name: fairnessfileState.model.name,
                type: 'model',
                timestamp: Date.now(),
            })
        }

        if (fileList.length === 0) {
            showInfoToast('Please select at least one file.')
            return
        }

        dispatch(
            uploadFiles({
                user_id: user?.user_id,
                tenant_id: user?.tenant_id,
                files: fileList,
                analysis_type: 'Classification',
            })
        )
    }

    // Handle upload status effects
    useEffect(() => {
        if (success) {
            showSuccessToast('Files uploaded successfully!')
            dispatch(clearUploadStatus())
            setFileState({ train: null, test: null, combined: null })
        } else if (error) {
            showErrorToast(`Upload failed: ${error}`)
            dispatch(clearUploadStatus())
        }
    }, [success, error, dispatch])

    return {
        // State
        fileState,
        fairnessfileState,
        percentage,
        setPercentage,
        modelFormat,
        setModelFormat,
        loading,
        fileInputRef,

        // Handlers
        handleFileChange,
        handleFairnessFileChange,
        handleBrowse,
        handleBrowseFairness,
        handleButtonClick,
        handleSave,
        handleSavefairnessData,
        handleSaveRegressionData,
        handleSaveClassificationData,
    }
}
