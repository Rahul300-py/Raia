/* eslint-disable no-unused-vars */
import React, { useEffect, useRef, useState } from 'react'
import {
    Box,
    Typography,
    Tabs,
    Tab,
    Paper,
    Button,
    LinearProgress,
    Container,
    TextField,
    Stack,
    Grid,
    Divider,
    useTheme,
    useMediaQuery,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    IconButton,
    TextareaAutosize,
} from '@mui/material'

import UploadFileIcon from '@mui/icons-material/UploadFile'
import CloudUploadIcon from '@mui/icons-material/CloudUpload'
import StorageIcon from '@mui/icons-material/Storage'

import ConfigureDataStep from '../components/ConfigureDataStep'
import SelectFeaturesStep from '../components/SelectFeaturesStep'

import DashboardNavBar from '../components/DashboardNavbar'
import { useNavigate } from 'react-router-dom'
import { ArrowBack, ArrowDropDown, ArrowDropUp } from '@mui/icons-material'
import {
    showErrorToast,
    showInfoToast,
    showSuccessToast,
} from '../utils/toastUtility'
import { clearUploadStatus, uploadFiles } from '../store/uploadSlice'
import { useDispatch, useSelector } from 'react-redux'
import { fetchFullLLMDrift } from '../store/llmSlice'
import SummaryReport from '../components/SummaryReport'

function NewAnalysis() {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const { success, error, loading } = useSelector((state) => state.upload)
    const { user } = useSelector((state) => state.auth) // assumes user.id and user.tenantId are present
    const [step, setStep] = useState(0)
    const [uploadProgress, setUploadProgress] = useState(1)
    const { fullDriftAnalysis } = useSelector((state) => state.llm)
    const [selectedDbType, setSelectedDbType] = useState('')
    const [selectedCloudProvider, setSelectedCloudProvider] = useState('')
    const [showDBForm, setShowDBForm] = useState(false)
    const [connectionDetails, setConnectionDetails] = useState({
        host: '',
        port: '',
        database: '',
        username: '',
        password: '',
        region: '',
        connectionString: '',
        serverName: '',
    })

    const theme = useTheme()
    const isSmallScreen = useMediaQuery(theme.breakpoints.down('sm'))
    const isMediumScreen = useMediaQuery(theme.breakpoints.down('md'))
    const [fileState, setFileState] = useState({
        train: null,
        test: null,
        combined: null,
    })
    const [percentage, setPercentage] = useState(50)

    const fileInputRef = useRef()

    const handleButtonClick = () => {
        fileInputRef.current.click() // Trigger file input
    }

    const handleFileChange = (e, type) => {
        const file = e.target.files[0]
        if (file) {
            setFileState((prev) => ({ ...prev, [type]: file }))
        }
    }
    const handleTabChange = (event, newValue) => {
        setStep(newValue)
    }
    const handleNext = () => {
        if (step === 0) {
            const fileList = []

            if (fileState.combined) {
                fileList.push(fileState.combined)
            } else {
                if (fileState.train) fileList.push(fileState.train)
                if (fileState.test) fileList.push(fileState.test)
            }

            if (fileList.length === 0) {
                showInfoToast('Please select at least one file.')
                return // Do NOT proceed to the next step
            }

            handleSave() // Optional: if you want to save before proceeding
        }

        if (step === 1 && !fullDriftAnalysis) {
            dispatch(fetchFullLLMDrift())
        }

        // Only go to next step if step 0 passed validation or not step 0
        if (
            step !== 0 ||
            fileState.combined ||
            fileState.train ||
            fileState.test
        ) {
            setStep((prev) => prev + 1)
        }
    }

    const handleBack = () => {
        setStep((prevStep) => prevStep - 1)
    }

    const handleDbChange = (event) => {
        setSelectedDbType(event.target.value)
        setConnectionDetails({
            ...connectionDetails,
            connectionString: '',
            host: '',
            port: '',
            database: '',
            username: '',
            password: '',
            serverName: '',
            region: '',
        })
    }

    const handleCloudProviderChange = (event) => {
        setSelectedCloudProvider(event.target.value)
        setConnectionDetails({
            ...connectionDetails,
            connectionString: '',
            host: '',
            port: '',
            database: '',
            username: '',
            password: '',
            serverName: '',
            region: '',
        })
    }

    const handleConnectionDetailsChange = (event) => {
        setConnectionDetails({
            ...connectionDetails,
            [event.target.name]: event.target.value,
        })
    }

    const renderDatabaseFields = () => {
        if (!selectedDbType && !selectedCloudProvider) {
            return (
                <Typography
                    variant="body2"
                    color="text.secondary"
                    sx={{ mt: 2 }}
                >
                    Please select a database type and cloud provider to proceed.
                </Typography>
            )
        }

        const genericFields = (
            <>
                <Box
                    sx={{
                        display: 'flex',
                        gap: 2,
                        mb: 2,
                        width: '100%',
                    }}
                >
                    <TextField
                        label="Database Name"
                        name="database"
                        value={connectionDetails.database}
                        onChange={handleConnectionDetailsChange}
                        fullWidth
                        size="medium"
                        sx={{ mb: 2 }}
                    />
                    <TextField
                        label="Host"
                        name="host"
                        value={connectionDetails.host}
                        onChange={handleConnectionDetailsChange}
                        fullWidth
                        size="medium"
                    />
                    <TextField
                        label="Port"
                        name="port"
                        value={connectionDetails.port}
                        onChange={handleConnectionDetailsChange}
                        fullWidth
                        size="medium"
                    />
                </Box>

                <Box sx={{ display: 'flex', gap: 2, width: '100%' }}>
                    <TextField
                        label="Username"
                        name="username"
                        value={connectionDetails.username}
                        onChange={handleConnectionDetailsChange}
                        fullWidth
                        size="medium"
                    />
                    <TextField
                        label="Password"
                        name="password"
                        value={connectionDetails.password}
                        onChange={handleConnectionDetailsChange}
                        type="password"
                        fullWidth
                        size="medium"
                    />
                </Box>
            </>
        )

        if (selectedCloudProvider === 'AWS') {
            return (
                <>
                    {genericFields}
                    <TextField
                        label="AWS Region"
                        name="region"
                        value={connectionDetails.region}
                        onChange={handleConnectionDetailsChange}
                        fullWidth
                        size="medium"
                        sx={{ mt: 2 }}
                    />
                </>
            )
        } else if (selectedCloudProvider === 'Azure') {
            if (selectedDbType === 'SQL_SERVER') {
                return (
                    <>
                        <Box
                            sx={{
                                display: 'flex',
                                gap: 2,
                                mb: 2,
                                width: '100%',
                            }}
                        >
                            <TextField
                                label="Server Name"
                                name="serverName"
                                value={connectionDetails.serverName}
                                onChange={handleConnectionDetailsChange}
                                fullWidth
                                size="medium"
                                sx={{ mb: 2 }}
                            />
                            <TextField
                                label="Database Name"
                                name="database"
                                value={connectionDetails.database}
                                onChange={handleConnectionDetailsChange}
                                fullWidth
                                size="medium"
                                sx={{ mb: 2 }}
                            />
                        </Box>
                        <Box
                            sx={{
                                display: 'flex',
                                gap: 2,
                                mb: 2,
                                width: '100%',
                            }}
                        >
                            <TextField
                                label="Username"
                                name="username"
                                value={connectionDetails.username}
                                onChange={handleConnectionDetailsChange}
                                fullWidth
                                size="medium"
                                sx={{ mb: 2 }}
                            />
                            <TextField
                                label="Password"
                                name="password"
                                value={connectionDetails.password}
                                onChange={handleConnectionDetailsChange}
                                type="password"
                                fullWidth
                                size="medium"
                            />
                        </Box>
                    </>
                )
            }
            return genericFields
        } else if (selectedCloudProvider === 'GCP') {
            return (
                <>
                    {genericFields}
                    <TextField
                        label="GCP Project ID (Optional)"
                        name="projectId"
                        value={connectionDetails.projectId}
                        onChange={handleConnectionDetailsChange}
                        fullWidth
                        size="medium"
                        sx={{ mt: 2 }}
                    />
                </>
            )
        } else if (selectedCloudProvider === 'MONGO_ATLAS') {
            return (
                <TextField
                    label="MongoDB Atlas Connection String"
                    name="connectionString"
                    value={connectionDetails.connectionString}
                    onChange={handleConnectionDetailsChange}
                    fullWidth
                    multiline
                    rows={3}
                    size="medium"
                    placeholder="mongodb+srv://<username>:<password>@cluster.mongodb.net/..."
                />
            )
        } else if (
            selectedCloudProvider === 'OTHER' ||
            selectedCloudProvider === 'ON_PREMISE'
        ) {
            if (selectedDbType === 'MONGODB') {
                return (
                    <>
                        <TextField
                            label="Host"
                            name="host"
                            value={connectionDetails.host}
                            onChange={handleConnectionDetailsChange}
                            fullWidth
                            size="medium"
                            sx={{ mb: 2 }}
                        />
                        <TextField
                            label="Port"
                            name="port"
                            value={connectionDetails.port}
                            onChange={handleConnectionDetailsChange}
                            fullWidth
                            size="medium"
                            sx={{ mb: 2 }}
                        />
                        <TextField
                            label="Database Name"
                            name="database"
                            value={connectionDetails.database}
                            onChange={handleConnectionDetailsChange}
                            fullWidth
                            size="medium"
                            sx={{ mb: 2 }}
                        />
                        <TextField
                            label="Username (Optional)"
                            name="username"
                            value={connectionDetails.username}
                            onChange={handleConnectionDetailsChange}
                            fullWidth
                            size="medium"
                            sx={{ mb: 2 }}
                        />
                        <TextField
                            label="Password (Optional)"
                            name="password"
                            value={connectionDetails.password}
                            onChange={handleConnectionDetailsChange}
                            type="password"
                            fullWidth
                            size="medium"
                        />
                    </>
                )
            }
            return genericFields
        }

        return genericFields
    }

    const handleGoBack = () => {
        navigate(-1) // Go to previous page
    }

    // Unified style for the "modern & classic" cards
    const getModernClassicCardStyles = (
        colorPalette,
        isSmallScreen,
        currentTheme,
        isFormCard = false
    ) => ({
        border: 'none', // Rely on shadows for depth
        display: 'flex',
        flexDirection: 'column',
        justifyContent: 'center', // Center content vertically
        alignItems: 'center',
        textAlign: 'center',
        p: { xs: 3, sm: isFormCard ? 5 : 4, md: isFormCard ? 6 : 5 }, // More padding for form card
        minHeight: isFormCard
            ? isSmallScreen
                ? 350
                : isMediumScreen
                  ? 400
                  : 450 // Taller for form
            : isSmallScreen
              ? 200
              : isMediumScreen
                ? 250
                : 300, // Taller for upload
        bgcolor: currentTheme.palette.background.paper, // Use theme's paper background
        borderRadius: currentTheme.shape.borderRadius * 2, // Consistent moderate rounding
        transition: 'box-shadow 0.3s ease-in-out, transform 0.3s ease-in-out',
        boxShadow: currentTheme.shadows[6], // More pronounced initial shadow
        '&:hover': {
            boxShadow: currentTheme.shadows[10], // Deeper shadow on hover
            transform: 'translateY(-3px)', // More pronounced lift
        },
    })

    const Step0Content = () => (
        <Grid container spacing={2} sx={{ my: 2 }}>
            {/* Section Title for Uploads */}

            {/* Group for Data and Model Upload Cards - Nested Grid */}
            <Grid item xs={12} width="100%">
                <Grid container spacing={2}>
                    <Grid item xs={12} lg={6} flex={1}>
                        {/* Data Upload Card */}
                        <Paper
                            elevation={0}
                            sx={{
                                borderRadius: 1,
                                p: 4,
                                boxShadow: 0,
                                border: '2px dotted grey',
                            }}
                        >
                            <Stack spacing={2} alignItems="center">
                                <Typography
                                    variant="h5"
                                    fontWeight={600}
                                    color="text.primary"
                                >
                                    <UploadFileIcon
                                        sx={{
                                            fontSize: 24,
                                            color: theme.palette.secondary
                                                .light,
                                        }}
                                    />
                                    Upload Dataset
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                >
                                    Drag and drop your dataset file here.
                                    <br />
                                    Supported formats: CSV, TXT, JSON.
                                </Typography>
                                {/* <Button
                                    variant="outlined"
                                    color="secondary" // Use theme's primary color
                                    sx={{
                                        fontWeight: 'bold',
                                        textTransform: 'none',
                                        mt: 2,
                                    }}
                                >
                                    Browse Files
                                </Button> */}
                                <Button
                                    variant="outlined"
                                    sx={{
                                        fontWeight: 'bold',
                                        textTransform: 'none',
                                        mt: 2,
                                    }}
                                    color="secondary"
                                    onClick={() => handleBrowse('train')}
                                >
                                    Browse files
                                </Button>
                                {fileState.train && (
                                    <Typography variant="caption">
                                        {fileState.train.name}
                                    </Typography>
                                )}
                            </Stack>
                        </Paper>
                    </Grid>

                    <Grid item xs={12} lg={6} flex={1}>
                        {/* Model Upload Card */}
                        <Paper
                            elevation={0}
                            sx={{
                                borderRadius: 1,
                                p: 4,
                                boxShadow: 0,
                                border: '2px dotted grey',
                            }}
                        >
                            <Stack spacing={2} alignItems="center">
                                <Typography
                                    variant="h5"
                                    fontWeight={600}
                                    color="text.primary"
                                >
                                    <CloudUploadIcon
                                        sx={{
                                            fontSize: 24,
                                            color: theme.palette.secondary
                                                .light, // Use secondary.main for more vibrancy
                                        }}
                                    />{' '}
                                    Upload Model
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                >
                                    Drag and drop your trained model file here.
                                    <br />
                                    Supported formats: Pickle, ONNX, PMML.
                                </Typography>
                                <Button
                                    variant="outlined"
                                    color="secondary" // Use theme's secondary color
                                    sx={{
                                        fontWeight: 'bold',
                                        textTransform: 'none',
                                        mt: 2,
                                    }}
                                >
                                    Browse Model File
                                </Button>
                            </Stack>
                        </Paper>
                    </Grid>
                </Grid>
            </Grid>

            <Grid item xs={12} width="100%">
                {/* Database Connection Card - Full Width */}
                <Paper
                    elevation={0}
                    sx={{
                        borderRadius: 1,
                        px: 4,
                        py: 2,
                        boxShadow: 0,
                        border: '2px dotted grey',
                    }}
                >
                    <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                        sx={{
                            width: '100%',
                            mb: showDBForm ? 4 : 0,
                            cursor: showDBForm ? 'auto' : 'pointer',
                        }}
                        onClick={() => {
                            if (!showDBForm) {
                                setShowDBForm(true)
                            }
                        }}
                    >
                        <Box display="flex" alignItems="center">
                            <StorageIcon
                                sx={{
                                    fontSize: 24,
                                    color: theme.palette.secondary.light, // Use info.main for more vibrancy
                                }}
                            />
                            <Typography
                                variant="h5"
                                fontWeight={600}
                                color="text.primary"
                                sx={{ ml: 2 }}
                            >
                                Connect to a Database
                            </Typography>
                        </Box>

                        <Button
                            onClick={() => setShowDBForm((prev) => !prev)}
                            sx={{ minWidth: 0 }}
                        >
                            {showDBForm ? (
                                <ArrowDropUp
                                    sx={{
                                        fontSize: 24,
                                        color: theme.palette.secondary.main,
                                    }}
                                />
                            ) : (
                                <ArrowDropDown
                                    sx={{
                                        fontSize: 24,
                                        color: theme.palette.secondary.main,
                                    }}
                                />
                            )}
                        </Button>
                    </Stack>

                    {showDBForm && (
                        <Stack
                            spacing={3}
                            alignItems="center"
                            sx={{ width: '100%', mx: 'auto' }}
                        >
                            {/* <Typography variant="body2" color="text.secondary">
                                Select your database type and cloud provider to
                                configure connection details.
                            </Typography> */}

                            <Grid
                                item
                                xs={12}
                                width="100%"
                                sx={{
                                    display: 'flex',
                                    flexDirection: 'row',
                                    justifyContent: 'space-between',
                                    mt: 1,
                                }}
                            >
                                <FormControl
                                    size="medium"
                                    sx={{ mb: 2, flex: 0.49 }}
                                >
                                    <InputLabel id="db-type-select-label">
                                        Database Type
                                    </InputLabel>
                                    <Select
                                        labelId="db-type-select-label"
                                        value={selectedDbType}
                                        label="Database Type"
                                        onChange={handleDbChange}
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value="POSTGRESQL">
                                            PostgreSQL
                                        </MenuItem>
                                        <MenuItem value="MYSQL">MySQL</MenuItem>
                                        <MenuItem value="SQL_SERVER">
                                            SQL Server
                                        </MenuItem>
                                        <MenuItem value="MONGODB">
                                            MongoDB
                                        </MenuItem>
                                        <MenuItem value="ORACLE">
                                            Oracle
                                        </MenuItem>
                                        <MenuItem value="GENERIC_JDBC">
                                            Generic JDBC
                                        </MenuItem>
                                    </Select>
                                </FormControl>

                                <FormControl
                                    size="medium"
                                    sx={{ mb: 2, flex: 0.49 }}
                                >
                                    <InputLabel id="cloud-provider-select-label">
                                        Cloud Provider / Location
                                    </InputLabel>
                                    <Select
                                        labelId="cloud-provider-select-label"
                                        value={selectedCloudProvider}
                                        label="Cloud Provider / Location"
                                        onChange={handleCloudProviderChange}
                                    >
                                        <MenuItem value="">
                                            <em>None</em>
                                        </MenuItem>
                                        <MenuItem value="AWS">AWS</MenuItem>
                                        <MenuItem value="Azure">Azure</MenuItem>
                                        <MenuItem value="GCP">
                                            Google Cloud Platform
                                        </MenuItem>
                                        <MenuItem value="MONGO_ATLAS">
                                            MongoDB Atlas
                                        </MenuItem>
                                        <MenuItem value="ON_PREMISE">
                                            On-Premise
                                        </MenuItem>
                                        <MenuItem value="OTHER">
                                            Other / Custom
                                        </MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>

                            <Divider sx={{ my: 2, width: '100%' }} />

                            {renderDatabaseFields()}

                            <Stack
                                sx={{
                                    width: '100%',
                                    flexDirection: 'row',
                                    justifyContent: 'flex-end',
                                }}
                            >
                                <Button
                                    variant="outlined"
                                    color="secondary"
                                    size="large"
                                    sx={{
                                        fontWeight: 'bold',
                                        textTransform: 'none',
                                        mt: 3,
                                    }}
                                    disabled={
                                        !selectedDbType &&
                                        !selectedCloudProvider
                                    }
                                >
                                    Test Connection
                                </Button>
                            </Stack>
                        </Stack>
                    )}
                </Paper>
            </Grid>

            <Grid item xs={12} width="100%">
                <Paper
                    elevation={0}
                    sx={{
                        boxShadow: 0,
                        // border: '2px dotted grey',
                    }}
                >
                    <Stack
                        sx={{
                            gap: 2,
                            flexDirection: 'row',
                            justifyContent: 'space-between',
                        }}
                    >
                        <TextField
                            placeholder="Enter your prompt"
                            size="medium"
                            fullWidth
                            label="Enter your prompt"
                        />
                        <FormControl size="medium" fullWidth>
                            <InputLabel id="db-type-select-label">
                                Select Problem Type
                            </InputLabel>
                            <Select
                                labelId="db-type-select-label"
                                value={selectedDbType}
                                label="Database Type"
                                onChange={handleDbChange}
                            >
                                <MenuItem value="">
                                    <em>None</em>
                                </MenuItem>
                                <MenuItem value="CLASSIFICATION">
                                    Classification Problem
                                </MenuItem>
                                <MenuItem value="REGRESSION">
                                    Regression Problem
                                </MenuItem>
                                <MenuItem value="CLUSTERING">
                                    Clustering Problem
                                </MenuItem>
                            </Select>
                        </FormControl>
                    </Stack>
                </Paper>
            </Grid>
            {/* Progress Section - Only visible if uploadProgress is not 100% or 0% */}
            {uploadProgress > 0 && uploadProgress < 100 && (
                <Grid item xs={12} width="100%">
                    <Box
                        sx={{
                            pt: 3,
                            pb: 2,
                        }}
                    >
                        <Typography
                            variant="body1"
                            sx={{
                                mb: 1.5,
                                color: theme.palette.text.primary,
                                fontWeight: 500,
                            }}
                        >
                            Processing Data & Model...
                        </Typography>
                        <LinearProgress
                            variant="determinate"
                            value={uploadProgress}
                            sx={{
                                height: 12,
                                borderRadius: 6,
                                bgcolor: theme.palette.grey[300],
                                '& .MuiLinearProgress-bar': {
                                    bgcolor: theme.palette.secondary.main,
                                    borderRadius: 6,
                                    transition: 'transform 0.5s linear',
                                },
                            }}
                        />
                        <Typography
                            variant="caption"
                            sx={{
                                mt: 1,
                                display: 'block',
                                color: theme.palette.text.primary,
                                textAlign: 'right',
                            }}
                        >
                            {uploadProgress}% Complete
                        </Typography>
                        <Divider sx={{ my: 2 }} />
                        <Typography
                            variant="caption"
                            color="text.secondary"
                            sx={{ display: 'block', lineHeight: 1.5 }}
                        >
                            By proceeding, you agree to our{' '}
                            <a
                                href="#"
                                style={{
                                    color: theme.palette.primary.main,
                                    textDecoration: 'none',
                                }}
                            >
                                Terms of Service
                            </a>{' '}
                            and{' '}
                            <a
                                href="#"
                                style={{
                                    color: theme.palette.primary.main,
                                    textDecoration: 'none',
                                }}
                            >
                                Privacy Policy
                            </a>
                            .
                        </Typography>
                    </Box>
                </Grid>
            )}
        </Grid>
    )

    const StepContent = () => {
        switch (step) {
            case 0:
                return <Step0Content />
            // case 1:
            //     return <ConfigureDataStep />
            case 1:
                return <SelectFeaturesStep />
            case 2:
                return <SummaryReport summary={fullDriftAnalysis} />
            default:
                return null
        }
    }

    const handleBrowse = (type) => {
        const input = document.createElement('input')
        input.type = 'file'
        input.accept = '.csv'
        input.onchange = (e) => handleFileChange(e, type)
        input.click()
    }

    const handleSave = () => {
        const fileList = []
        if (fileState.combined) {
            fileList.push(fileState.combined)
        } else {
            if (fileState.train) fileList.push(fileState.train)
            if (fileState.test) fileList.push(fileState.test)
        }

        if (fileList.length === 0) {
            showInfoToast('Please select at least one file.')
            return
        }

        dispatch(
            uploadFiles({
                user_id: user?.user_id,
                tenant_id: user?.tenant_id,
                files: fileList,
            })
        )
    }

    useEffect(() => {
        if (success) {
            showSuccessToast('Files uploaded successfully!')
            dispatch(clearUploadStatus())
            setFileState({ train: null, test: null, combined: null }) // optional: reset
        } else if (error) {
            showErrorToast(`Upload failed: ${error}`)
            dispatch(clearUploadStatus())
        }
    }, [success, error, dispatch])

    return (
        <Box
            sx={{
                bgcolor: theme.palette.background.default,
                minHeight: '100vh',
            }}
        >
            {/* DashboardNavBar would typically go here */}

            <Container maxWidth="xl" sx={{ pt: { xs: 4, md: 6 }, pb: 6 }}>
                <Typography
                    variant="h6"
                    fontWeight="500"
                    sx={{ color: 'gray', mb: 4, fontSize: '14px' }}
                >
                    <IconButton
                        onClick={handleGoBack}
                        aria-label="Go back"
                        sx={{ color: 'gray', fontSize: '18px' }}
                    >
                        <ArrowBack fontSize="20px" />
                    </IconButton>
                    Home /{' '}
                    {step === 3 ? `Analysis Summary` : `New Model Analysis`}
                </Typography>

                {/* Tabs Section */}
                <Paper
                    elevation={2}
                    sx={{
                        mb: 4,
                        borderRadius: 2,
                        p: 0,
                        overflow: 'hidden',
                    }}
                >
                    <Tabs
                        value={step}
                        // onChange={handleTabChange}
                        textColor="secondary"
                        indicatorColor="secondary"
                        variant={isSmallScreen ? 'scrollable' : 'fullWidth'}
                        scrollButtons="auto"
                        allowScrollButtonsMobile
                        sx={{
                            '& .MuiTab-root': {
                                textTransform: 'none',
                                fontWeight: theme.typography.fontWeightMedium,
                                fontSize: isSmallScreen ? '0.8rem' : '1rem',
                                color: theme.palette.text.secondary,
                                py: { xs: 1.5, sm: 2.5 },
                                minWidth: 'auto',
                                flexGrow: 1,
                            },
                            '& .Mui-selected': {
                                color: theme.palette.secondary.main,
                                fontWeight: theme.typography.fontWeightBold,
                            },
                            '& .MuiTabs-indicator': {
                                backgroundColor: theme.palette.secondary.main,
                                height: 2,
                                borderRadius: '4px 4px 0 0',
                            },
                        }}
                    >
                        <Tab label="1. Upload" />
                        {/* <Tab label="2. Configure" /> */}
                        <Tab label="2. Select Features" />
                        <Tab label="3. Report" />
                    </Tabs>
                </Paper>

                {/* Main content area for each step */}

                {StepContent()}

                {/* Navigation Buttons */}
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent:
                            step === 0 || step === 3
                                ? 'flex-end'
                                : 'space-between',
                        mt: 4,
                        pb: 2,
                    }}
                >
                    {step > 0 && step < 3 && (
                        <Button
                            variant="outlined"
                            color="secondary"
                            onClick={handleBack}
                            sx={{
                                textTransform: 'none',
                                minWidth: '100px',
                                fontWeight: 'bold',
                            }}
                        >
                            Back
                        </Button>
                    )}
                    {step < 2 && (
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={handleNext}
                            sx={{
                                textTransform: 'none',
                                minWidth: '140px',
                                fontWeight: 'bold',
                            }}
                        >
                            {step === 1 ? 'Generate Report' : 'Next'}
                        </Button>
                    )}
                    {step === 2 && (
                        <Button
                            variant="contained"
                            color="primary"
                            href="/dashboard"
                            sx={{
                                textTransform: 'none',
                                minWidth: '180px',
                                fontWeight: 'bold',
                            }}
                        >
                            Go To Dashboard
                        </Button>
                    )}
                </Box>
            </Container>
        </Box>
    )
}

export default NewAnalysis
