# XAI-Explainability API

This project provides a FastAPI application to expose data drift analysis functionalities. It leverages `evidently` for drift detection and `boto3` (AWS Bedrock) for AI-powered insights.

## Features

* **Data Upload:** Upload reference and current datasets (either separately or as a combined file).

* **Full Data Drift Report:** Generate an HTML report and JSON summary for the entire dataset.

* **Column-Specific Drift Report:** Generate an HTML report and JSON summary for individual columns.

* **Textual Summaries:** Extract concise textual summaries from Evidently JSON reports.

* **AI-Powered Analysis:** Utilize Large Language Models (LLMs) via AWS Bedrock to provide deeper business insights and recommendations for detected data drift.

* **Backend Report Upload:** Automatically uploads generated JSON reports to a configurable backend API.

## Prerequisites

Before you begin, ensure you have the following installed:

* **Python 3.8+**

* **pip** (Python package installer)

### AWS Credentials (for AI Analysis)

If you plan to use the AI-powered analysis features, you will need AWS credentials configured for access to Bedrock. You can set them up in several ways:

1.  **Environment Variables (Recommended for Development):**

    ```
    export AWS_ACCESS_KEY_ID="YOUR_AWS_ACCESS_KEY"
    export AWS_SECRET_ACCESS_KEY="YOUR_AWS_SECRET_KEY"
    export AWS_REGION="your-aws-region" # e.g., us-east-1


    ```

2.  **AWS CLI Configuration:**
    Run `aws configure` and follow the prompts.

3.  **IAM Roles (Recommended for Production):**
    For deployment on AWS services (EC2, ECS, Lambda), assign an IAM role with appropriate permissions to access Bedrock.

## Setup Instructions

Follow these steps to set up and run the application on your system.

### 1. Clone the Repository
git clone &lt;your-repository-url>
cd &lt;your-repository-name> # e.g., data-drift-api


### 2. Create a Virtual Environment (Recommended)

It's highly recommended to use a virtual environment to manage dependencies and avoid conflicts with other Python projects.

**For macOS and Linux:**

python3 -m venv venv
source venv/bin/activate


**For Windows (Command Prompt):**

python -m venv venv
venv\Scripts\activate


**For Windows (PowerShell):**

python -m venv venv
.\venv\Scripts\Activate.ps1


### 3. Install Dependencies

With your virtual environment activated, install the required packages. Create a `requirements.txt` file in your project root with the following content:

requirements.txt
fastapi==0.111.0
uvicorn==0.30.1
pandas==2.2.2
evidently==0.4.2
boto3==1.34.119
requests==2.32.3
python-multipart==0.0.9


Then, run:

pip install -r requirements.txt


### 4. Place Backend Files

Ensure that `datadrift_backend.py` (and `app.py`, though `app.py` is the Streamlit frontend and not directly used by FastAPI, it's good for project completeness) are in the same directory as `main.py`.

### 5. Configure Environment Variables

The application can upload drift reports to a configurable backend API. Set the following environment variables before running the application:

**For macOS and Linux:**

export BACKEND_API_URL="http://localhost:8000/upload-report" # Replace with your actual upload API endpoint
export BACKEND_JWT_TOKEN="your_jwt_token_here" # Replace with a secure JWT token for authentication
export BACKEND_USER_ID="1" # Replace with your user ID
export BACKEND_TENANT_ID="1" # Replace with your tenant ID


**For Windows (Command Prompt):**

set BACKEND_API_URL="http://localhost:8000/upload-report"
set BACKEND_JWT_TOKEN="your_jwt_token_here"
set BACKEND_USER_ID="1"
set BACKEND_TENANT_ID="1"


**For Windows (PowerShell):**

$env:BACKEND_API_URL="http://localhost:8000/upload-report"
$env:BACKEND_JWT_TOKEN="your_jwt_token_here"
$env:BACKEND_USER_ID="1"
$env:BACKEND_TENANT_ID="1"


**Note:** If these are not set, the upload functionality will still attempt to run but might fail or use placeholder values.

## Running the Application

After completing the setup and configuration, you can run the FastAPI application:

uvicorn main:app --reload --host 0.0.0.0 --port 8000


* `main`: Refers to the `main.py` file.

* `app`: Refers to the `FastAPI()` instance named `app` inside `main.py`.

* `--reload`: Restarts the server automatically on code changes (useful for development).

* `--host 0.0.0.0`: Makes the server accessible from other devices on your network (use `127.0.0.1` or `localhost` if only accessing locally).

* `--port 8000`: Runs the application on port 8000.

Once the server is running, you can access the API documentation at:

* **Swagger UI:** `http://127.0.0.1:8000/docs`

* **ReDoc:** `http://127.0.0.1:8000/redoc`

## API Endpoints

The API documentation (`/docs`) provides a detailed interactive interface for all available endpoints. Here's a brief overview:

* **`POST /upload-data`**: Upload reference and current datasets.

    * Parameters: `reference_file` (file), `current_file` (file), `combined_file` (file), `split_percentage` (int).

* **`POST /analyze-full-drift`**: Generates and returns a full HTML data drift report.

* **`POST /analyze-column-drift`**: Generates and returns an HTML data drift report for a specific column.

    * Parameters: `column_name` (string).

* **`POST /get-full-drift-summary`**: Returns a textual summary from a full data drift JSON payload.

    * Parameters: `drift_json_payload` (JSON object).

* **`POST /get-column-drift-summary`**: Returns a textual summary for a specific column from a data drift JSON payload.

    * Parameters: `column_name` (string), `drift_json_payload` (JSON object).

* **`POST /ai-full-drift-analysis`**: Provides an AI-powered business analysis for the full data drift.

    * Parameters: `drift_json_payload` (JSON object).

* **`POST /ai-column-drift-analysis`**: Provides an AI-powered business analysis for a specific column's data drift.

    * Parameters: `column_name` (string), `drift_json_payload` (JSON object).

* **`GET /status`**: Checks the current data load status in the API.

## Usage Workflow

1.  **Upload Data:** Begin by uploading your datasets using the `/upload-data` endpoint. This will load the data into the application's memory for subsequent analysis.

2.  **Generate Reports:** Call `/analyze-full-drift` or `/analyze-column-drift` to perform drift analysis and generate Evidently reports. These endpoints will return the HTML report and also trigger the upload of the raw JSON report to your configured backend API.

3.  **Get Summaries/AI Analysis:**

    * If you have access to the raw Evidently JSON output (either from a local temporary file or retrieved from your backend storage), you can pass it to the `/get-*-summary` or `/ai-*-analysis` endpoints.

    * These endpoints will leverage the `DriftAnalyzer` and `LLMAnalyzer` to provide concise textual summaries or more in-depth AI-powered business insights based on the drift results.

## Troubleshooting

* **`ModuleNotFoundError`**: Ensure you have activated your virtual environment and run `pip install -r requirements.txt`.

* **AWS Bedrock Errors**: Check your AWS credentials and ensure your IAM user/role has permissions for `bedrock:InvokeModel` and related actions in the specified AWS region.

* **File Upload Errors**: Verify that the files you are uploading are valid CSVs and that the `python-multipart` library is installed.

* **Backend Upload Issues**: Double-check the `BACKEND_API_URL`, `BACKEND_JWT_TOKEN`
