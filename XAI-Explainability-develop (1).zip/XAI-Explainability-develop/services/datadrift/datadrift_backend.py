# In datadrift_backend.py

import warnings

warnings.filterwarnings("ignore", category=FutureWarning)
import pandas as pd
import json
import boto3
import tempfile
import os
import requests
import mimetypes
from datetime import datetime
from evidently import Report
from evidently.presets import DataDriftPreset
from evidently import Dataset


class DriftAnalyzer:
    def __init__(self, api_url=None, jwt_token=None, user_id=None, tenant_id=None):
        self.reference_df = None
        self.current_df = None
        # S3 upload configuration
        self.api_url = api_url
        self.jwt_token = jwt_token
        self.user_id = user_id
        self.tenant_id = tenant_id

    def upload_file_to_api(
        self, api_url: str, jwt_token: str, file_path: str, user_id: int, tenant_id: int
    ) -> str:
        """Upload file to API endpoint."""
        headers = {"Authorization": f"Bearer {jwt_token}"}

        content_type, _ = mimetypes.guess_type(file_path)

        files = {
            "files": (
                file_path.split("/")[-1],
                open(file_path, "rb"),
                content_type or "application/json",
            )
        }

        data = {"user_id": str(user_id), "tenant_id": str(tenant_id)}

        try:
            response = requests.post(api_url, headers=headers, files=files, data=data)

            if response.status_code == 200:
                return "File uploaded successfully."
            else:
                return f"Upload failed. Status code: {response.status_code}. Details: {response.text}"

        except Exception as e:
            return f"An error occurred: {str(e)}"
        finally:
            # Close the file handle
            if "files" in locals():
                files["files"][1].close()

    def _save_and_upload_json(self, result, filename_prefix):
        """Save JSON report and upload to API if configured."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        json_filename = f"{filename_prefix}_{timestamp}.json"

        upload_result = None  # default if no upload

        try:
            # Save JSON to temporary file
            temp_json_path = os.path.join(tempfile.gettempdir(), json_filename)
            result.save_json(temp_json_path)

            # Upload to API if configuration is provided
            if all([self.api_url, self.jwt_token, self.user_id, self.tenant_id]):
                upload_result = self.upload_file_to_api(
                    self.api_url,
                    self.jwt_token,
                    temp_json_path,
                    self.user_id,
                    self.tenant_id,
                )
                print(f"Upload result: {upload_result}")
            else:
                print(f"JSON saved locally: {temp_json_path}")

            return temp_json_path, upload_result  # ✅ fixed: return both
        except Exception as e:
            print(f"Error saving/uploading JSON: {e}")
            return None, None  # or raise if preferred

    def preprocess(self, df: pd.DataFrame) -> pd.DataFrame:
        """Map yes/no to 1/0 and one-hot encode categorical columns."""
        yes_no_cols = [
            col for col in df.columns if set(df[col].dropna().unique()) == {"yes", "no"}
        ]
        for col in yes_no_cols:
            df[col] = df[col].map({"yes": 1, "no": 0})
        return pd.get_dummies(df, drop_first=True)

    def load_data(self, ref_df, cur_df=None, split_pct=50):
        """Load and prepare data for drift analysis."""
        if cur_df is None:
            # Split mode
            split_idx = int(len(ref_df) * split_pct / 100)
            self.reference_df = ref_df.iloc[:split_idx]
            self.current_df = ref_df.iloc[split_idx:]
        else:
            # Separate files mode
            self.reference_df = ref_df
            self.current_df = cur_df

        return self.reference_df, self.current_df

    def generate_full_drift_report(self):
        """Generate full dataset drift report."""
        ds_ref = Dataset.from_pandas(self.reference_df)
        ds_cur = Dataset.from_pandas(self.current_df)
        report = Report(metrics=[DataDriftPreset()])
        result = report.run(reference_data=ds_ref, current_data=ds_cur)

        # Save JSON and upload to API
        json_path, upload_result = self._save_and_upload_json(
            result, "full_drift_report"
        )

        # Get HTML
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html")
        tmp.close()  # Close the file handle
        result.save_html(tmp.name)
        with open(tmp.name, "r", encoding="utf-8") as f:
            html = f.read()
        os.unlink(tmp.name)

        # Get JSON for analysis
        drift_json = result.json()
        drift_dict = json.loads(drift_json) if drift_json else {}

        return html, drift_dict, json_path, upload_result

    def generate_column_drift_report(self, column):
        """Generate drift report for specific column."""
        ref_col_df = self.reference_df[[column]].copy()
        cur_col_df = self.current_df[[column]].copy()

        ds_ref = Dataset.from_pandas(ref_col_df)
        ds_cur = Dataset.from_pandas(cur_col_df)
        report = Report(metrics=[DataDriftPreset()])
        result = report.run(reference_data=ds_ref, current_data=ds_cur)

        # Save JSON and upload to API
        json_path, upload_result = self._save_and_upload_json(
            result, f"column_drift_report_{column}"
        )

        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".html")
        tmp.close()  # Close the file handle
        result.save_html(tmp.name)
        with open(tmp.name, "r", encoding="utf-8") as f:
            html = f.read()
        os.unlink(tmp.name)
        drift_json = result.json()
        drift_dict = json.loads(drift_json) if drift_json else {}

        return html, drift_dict, json_path, upload_result

    def get_drift_summary(self, drift_dict):
        """Extract drift summary from results."""
        summary_lines = []
        if "metrics" in drift_dict:
            for metric in drift_dict["metrics"]:
                if metric.get("metric") == "DataDriftTable":
                    result = metric.get("result", {})
                    n_drifted = result.get("number_of_drifted_columns", 0)
                    total = result.get("number_of_columns", 0)
                    share = result.get("share_of_drifted_columns", 0.0)
                    summary_lines.append(
                        f"- Drifted columns: {n_drifted} out of {total} ({share:.0%})"
                    )
                    for feature, info in result.get("drift_by_columns", {}).items():
                        status = info.get("drift_detected", False)
                        stat = info.get("stattest_name", "Unknown")
                        summary_lines.append(
                            f"  - {feature}: Drift={'Yes' if status else 'No'} | Test={stat}"
                        )
        return "\n".join(summary_lines)

    def get_column_drift_summary(
        self,
        drift_dict: dict,
        column_name: str,
        psi_threshold: float = 0.10,
    ) -> str:
        """
        Produce a markdown bullet list for `column_name` that mirrors what
        Evidently shows in its HTML table.

        Priority order:
        1. DataDriftTable → stattest, p-value, drift_score, drift flag
        2. ValueDrift(column=…) → PSI only
        """

        # ── 1️⃣  Look for the full DataDriftTable entry ─────────────────────
        for metric in drift_dict.get("metrics", []):
            if metric.get("metric") == "DataDriftTable":
                col_info = (
                    metric.get("result", {})
                    .get("drift_by_columns", {})
                    .get(column_name)
                )
                if col_info:
                    drift_flag = col_info.get("drift_detected", False)
                    stattest = col_info.get("stattest_name", "Unknown")
                    p_value = col_info.get("p_value", "N/A")
                    score = col_info.get("drift_score", "N/A")

                    return (
                        f"- **Column**: `{column_name}`\n"
                        f"  - Drift Detected: {'Yes ✅' if drift_flag else 'No ❌'}\n"
                        f"  - Stat Test: {stattest}\n"
                        f"  - p-value: {p_value}\n"
                        f"  - Drift Score: {score}"
                    )

        # ── 2️⃣  Fall back to the PSI-only ValueDrift metric ───────────────
        for metric in drift_dict.get("metrics", []):
            if metric.get("metric_id") == f"ValueDrift(column={column_name})":
                psi_value = metric.get("value", None)
                if psi_value is None:
                    break

                drift_flag = psi_value >= psi_threshold
                return (
                    f"- **Column**: `{column_name}`\n"
                    f"  - Population-Stability Index (PSI): {psi_value:.4f}\n"
                    f"  - Threshold: {psi_threshold}\n"
                    f"  - Drift Detected: {'Yes ✅' if drift_flag else 'No ❌'}"
                )

        # ── 3️⃣  Nothing found ─────────────────────────────────────────────
        return f"- No drift information found for column `{column_name}`."


class LLMAnalyzer:
    def __init__(self):
        self.bedrock_runtime = None
        self._initialize_bedrock()

    def _initialize_bedrock(self):
        """Initialize AWS Bedrock client."""
        try:
            self.bedrock_runtime = boto3.client(
                service_name="bedrock-runtime",
                region_name=os.getenv("AWS_REGION", "us-east-1"),
                aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
                aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY"),
            )
        except Exception as e:
            print(f"Bedrock initialization failed: {e}")

    def analyze_full_drift(self, ref_df, cur_df, summary_text):
        """Generate comprehensive drift analysis."""
        prompt = f"""
You are a senior data scientist and business consultant analyzing data drift for a dataset.

The organization has been monitoring their data over time to detect potential changes in data patterns, quality, or distributions that could impact their machine learning models and business decisions.

DATASET INFORMATION:
- Reference dataset shape: {ref_df.shape}
- Current dataset shape: {cur_df.shape}
- Number of features analyzed: {len(ref_df.columns)}
- Features: {', '.join(ref_df.columns[:10])}{'...' if len(ref_df.columns) > 10 else ''}

DRIFT ANALYSIS RESULTS:
{summary_text}

ANALYSIS METHOD:
- Framework: Evidently AI
- Method: Population Stability Index (PSI)
- Threshold: 0.1 (standard threshold for drift detection)

Please provide a comprehensive business analysis covering:

1. **Executive Summary** - Key findings in 2-3 sentences
2. **Critical Drift Issues** - Which features show significant drift and severity
3. **Business Impact** - Potential consequences for models and operations
4. **Root Cause Analysis** - Possible reasons for observed drift
5. **Recommendations** - Specific actions to address drift issues
6. **Risk Assessment** - Categorize risk levels and urgency
7. **Next Steps** - Immediate and long-term actions needed

Format your response in clear markdown with proper headings and bullet points.
"""
        return self._invoke_claude(prompt)

    #     def analyze_column_drift(self, column):
    #         """Generate column-specific drift analysis."""
    #         prompt = f"""
    # You are a helpful assistant. Analyze the data drift for column: {column}.
    # Provide a short summary for the differences in distributions between the reference and current dataset (if any).
    # Use statistical reasoning and focus on insights.
    # """
    #         return self._invoke_claude(prompt)
    def analyze_column_drift(self, summary):
        """Generate column-specific drift analysis using summary."""
        prompt = f"""
    You are a senior data scientist investigating a data drift issue for a specific column.

    The following column-level drift details have been extracted:

    {summary}

    Please analyze the statistical insights and their impact on model behavior or business decisions. Your analysis should include:

    1. **Drift Detection** — Was drift observed, and how significant is it?
    2. **Possible Causes** — What could explain the distribution change?
    3. **Consequences** — What does this drift mean for ML models?
    4. **Recommended Actions** — Any steps needed to mitigate its effects.

   Format your response in clear markdown with proper headings and bullet points.
    """
        return self._invoke_claude(prompt)

    def _invoke_claude(self, prompt):
        """Invoke Claude via AWS Bedrock."""
        if not self.bedrock_runtime:
            return "Claude invocation failed: Bedrock not initialized"

        try:
            request_body = {
                "anthropic_version": "bedrock-2023-05-31",
                "max_tokens": 130000,
                "messages": [{"role": "user", "content": prompt}],
                "temperature": 0.3,
            }

            response = self.bedrock_runtime.invoke_model(
                modelId="us.anthropic.claude-3-7-sonnet-20250219-v1:0",
                body=json.dumps(request_body),
            )

            response_body = json.loads(response["body"].read().decode("utf-8"))
            return response_body["content"][0]["text"]
        except Exception as e:
            return f"Claude invocation failed: {e}"
