# main.py
from dotenv import load_dotenv  # Import load_dotenv
import os  # Import os for getenv

# --- Load environment variables from .env file ---
# This should be called as early as possible in your application's entry point.
load_dotenv()
# -------------------------------------------------

from fastapi import FastAPI, File, UploadFile, Form, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from typing import Optional, Dict, Any
import pandas as pd
import io
from datetime import datetime
import tempfile
import json

# Assuming datadrift_backend.py is in the same directory or accessible via PYTHONPATH
from services.datadrift.datadrift_backend import DriftAnalyzer, LLMAnalyzer

app = FastAPI(
    title="Data Drift Analysis API",
    description="API for performing data drift analysis using Evidently AI and AI-powered insights.",
    version="1.0.0",
)

# Initialize analyzers globally (or inject them via dependency injection if preferred for testing)
# Retrieve configurations from environment variables (now loaded from .env)
API_URL = os.getenv("BACKEND_API_URL")
JWT_TOKEN = os.getenv("BACKEND_JWT_TOKEN")

# Convert USER_ID and TENANT_ID to int, providing default if not found or invalid
try:
    USER_ID_STR = os.getenv("BACKEND_USER_ID")
    USER_ID = int(USER_ID_STR) if USER_ID_STR else 1  # Default to 1 if not set
except (ValueError, TypeError):
    print(
        "Warning: BACKEND_USER_ID environment variable is not a valid integer. Defaulting to 1."
    )
    USER_ID = 1

try:
    TENANT_ID_STR = os.getenv("BACKEND_TENANT_ID")
    TENANT_ID = int(TENANT_ID_STR) if TENANT_ID_STR else 1  # Default to 1 if not set
except (ValueError, TypeError):
    print(
        "Warning: BACKEND_TENANT_ID environment variable is not a valid integer. Defaulting to 1."
    )
    TENANT_ID = 1


drift_analyzer = DriftAnalyzer(
    api_url=API_URL, jwt_token=JWT_TOKEN, user_id=USER_ID, tenant_id=TENANT_ID
)
llm_analyzer = LLMAnalyzer()

# Store dataframes in memory for subsequent analysis within the same session
# In a real-world multi-user application, this would need a more robust state management
# (e.g., caching with user-specific keys, database storage, or passing data IDs).
# For this example, we'll use a simple in-memory store.
data_store: Dict[str, pd.DataFrame] = {}


@app.post("/upload-data", summary="Upload Reference and Current Data for Analysis")
async def upload_data(
    reference_file: Optional[UploadFile] = File(
        None, description="Reference dataset (CSV)"
    ),
    current_file: Optional[UploadFile] = File(
        None, description="Current dataset (CSV)"
    ),
    combined_file: Optional[UploadFile] = File(
        None, description="Combined dataset (CSV)"
    ),
    split_percentage: Optional[int] = Form(
        50, description="Percentage for reference data if combined file is used (10-90)"
    ),
):
    """
    Uploads data for drift analysis. You can either upload:
    - `reference_file` and `current_file` separately.
    - A `combined_file` which will be split into reference and current based on `split_percentage`.

    The uploaded data will be stored temporarily for subsequent analysis.
    """
    global drift_analyzer  # Access the global instance

    ref_df = None
    cur_df = None

    if reference_file and current_file:
        try:
            ref_content = await reference_file.read()
            cur_content = await current_file.read()
            ref_df = pd.read_csv(io.StringIO(ref_content.decode("utf-8")))
            cur_df = pd.read_csv(io.StringIO(cur_content.decode("utf-8")))

            if list(ref_df.columns) != list(cur_df.columns):
                raise HTTPException(
                    status_code=400,
                    detail="Reference and Current datasets must have the same columns.",
                )

            # Store the dataframes
            data_store["reference_df"] = ref_df
            data_store["current_df"] = cur_df
            drift_analyzer.load_data(ref_df, cur_df)

            return JSONResponse(
                status_code=200,
                content={
                    "message": "Reference and Current files uploaded and loaded successfully.",
                    "reference_rows": len(ref_df),
                    "current_rows": len(cur_df),
                    "columns": list(ref_df.columns),
                },
            )
        except Exception as e:
            raise HTTPException(
                status_code=400, detail=f"Error processing separate files: {e}"
            )

    elif combined_file:
        try:
            combined_content = await combined_file.read()
            df = pd.read_csv(io.StringIO(combined_content.decode("utf-8")))

            if not (10 <= split_percentage <= 90):
                raise HTTPException(
                    status_code=400,
                    detail="Split percentage must be between 10 and 90.",
                )

            # Store the dataframes
            data_store["combined_df"] = df
            ref_df, cur_df = drift_analyzer.load_data(df, split_pct=split_percentage)
            data_store["reference_df"] = ref_df
            data_store["current_df"] = cur_df

            return JSONResponse(
                status_code=200,
                content={
                    "message": f"Combined file uploaded and split successfully ({split_percentage}% reference).",
                    "total_rows": len(df),
                    "reference_rows": len(ref_df),
                    "current_rows": len(cur_df),
                    "columns": list(df.columns),
                },
            )
        except Exception as e:
            raise HTTPException(
                status_code=400, detail=f"Error processing combined file: {e}"
            )
    else:
        raise HTTPException(
            status_code=400,
            detail="Please provide either separate reference/current files or a combined file.",
        )


@app.post(
    "/analyze-full-drift",
    response_class=HTMLResponse,
    summary="Generate Full Data Drift Report",
)
async def analyze_full_drift():
    """
    Generates a full data drift report for the entire dataset using Evidently AI.
    Returns the HTML report and a JSON summary.
    """
    if "reference_df" not in data_store or "current_df" not in data_store:
        raise HTTPException(
            status_code=400,
            detail="No data uploaded. Please upload data first using /upload-data.",
        )

    html_report, drift_dict, json_path, upload_result = (
        drift_analyzer.generate_full_drift_report()
    )

    response_content = f"""
    <html>
        <head>
            <title>Full Data Drift Report</title>
        </head>
        <body>
            <h1>Full Data Drift Report</h1>
            <p><strong>Upload Status:</strong> {upload_result if upload_result else 'No upload configured or encountered an issue.'}</p>
            <p><strong>JSON Report Path:</strong> {os.path.basename(json_path) if json_path else 'Not saved locally.'}</p>
            {html_report}
        </body>
    </html>
    """
    return HTMLResponse(content=response_content)


@app.post(
    "/analyze-column-drift",
    response_class=HTMLResponse,
    summary="Generate Single Column Data Drift Report",
)
async def analyze_column_drift(column_name: str):
    """
    Generates a data drift report for a specific column using Evidently AI.
    Returns the HTML report and a JSON summary.
    """
    if "reference_df" not in data_store or "current_df" not in data_store:
        raise HTTPException(
            status_code=400,
            detail="No data uploaded. Please upload data first using /upload-data.",
        )

    ref_cols = data_store["reference_df"].columns
    if column_name not in ref_cols:
        raise HTTPException(
            status_code=404, detail=f"Column '{column_name}' not found in the dataset."
        )

    html_report, drift_dict, json_path, upload_result = (
        drift_analyzer.generate_column_drift_report(column_name)
    )

    response_content = f"""
    <html>
        <head>
            <title>Column Data Drift Report - {column_name}</title>
        </head>
        <body>
            <h1>Column Data Drift Report for '{column_name}'</h1>
            <p><strong>Upload Status:</strong> {upload_result if upload_result else 'No upload configured or encountered an issue.'}</p>
            <p><strong>JSON Report Path:</strong> {os.path.basename(json_path) if json_path else 'Not saved locally.'}</p>
            {html_report}
        </body>
    </html>
    """
    return HTMLResponse(content=response_content)


@app.post("/get-full-drift-summary", summary="Get Text Summary of Full Data Drift")
async def get_full_drift_summary(drift_json_payload: Dict[str, Any]):
    """
    Provides a textual summary of the full data drift analysis based on the Evidently JSON output.
    """
    summary = drift_analyzer.get_drift_summary(drift_json_payload)
    return JSONResponse(content={"summary": summary})


@app.post(
    "/get-column-drift-summary", summary="Get Text Summary of Single Column Data Drift"
)
async def get_column_drift_summary(
    column_name: str, drift_json_payload: Dict[str, Any]
):
    """
    Provides a textual summary of a single column's data drift analysis based on the Evidently JSON output.
    """
    summary = drift_analyzer.get_column_drift_summary(drift_json_payload, column_name)
    return JSONResponse(content={"summary": summary})


@app.post(
    "/ai-full-drift-analysis", summary="Get AI-Powered Analysis of Full Data Drift"
)
async def ai_full_drift_analysis(drift_json_payload: Dict[str, Any]):
    """
    Generates an AI-powered business analysis for the full data drift report.
    Requires the full drift report's JSON output.
    """
    if "reference_df" not in data_store or "current_df" not in data_store:
        raise HTTPException(
            status_code=400,
            detail="No data uploaded. Please upload data first using /upload-data.",
        )

    summary_text = drift_analyzer.get_drift_summary(drift_json_payload)
    llm_response = llm_analyzer.analyze_full_drift(
        data_store["reference_df"], data_store["current_df"], summary_text
    )
    return JSONResponse(content={"ai_analysis": llm_response})


@app.post(
    "/ai-column-drift-analysis",
    summary="Get AI-Powered Analysis of Single Column Data Drift",
)
async def ai_column_drift_analysis(
    column_name: str, drift_json_payload: Dict[str, Any]
):
    """
    Generates an AI-powered business analysis for a specific column's data drift.
    Requires the column-specific drift report's JSON output.
    """
    if "reference_df" not in data_store or "current_df" not in data_store:
        raise HTTPException(
            status_code=400,
            detail="No data uploaded. Please upload data first using /upload-data.",
        )

    summary_text = drift_analyzer.get_column_drift_summary(
        drift_json_payload, column_name
    )
    llm_response = llm_analyzer.analyze_column_drift(summary_text)
    return JSONResponse(content={"ai_analysis": llm_response})


# Optional: Endpoint to check if data is loaded
@app.get("/status", summary="Check Data Load Status")
async def get_status():
    """
    Checks if reference and current dataframes are loaded in the API.
    """
    return JSONResponse(
        content={
            "reference_df_loaded": "reference_df" in data_store,
            "current_df_loaded": "current_df" in data_store,
            "reference_rows": (
                len(data_store["reference_df"]) if "reference_df" in data_store else 0
            ),
            "current_rows": (
                len(data_store["current_df"]) if "current_df" in data_store else 0
            ),
            "columns": (
                list(data_store["reference_df"].columns)
                if "reference_df" in data_store
                else []
            ),
        }
    )


if __name__ == "__main__":
    import uvicorn

    # To run this API: uvicorn main:app --reload --port 8000
    uvicorn.run(app, host="0.0.0.0", port=8000)
