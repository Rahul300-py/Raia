/* eslint-disable no-unused-vars */
// src/pages/XAIDashboardPage.jsx
import React from 'react'
import {
    AppBar,
    Toolbar,
    Typography,
    IconButton,
    InputBase,
    Box,
    Container,
    Paper,
    Tabs,
    Tab,
    Button,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Stack,
    Grid,
    Divider,
    Link,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Slider,
    TextField,
    Tooltip,
} from '@mui/material'
import SearchIcon from '@mui/icons-material/Search'
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined'
import MoreVertIcon from '@mui/icons-material/MoreVert'
import DownloadIcon from '@mui/icons-material/Download'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined' // For info tooltips

// Recharts imports for the Feature Importances chart
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    ResponsiveContainer,
    LabelList,
} from 'recharts'
import WhatIfAnalysis from '../components/WhatIfAnalysis'
import DataDriftDashboard from '../components/DataDrift'
import FairnessDashboard from '../components/FairnessMatrix'

// --- MOCK DATA ---

// Mock data for Titanic features and SHAP values (for Feature Importances)
const MOCK_TITANIC_SHAP_DATA = [
    {
        feature: 'Sex',
        description: 'Gender of passenger (male/female)',
        importance: 0.28,
        type: 'Categorical',
    },
    {
        feature: 'PassengerClass',
        description: 'Ticket class (1st, 2nd, 3rd)',
        importance: 0.22,
        type: 'Categorical',
    },
    {
        feature: 'Age',
        description: 'Age in years',
        importance: 0.18,
        type: 'Numerical',
    },
    {
        feature: 'Fare',
        description: 'Passenger fare',
        importance: 0.15,
        type: 'Numerical',
    },
    {
        feature: 'Embarked',
        description: 'Port of embarkation (C, Q, S)',
        importance: 0.1,
        type: 'Categorical',
    },
    {
        feature: 'SibSp',
        description: 'Number of siblings/spouses aboard',
        importance: 0.07,
        type: 'Numerical',
    },
    {
        feature: 'Parch',
        description: 'Number of parents/children aboard',
        importance: 0.05,
        type: 'Numerical',
    },
    {
        feature: 'Deck',
        description: 'Deck level (A-G, T)',
        importance: 0.03,
        type: 'Categorical',
    },
].sort((a, b) => b.importance - a.importance) // Sort by importance descending

// Mock data for classification report (for Classification Stats)
const MOCK_CLASSIFICATION_REPORT = {
    Survived: { precision: 0.78, recall: 0.7, f1_score: 0.74, support: 342 },
    'Did Not Survive': {
        precision: 0.85,
        recall: 0.9,
        f1_score: 0.87,
        support: 549,
    },
    accuracy: 0.83,
    macro_avg: { precision: 0.81, recall: 0.8, f1_score: 0.81 },
    weighted_avg: { precision: 0.83, recall: 0.83, f1_score: 0.83 },
}

// Mock data for individual prediction (for Individual Predictions)
const MOCK_INDIVIDUAL_PREDICTION = {
    predicted_class: 'Survived',
    probability: 0.88,
    base_value: 0.5, // The average prediction (logit odds) if no features were considered
    explanation_values: [
        { feature: 'Sex=female', value: 0.45, type: 'positive' }, // Positive contribution to 'Survived'
        { feature: 'PassengerClass=1st', value: 0.2, type: 'positive' },
        { feature: 'Age=28', value: 0.1, type: 'positive' },
        { feature: 'Fare=71.28', value: 0.05, type: 'positive' },
        { feature: 'Embarked=C', value: 0.02, type: 'positive' },
        { feature: 'Parch=0', value: -0.03, type: 'negative' }, // Negative contribution
        { feature: 'SibSp=1', value: -0.05, type: 'negative' },
        { feature: 'Deck=C', value: -0.08, type: 'negative' },
    ].sort((a, b) => Math.abs(b.value) - Math.abs(a.value)), // Sort by absolute contribution for waterfall
    final_prediction_sum:
        0.5 + 0.45 + 0.2 + 0.1 + 0.05 + 0.02 - 0.03 - 0.05 - 0.08, // Simulates final prediction
}

// Mock data for Feature Dependence (e.g., PDP for Age)
const MOCK_AGE_PDP_DATA = [
    { age: 0, probability: 0.3 },
    { age: 10, probability: 0.5 },
    { age: 20, probability: 0.4 },
    { age: 30, probability: 0.35 },
    { age: 40, probability: 0.3 },
    { age: 50, probability: 0.25 },
    { age: 60, probability: 0.2 },
    { age: 70, probability: 0.15 },
    { age: 80, probability: 0.1 },
]

// Mock data for Feature Interactions (e.g., Sex and PassengerClass)
const MOCK_SEX_CLASS_INTERACTION = [
    { sex: 'male', class: '1st', interaction_effect: 0.15 },
    { sex: 'male', class: '2nd', interaction_effect: 0.05 },
    { sex: 'male', class: '3rd', interaction_effect: -0.1 },
    { sex: 'female', class: '1st', interaction_effect: 0.25 },
    { sex: 'female', class: '2nd', interaction_effect: 0.18 },
    { sex: 'female', class: '3rd', interaction_effect: 0.08 },
]

// --- COMPONENT ---

function XAIDashboardPage() {
    const [activeTab, setActiveTab] = React.useState(0)
    const [importanceType, setImportanceType] = React.useState('SHAP values')
    const [depth, setDepth] = React.useState('All')
    const [selectedIndividual, setSelectedIndividual] =
        React.useState('Passenger 1234')
    const [whatIfAge, setWhatIfAge] = React.useState(25)
    const [whatIfSex, setWhatIfSex] = React.useState('female')
    const [whatIfClass, setWhatIfClass] = React.useState('3rd')
    const [dependencyFeature, setDependencyFeature] = React.useState('Age')
    const [interactionFeature1, setInteractionFeature1] = React.useState('Sex')
    const [interactionFeature2, setInteractionFeature2] =
        React.useState('PassengerClass')

    const handleTabChange = (event, newValue) => {
        setActiveTab(newValue)
    }

    // Render method for custom Recharts tooltip
    const CustomTooltip = ({ active, payload, label }) => {
        if (active && payload && payload.length) {
            const feature = MOCK_TITANIC_SHAP_DATA.find(
                (f) => f.feature === label
            )
            return (
                <Paper
                    elevation={3}
                    sx={{
                        p: 1.5,
                        borderRadius: '8px',
                        bgcolor: 'rgba(255,255,255,0.95)',
                    }}
                >
                    <Typography
                        variant="subtitle2"
                        sx={{ fontWeight: 'bold', color: 'primary.main' }}
                    >
                        {label}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        Importance: {(payload[0].value * 100).toFixed(2)}%
                    </Typography>
                    {feature && (
                        <Typography variant="caption" color="text.disabled">
                            {feature.description}
                        </Typography>
                    )}
                </Paper>
            )
        }
        return null
    }

    const renderTabContent = () => {
        switch (activeTab) {
            case 0: // What if...
                return <WhatIfAnalysis />
            case 1:
                return <DataDriftDashboard />

            case 2:
                return <FairnessDashboard />

            case 3: // Feature Importances
                return (
                    <Box>
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mb: 3 }}
                            >
                                Feature Importances
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{
                                    textTransform: 'none',
                                    backgroundColor: '#333',
                                    '&:hover': { backgroundColor: '#555' },
                                }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 3 }}
                        >
                            Which features had the biggest impact on predicting
                            survival?
                        </Typography>

                        <Stack
                            direction={{ xs: 'column', sm: 'row' }}
                            spacing={3}
                            alignItems={{ xs: 'flex-start', sm: 'center' }}
                            mb={4}
                        >
                            <FormControl
                                variant="outlined"
                                size="small"
                                sx={{ minWidth: 200 }}
                            >
                                <InputLabel id="importance-type-label">
                                    Importances type
                                </InputLabel>
                                <Select
                                    labelId="importance-type-label"
                                    value={importanceType}
                                    onChange={(e) =>
                                        setImportanceType(e.target.value)
                                    }
                                    label="Importances type"
                                >
                                    <MenuItem value="SHAP values">
                                        SHAP values
                                    </MenuItem>
                                    <MenuItem value="Permutation Importance">
                                        Permutation Importance
                                    </MenuItem>
                                </Select>
                            </FormControl>

                            <FormControl
                                variant="outlined"
                                size="small"
                                sx={{ minWidth: 120 }}
                            >
                                <InputLabel id="depth-label">Depth</InputLabel>
                                <Select
                                    labelId="depth-label"
                                    value={depth}
                                    onChange={(e) => setDepth(e.target.value)}
                                    label="Depth"
                                >
                                    <MenuItem value="All">All</MenuItem>
                                    <MenuItem value="5">5</MenuItem>
                                    <MenuItem value="10">10</MenuItem>
                                </Select>
                            </FormControl>
                        </Stack>

                        <Typography
                            variant="body2"
                            sx={{
                                textAlign: 'center',
                                mb: 2,
                                color: 'text.secondary',
                            }}
                        >
                            Average Impact on predicted Survival (mean absolute
                            SHAP value)
                        </Typography>
                        <Paper
                            variant="outlined"
                            sx={{ p: 3, mb: 4, borderRadius: '8px' }}
                        >
                            <ResponsiveContainer width="100%" height={350}>
                                <BarChart
                                    data={MOCK_TITANIC_SHAP_DATA}
                                    layout="vertical"
                                    margin={{
                                        top: 5,
                                        right: 30,
                                        left: 80,
                                        bottom: 5,
                                    }}
                                >
                                    <CartesianGrid
                                        strokeDasharray="3 3"
                                        horizontal={false}
                                    />
                                    <XAxis
                                        type="number"
                                        tickFormatter={(value) =>
                                            `${(value * 100).toFixed(0)}%`
                                        }
                                    />
                                    <YAxis
                                        type="category"
                                        dataKey="feature"
                                        width={100}
                                        tickLine={false}
                                        axisLine={false}
                                    />
                                    <Tooltip content={<CustomTooltip />} />
                                    <Bar
                                        dataKey="importance"
                                        fill={(theme) =>
                                            theme.palette.primary.main
                                        }
                                        minPointSize={5}
                                    >
                                        <LabelList
                                            dataKey="importance"
                                            position="right"
                                            formatter={(value) =>
                                                (value * 100).toFixed(1) + '%'
                                            }
                                            fill={(theme) =>
                                                theme.palette.text.primary
                                            }
                                        />
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                            <Box sx={{ textAlign: 'right', mt: 2 }}>
                                <Button
                                    variant="outlined"
                                    size="small"
                                    sx={{ textTransform: 'none' }}
                                >
                                    Popout
                                </Button>
                            </Box>
                        </Paper>

                        <Divider sx={{ my: 4 }} />

                        <Typography
                            variant="h5"
                            sx={{ fontWeight: 600, mb: 3 }}
                        >
                            Feature Descriptions
                        </Typography>
                        <Stack
                            direction="row"
                            justifyContent="space-between"
                            alignItems="center"
                            mb={2}
                        >
                            <FormControl
                                variant="outlined"
                                size="small"
                                sx={{ minWidth: 150 }}
                            >
                                <InputLabel id="sort-features-label">
                                    Sort Features
                                </InputLabel>
                                <Select
                                    labelId="sort-features-label"
                                    value="Alphabetical"
                                    onChange={() => {}} // Placeholder for sorting
                                    label="Sort Features"
                                >
                                    <MenuItem value="Alphabetical">
                                        Alphabetical
                                    </MenuItem>
                                    <MenuItem value="Importance">
                                        Importance
                                    </MenuItem>
                                </Select>
                            </FormControl>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{
                                    textTransform: 'none',
                                    backgroundColor: '#333',
                                    '&:hover': { backgroundColor: '#555' },
                                }}
                            >
                                Explain with AI
                            </Button>
                        </Stack>
                        <TableContainer
                            component={Paper}
                            variant="outlined"
                            sx={{ borderRadius: '8px' }}
                        >
                            <Table
                                size="small"
                                aria-label="feature descriptions table"
                            >
                                <TableHead>
                                    <TableRow sx={{ bgcolor: 'grey.100' }}>
                                        <TableCell sx={{ fontWeight: 'bold' }}>
                                            Feature
                                        </TableCell>
                                        <TableCell sx={{ fontWeight: 'bold' }}>
                                            Type
                                        </TableCell>
                                        <TableCell sx={{ fontWeight: 'bold' }}>
                                            Description
                                        </TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {MOCK_TITANIC_SHAP_DATA.map(
                                        (feature, index) => (
                                            <TableRow key={index}>
                                                <TableCell>
                                                    {feature.feature}
                                                </TableCell>
                                                <TableCell>
                                                    {feature.type}
                                                </TableCell>
                                                <TableCell>
                                                    {feature.description}
                                                </TableCell>
                                            </TableRow>
                                        )
                                    )}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Box>
                )
            case 4: // Classification Stats
                return (
                    <Box>
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mb: 3 }}
                            >
                                Classification Statistics
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 3 }}
                        >
                            Overall model performance metrics and class-wise
                            breakdowns.
                        </Typography>

                        <Grid container spacing={4}>
                            <Grid item xs={12} md={6}>
                                <Paper
                                    variant="outlined"
                                    sx={{ p: 3, borderRadius: '8px' }}
                                >
                                    <Typography variant="h6" sx={{ mb: 2 }}>
                                        Overall Metrics
                                    </Typography>
                                    <Stack spacing={1}>
                                        <Typography>
                                            Accuracy:{' '}
                                            <Box
                                                component="span"
                                                sx={{
                                                    fontWeight: 'bold',
                                                    color: 'primary.main',
                                                }}
                                            >
                                                {(
                                                    MOCK_CLASSIFICATION_REPORT.accuracy *
                                                    100
                                                ).toFixed(2)}
                                                %
                                            </Box>
                                        </Typography>
                                        <Typography>
                                            Macro Avg F1-Score:{' '}
                                            <Box
                                                component="span"
                                                sx={{ fontWeight: 'bold' }}
                                            >
                                                {MOCK_CLASSIFICATION_REPORT.macro_avg.f1_score.toFixed(
                                                    2
                                                )}
                                            </Box>
                                        </Typography>
                                        <Typography>
                                            Weighted Avg F1-Score:{' '}
                                            <Box
                                                component="span"
                                                sx={{ fontWeight: 'bold' }}
                                            >
                                                {MOCK_CLASSIFICATION_REPORT.weighted_avg.f1_score.toFixed(
                                                    2
                                                )}
                                            </Box>
                                        </Typography>
                                    </Stack>
                                    <Divider sx={{ my: 2 }} />
                                    <Typography variant="h6" sx={{ mb: 2 }}>
                                        Class-wise Report
                                    </Typography>
                                    <TableContainer>
                                        <Table size="small">
                                            <TableHead>
                                                <TableRow>
                                                    <TableCell
                                                        sx={{
                                                            fontWeight: 'bold',
                                                        }}
                                                    >
                                                        Class
                                                    </TableCell>
                                                    <TableCell
                                                        align="right"
                                                        sx={{
                                                            fontWeight: 'bold',
                                                        }}
                                                    >
                                                        Precision
                                                    </TableCell>
                                                    <TableCell
                                                        align="right"
                                                        sx={{
                                                            fontWeight: 'bold',
                                                        }}
                                                    >
                                                        Recall
                                                    </TableCell>
                                                    <TableCell
                                                        align="right"
                                                        sx={{
                                                            fontWeight: 'bold',
                                                        }}
                                                    >
                                                        F1-Score
                                                    </TableCell>
                                                    <TableCell
                                                        align="right"
                                                        sx={{
                                                            fontWeight: 'bold',
                                                        }}
                                                    >
                                                        Support
                                                    </TableCell>
                                                </TableRow>
                                            </TableHead>
                                            <TableBody>
                                                {Object.entries(
                                                    MOCK_CLASSIFICATION_REPORT
                                                ).map(
                                                    ([key, value]) =>
                                                        key !== 'accuracy' &&
                                                        key !== 'macro_avg' &&
                                                        key !==
                                                            'weighted_avg' && (
                                                            <TableRow key={key}>
                                                                <TableCell>
                                                                    {key}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    {value.precision.toFixed(
                                                                        2
                                                                    )}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    {value.recall.toFixed(
                                                                        2
                                                                    )}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    {value.f1_score.toFixed(
                                                                        2
                                                                    )}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    {
                                                                        value.support
                                                                    }
                                                                </TableCell>
                                                            </TableRow>
                                                        )
                                                )}
                                            </TableBody>
                                        </Table>
                                    </TableContainer>
                                </Paper>
                            </Grid>
                            <Grid item xs={12} md={6}>
                                <Paper
                                    variant="outlined"
                                    sx={{
                                        p: 3,
                                        mb: 3,
                                        borderRadius: '8px',
                                        minHeight: '250px',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        bgcolor: 'grey.50',
                                    }}
                                >
                                    <Typography
                                        variant="body2"
                                        color="text.secondary"
                                        mb={1}
                                    >
                                        ROC Curve Visualization
                                    </Typography>
                                    {/* Placeholder for ROC Curve Chart (e.g., using Recharts LineChart) */}
                                    <Box
                                        sx={{
                                            width: '90%',
                                            height: '180px',
                                            border: '1px dashed #ccc',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                    >
                                        <Typography
                                            variant="caption"
                                            color="text.disabled"
                                        >
                                            ROC Curve Here
                                        </Typography>
                                    </Box>
                                </Paper>
                                <Paper
                                    variant="outlined"
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        minHeight: '250px',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        bgcolor: 'grey.50',
                                    }}
                                >
                                    <Typography
                                        variant="body2"
                                        color="text.secondary"
                                        mb={1}
                                    >
                                        Confusion Matrix Heatmap
                                    </Typography>
                                    {/* Placeholder for Confusion Matrix Heatmap (e.g., using Nivo or custom SVG) */}
                                    <Box
                                        sx={{
                                            width: '90%',
                                            height: '180px',
                                            border: '1px dashed #ccc',
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                        }}
                                    >
                                        <Typography
                                            variant="caption"
                                            color="text.disabled"
                                        >
                                            Confusion Matrix Here
                                        </Typography>
                                    </Box>
                                </Paper>
                            </Grid>
                        </Grid>
                    </Box>
                )

            case 5: // Individual Predictions
                return (
                    <Box>
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mb: 3 }}
                            >
                                Individual Prediction Explanations
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 3 }}
                        >
                            Understand why the model made a specific prediction
                            for a single passenger.
                        </Typography>

                        <FormControl
                            variant="outlined"
                            size="small"
                            sx={{ minWidth: 250, mb: 4 }}
                        >
                            <InputLabel id="select-individual-label">
                                Select Passenger ID
                            </InputLabel>
                            <Select
                                labelId="select-individual-label"
                                value={selectedIndividual}
                                onChange={(e) =>
                                    setSelectedIndividual(e.target.value)
                                }
                                label="Select Passenger ID"
                            >
                                <MenuItem value="Passenger 1234">
                                    Passenger 1234 (Survived)
                                </MenuItem>
                                <MenuItem value="Passenger 5678">
                                    Passenger 5678 (Did Not Survive)
                                </MenuItem>
                                {/* Add more mock passengers */}
                            </Select>
                        </FormControl>

                        <Paper
                            variant="outlined"
                            sx={{ p: 3, borderRadius: '8px' }}
                        >
                            <Typography variant="h6" sx={{ mb: 2 }}>
                                Prediction for {selectedIndividual}:{' '}
                                <Box
                                    component="span"
                                    sx={{
                                        color: 'primary.main',
                                        fontWeight: 'bold',
                                    }}
                                >
                                    {MOCK_INDIVIDUAL_PREDICTION.predicted_class}
                                </Box>{' '}
                                (Probability:{' '}
                                {(
                                    MOCK_INDIVIDUAL_PREDICTION.probability * 100
                                ).toFixed(1)}
                                %)
                            </Typography>
                            <Divider sx={{ my: 2 }} />
                            <Typography variant="body1" sx={{ mb: 2 }}>
                                Feature contributions to this prediction
                                (SHAP/LIME Waterfall Plot):
                            </Typography>
                            <Box
                                sx={{
                                    minHeight: '350px',
                                    border: '1px dashed grey',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    color: 'text.secondary',
                                    mb: 2,
                                    p: 2,
                                    bgcolor: 'grey.50',
                                }}
                            >
                                <Typography variant="h6" sx={{ mb: 2 }}>
                                    Waterfall Plot Placeholder
                                </Typography>
                                {/* Simulated Waterfall Plot */}
                                <Box
                                    sx={{
                                        width: '90%',
                                        display: 'flex',
                                        flexDirection: 'column',
                                        alignItems: 'center',
                                    }}
                                >
                                    <Typography
                                        variant="caption"
                                        sx={{ alignSelf: 'flex-start', mb: 1 }}
                                    >
                                        Base Value:{' '}
                                        {MOCK_INDIVIDUAL_PREDICTION.base_value}
                                    </Typography>
                                    {MOCK_INDIVIDUAL_PREDICTION.explanation_values.map(
                                        (item, index) => (
                                            <Stack
                                                key={index}
                                                direction="row"
                                                alignItems="center"
                                                sx={{ width: '100%', mb: 0.5 }}
                                            >
                                                <Typography
                                                    variant="body2"
                                                    sx={{
                                                        minWidth: '150px',
                                                        textAlign: 'right',
                                                        mr: 1,
                                                        color:
                                                            item.type ===
                                                            'positive'
                                                                ? 'success.dark'
                                                                : 'error.dark',
                                                    }}
                                                >
                                                    {item.feature}
                                                </Typography>
                                                <Box
                                                    sx={{
                                                        height: '15px',
                                                        width: `${Math.abs(item.value) * 200}%`, // Scale based on value
                                                        bgcolor:
                                                            item.type ===
                                                            'positive'
                                                                ? 'success.light'
                                                                : 'error.light',
                                                        border: `1px solid ${item.type === 'positive' ? 'success.main' : 'error.main'}`,
                                                        borderRadius: '4px',
                                                        ml:
                                                            item.type ===
                                                            'positive'
                                                                ? 0
                                                                : `${(MOCK_INDIVIDUAL_PREDICTION.base_value + 0.1) * 200}%`, // Adjust positioning for negative bars
                                                        mr:
                                                            item.type ===
                                                            'negative'
                                                                ? 0
                                                                : `${(MOCK_INDIVIDUAL_PREDICTION.base_value + 0.1) * 200}%`,
                                                    }}
                                                />
                                                <Typography
                                                    variant="caption"
                                                    sx={{
                                                        ml: 1,
                                                        color: 'text.secondary',
                                                    }}
                                                >
                                                    {item.value.toFixed(3)}
                                                </Typography>
                                            </Stack>
                                        )
                                    )}
                                    <Typography
                                        variant="caption"
                                        sx={{ alignSelf: 'flex-start', mt: 1 }}
                                    >
                                        Final Prediction:{' '}
                                        {MOCK_INDIVIDUAL_PREDICTION.final_prediction_sum.toFixed(
                                            3
                                        )}
                                    </Typography>
                                </Box>
                                <Typography
                                    variant="caption"
                                    color="text.disabled"
                                    sx={{ mt: 2 }}
                                >
                                    (Actual Waterfall Charts are more complex
                                    with charting libraries like Plotly.js)
                                </Typography>
                            </Box>

                            <TableContainer
                                component={Paper}
                                elevation={0}
                                sx={{ mt: 3 }}
                            >
                                <Table size="small">
                                    <TableHead>
                                        <TableRow sx={{ bgcolor: 'grey.100' }}>
                                            <TableCell
                                                sx={{ fontWeight: 'bold' }}
                                            >
                                                Feature
                                            </TableCell>
                                            <TableCell
                                                sx={{ fontWeight: 'bold' }}
                                            >
                                                Contribution
                                            </TableCell>
                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {MOCK_INDIVIDUAL_PREDICTION.explanation_values.map(
                                            (f, i) => (
                                                <TableRow key={i}>
                                                    <TableCell>
                                                        {f.feature}
                                                    </TableCell>
                                                    <TableCell
                                                        sx={{
                                                            color:
                                                                f.type ===
                                                                'positive'
                                                                    ? 'success.main'
                                                                    : 'error.main',
                                                        }}
                                                    >
                                                        {f.value.toFixed(3)} (
                                                        {f.type})
                                                    </TableCell>
                                                </TableRow>
                                            )
                                        )}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                        </Paper>
                    </Box>
                )

            case 6: // Feature Dependence
                return (
                    <Box>
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mb: 3 }}
                            >
                                Feature Dependence Plots
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 3 }}
                        >
                            Visualize how a single feature impacts the model's
                            prediction on average.
                        </Typography>
                        <FormControl
                            variant="outlined"
                            size="small"
                            sx={{ minWidth: 250, mb: 4 }}
                        >
                            <InputLabel id="dependency-feature-label">
                                Select Feature
                            </InputLabel>
                            <Select
                                labelId="dependency-feature-label"
                                value={dependencyFeature}
                                onChange={(e) =>
                                    setDependencyFeature(e.target.value)
                                }
                                label="Select Feature"
                            >
                                {MOCK_TITANIC_SHAP_DATA.map((f) => (
                                    <MenuItem key={f.feature} value={f.feature}>
                                        {f.feature}
                                    </MenuItem>
                                ))}
                            </Select>
                        </FormControl>
                        <Paper
                            variant="outlined"
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                minHeight: '400px',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: 'text.secondary',
                                bgcolor: 'grey.50',
                            }}
                        >
                            <Typography variant="h6" sx={{ mb: 2 }}>
                                Partial Dependence Plot (PDP) / Individual
                                Conditional Expectation (ICE) for "
                                {dependencyFeature}"
                            </Typography>
                            <Box
                                sx={{
                                    width: '80%',
                                    height: '300px',
                                    border: '1px dashed grey',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                }}
                            >
                                <Typography
                                    variant="caption"
                                    color="text.disabled"
                                >
                                    Interactive Line/Scatter Plot showing
                                    average prediction as feature value changes.
                                    {dependencyFeature === 'Age' && (
                                        <Stack
                                            direction="row"
                                            justifyContent="space-around"
                                            sx={{ width: '100%', mt: 2 }}
                                        >
                                            {MOCK_AGE_PDP_DATA.map((d, i) => (
                                                <Stack
                                                    key={i}
                                                    alignItems="center"
                                                >
                                                    <Box
                                                        sx={{
                                                            width: 10,
                                                            height: `${d.probability * 150}px`,
                                                            bgcolor:
                                                                'primary.light',
                                                            border: '1px solid primary.main',
                                                            borderRadius: '4px',
                                                        }}
                                                    />
                                                    <Typography
                                                        variant="caption"
                                                        sx={{ mt: 0.5 }}
                                                    >
                                                        {d.age}
                                                    </Typography>
                                                </Stack>
                                            ))}
                                        </Stack>
                                    )}
                                </Typography>
                            </Box>
                            <Typography
                                variant="body2"
                                sx={{ mt: 2, textAlign: 'center' }}
                            >
                                Shows the marginal effect of a feature on the
                                predicted outcome.
                            </Typography>
                        </Paper>
                    </Box>
                )

            case 7: // Feature Interactions
                return (
                    <Box>
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mb: 3 }}
                            >
                                Feature Interaction Plots
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 3 }}
                        >
                            Explore how two features interact to influence the
                            model's prediction.
                        </Typography>
                        <Stack
                            direction={{ xs: 'column', sm: 'row' }}
                            spacing={3}
                            alignItems={{ xs: 'flex-start', sm: 'center' }}
                            mb={4}
                        >
                            <FormControl
                                variant="outlined"
                                size="small"
                                sx={{ minWidth: 200 }}
                            >
                                <InputLabel id="interaction-feature1-label">
                                    Feature 1
                                </InputLabel>
                                <Select
                                    labelId="interaction-feature1-label"
                                    value={interactionFeature1}
                                    onChange={(e) =>
                                        setInteractionFeature1(e.target.value)
                                    }
                                    label="Feature 1"
                                >
                                    {MOCK_TITANIC_SHAP_DATA.map((f) => (
                                        <MenuItem
                                            key={f.feature}
                                            value={f.feature}
                                        >
                                            {f.feature}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <FormControl
                                variant="outlined"
                                size="small"
                                sx={{ minWidth: 200 }}
                            >
                                <InputLabel id="interaction-feature2-label">
                                    Feature 2
                                </InputLabel>
                                <Select
                                    labelId="interaction-feature2-label"
                                    value={interactionFeature2}
                                    onChange={(e) =>
                                        setInteractionFeature2(e.target.value)
                                    }
                                    label="Feature 2"
                                >
                                    {MOCK_TITANIC_SHAP_DATA.map((f) => (
                                        <MenuItem
                                            key={f.feature}
                                            value={f.feature}
                                        >
                                            {f.feature}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Stack>
                        <Paper
                            variant="outlined"
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                minHeight: '400px',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: 'text.secondary',
                                bgcolor: 'grey.50',
                            }}
                        >
                            <Typography variant="h6" sx={{ mb: 2 }}>
                                Interaction Plot for "{interactionFeature1}" and
                                "{interactionFeature2}"
                            </Typography>
                            <Box
                                sx={{
                                    width: '90%',
                                    height: '300px',
                                    border: '1px dashed grey',
                                    display: 'grid',
                                    gridTemplateColumns: `repeat(${new Set(MOCK_SEX_CLASS_INTERACTION.map((d) => d.class)).size}, 1fr)`,
                                    gridTemplateRows: `repeat(${new Set(MOCK_SEX_CLASS_INTERACTION.map((d) => d.sex)).size}, 1fr)`,
                                    gap: 1,
                                    p: 2,
                                }}
                            >
                                {MOCK_SEX_CLASS_INTERACTION.map((data, idx) => (
                                    <Tooltip
                                        key={idx}
                                        title={`Sex: ${data.sex}, Class: ${data.class}, Effect: ${data.interaction_effect.toFixed(2)}`}
                                    >
                                        <Box
                                            sx={{
                                                bgcolor:
                                                    data.interaction_effect > 0
                                                        ? 'success.light'
                                                        : 'error.light',
                                                border: `1px solid ${data.interaction_effect > 0 ? 'success.main' : 'error.main'}`,
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontWeight: 'bold',
                                                fontSize: '0.9em',
                                                color:
                                                    data.interaction_effect > 0
                                                        ? 'success.dark'
                                                        : 'error.dark',
                                            }}
                                        >
                                            {data.sex === 'female' ? 'F' : 'M'}/
                                            {data.class.charAt(0)} (
                                            {data.interaction_effect.toFixed(2)}
                                            )
                                        </Box>
                                    </Tooltip>
                                ))}
                            </Box>
                            <Typography
                                variant="caption"
                                color="text.disabled"
                                sx={{ mt: 2 }}
                            >
                                (Actual Interaction plots often use heatmaps or
                                3D surfaces with charting libraries like
                                Plotly.js)
                            </Typography>
                        </Paper>
                    </Box>
                )

            case 8: // Decision Trees
                return (
                    <Box>
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mb: 3 }}
                            >
                                Decision Tree Visualization
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Typography
                            variant="body1"
                            sx={{ color: 'text.secondary', mb: 3 }}
                        >
                            If a tree-based model was used, visualize the
                            decision path and rules.
                        </Typography>
                        <Paper
                            variant="outlined"
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                minHeight: '500px',
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                color: 'text.secondary',
                                bgcolor: 'grey.50',
                            }}
                        >
                            <Typography variant="h6" sx={{ mb: 2 }}>
                                Decision Tree Graph Placeholder
                            </Typography>
                            <Box
                                sx={{
                                    width: '90%',
                                    height: '400px',
                                    border: '1px dashed grey',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    justifyContent: 'flex-start',
                                    overflow: 'auto',
                                    p: 2,
                                }}
                            >
                                {/* Simplified Tree Nodes */}
                                <Box
                                    sx={{
                                        bgcolor: 'primary.light',
                                        border: '1px solid primary.main',
                                        p: 1,
                                        borderRadius: '8px',
                                        mb: 1,
                                    }}
                                >
                                    <Typography
                                        variant="body2"
                                        sx={{ fontWeight: 'bold' }}
                                    >
                                        Root Node: Sex {'<='} 0.5 (Male)
                                    </Typography>
                                    <Typography variant="caption">
                                        Samples: 891, Value: [549, 342]
                                    </Typography>
                                </Box>
                                <Box
                                    sx={{
                                        width: '2px',
                                        height: '20px',
                                        bgcolor: 'grey.400',
                                    }}
                                />
                                <Stack
                                    direction="row"
                                    spacing={4}
                                    sx={{
                                        width: '100%',
                                        justifyContent: 'space-around',
                                    }}
                                >
                                    <Box
                                        sx={{
                                            bgcolor: 'info.light',
                                            border: '1px solid info.main',
                                            p: 1,
                                            borderRadius: '8px',
                                            width: '45%',
                                        }}
                                    >
                                        <Typography
                                            variant="body2"
                                            sx={{ fontWeight: 'bold' }}
                                        >
                                            True: Class {'<='} 2.5
                                        </Typography>
                                        <Typography variant="caption">
                                            Samples: 450, Value: [400, 50]
                                        </Typography>
                                    </Box>
                                    <Box
                                        sx={{
                                            bgcolor: 'warning.light',
                                            border: '1px solid warning.main',
                                            p: 1,
                                            borderRadius: '8px',
                                            width: '45%',
                                        }}
                                    >
                                        <Typography
                                            variant="body2"
                                            sx={{ fontWeight: 'bold' }}
                                        >
                                            False: Sex {'>'} 0.5 (Female)
                                        </Typography>
                                        <Typography variant="caption">
                                            Samples: 441, Value: [149, 292]
                                        </Typography>
                                    </Box>
                                </Stack>
                                <Typography
                                    variant="caption"
                                    color="text.disabled"
                                    sx={{ mt: 2 }}
                                >
                                    (Actual tree visualizations are interactive
                                    and complex, requiring libraries like D3.js
                                    or specialized tools.)
                                </Typography>
                            </Box>
                        </Paper>
                    </Box>
                )

            default:
                return (
                    <Typography
                        variant="h6"
                        sx={{
                            textAlign: 'center',
                            py: 5,
                            color: 'text.secondary',
                        }}
                    >
                        Select a tab to view content.
                    </Typography>
                )
        }
    }

    return (
        <Box
            sx={{
                flexGrow: 1,
                display: 'flex',
                flexDirection: 'column',
                height: '100vh',
                bgcolor: 'background.default',
                py: 4,
                px: { xs: 2, sm: 3, md: 4 },
            }}
        >
            {/* Main Content Area */}

            {/* <Typography
                variant="h4"
                component="h4"
                sx={{ fontWeight: 700, color: 'text.primary', mb: 1 }}
            >
                XAI Report: Predicting survival on the Titanic
            </Typography> */}
            {/* <Link
                    href="#"
                    underline="none"
                    sx={{
                        color: 'primary.main',
                        display: 'flex',
                        alignItems: 'center',
                    }}
                >
                    Download Report{' '}
                    <DownloadIcon sx={{ fontSize: '1.2em', ml: 0.5 }} />
                </Link> */}

            {/* Tabs for Dashboard Sections */}
            <Paper
                elevation={0}
                sx={{
                    borderBottom: 1,
                    borderColor: 'divider',

                    borderRadius: '8px 8px 0 0',
                }}
            >
                <Tabs
                    value={activeTab}
                    onChange={handleTabChange}
                    aria-label="dashboard sections"
                    variant="scrollable"
                    scrollButtons="auto"
                    allowScrollButtonsMobile
                    sx={{
                        '& .MuiTabs-indicator': {
                            backgroundColor: 'secondary.main',
                        },
                        '& .MuiTab-root': {
                            textTransform: 'none',
                            fontWeight: 600,
                            color: 'text.secondary',
                        },
                        '& .Mui-selected': {
                            color: 'secondary.main',
                            fontWeight: 700,
                        },
                    }}
                >
                    <Tab label="What if..." />
                    <Tab label="Data drift" />
                    <Tab label="Fairness" />
                    <Tab label="Feature Importances" />
                    <Tab label="Classification Stats" />
                    <Tab label="Individual Predictions" />

                    <Tab label="Feature Dependence" />
                    <Tab label="Feature Interactions" />
                    <Tab label="Decision Trees" />
                </Tabs>
            </Paper>

            {/* Tab Content */}
            <Box
                sx={{
                    p: 3,
                    bgcolor: 'background.paper',
                    borderRadius: '0 0 8px 8px',
                    minHeight: '60vh',
                    boxShadow: '0 2px 10px rgba(0,0,0,0.05)',
                }}
            >
                {renderTabContent()}
            </Box>
        </Box>
    )
}

export default XAIDashboardPage
