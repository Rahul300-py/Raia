import {
    Box,
    Button,
    Card,
    CardContent,
    TextField,
    Typography,
    InputAdornment,
    IconButton,
    Avatar,
    Link as MuiLink,
} from '@mui/material'
import {
    Email,
    Lock,
    Visibility,
    VisibilityOff,
    ArrowBack,
} from '@mui/icons-material'
import { useNavigate, Link } from 'react-router-dom'
import { useState } from 'react'

function LoginPage() {
    const navigate = useNavigate()
    const [showPassword, setShowPassword] = useState(false)

    const handleLogin = () => {
        // Add authentication logic here
        navigate('/home')
    }

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword)
    }

    const handleGoBack = () => {
        navigate(-1) // Go to previous page
    }

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="100vh"
            sx={{
                background:
                    'radial-gradient(ellipse at center, rgba(230,247,250,1) 0%, rgba(240,230,250,1) 50%, rgba(255,255,255,0) 100%)',
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                width: '100%',
            }}
        >
            <Card
                sx={{
                    width: 400,
                    borderRadius: 3,
                    boxShadow: 6,
                    maxWidth: '90%',
                }}
            >
                <CardContent sx={{ textAlign: 'center', position: 'relative' }}>
                    {/* Go Back Arrow */}
                    <IconButton
                        onClick={handleGoBack}
                        sx={{ position: 'absolute', left: 8, top: 8 }}
                        aria-label="Go back"
                    >
                        <ArrowBack />
                    </IconButton>

                    {/* Logo */}
                    <Avatar
                        src="/logo.png"
                        alt="XAI"
                        sx={{ width: 80, height: 80, mx: 'auto', mb: 1 }}
                        variant="rounded"
                    />
                    <Typography variant="h4" gutterBottom>
                        Welcome Back
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Please login to your account
                    </Typography>

                    <TextField
                        label="Email"
                        type="email"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Email />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label="Password"
                        type={showPassword ? 'text' : 'password'}
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Lock />
                                </InputAdornment>
                            ),
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={togglePasswordVisibility}
                                        edge="end"
                                    >
                                        {showPassword ? (
                                            <VisibilityOff />
                                        ) : (
                                            <Visibility />
                                        )}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                    />

                    <Button
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                        sx={{ mt: 2, mb: 2 }}
                        onClick={handleLogin}
                    >
                        Login
                    </Button>

                    <Typography variant="body2">
                        New to XAI?{' '}
                        <MuiLink
                            component={Link}
                            to="/signup"
                            underline="hover"
                            color="highlight.main"
                        >
                            Sign up
                        </MuiLink>
                    </Typography>
                </CardContent>
            </Card>
        </Box>
    )
}

export default LoginPage
