import {
    Box,
    Button,
    Card,
    CardContent,
    TextField,
    Typography,
    InputAdornment,
    IconButton,
    Avatar,
    Link as MuiLink,
} from '@mui/material'
import {
    Email,
    Lock,
    Person,
    Visibility,
    VisibilityOff,
    ArrowBack,
} from '@mui/icons-material'
import { useState } from 'react'
import { useNavigate, Link } from 'react-router-dom'

function SignupPage() {
    const navigate = useNavigate()
    const [showPassword, setShowPassword] = useState(false)

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword)
    }

    const handleSignup = () => {
        // Add sign-up logic here
        navigate('/home')
    }

    const handleGoBack = () => {
        navigate(-1) // Go to the previous page
    }

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="100vh"
            sx={{
                background:
                    'radial-gradient(ellipse at center, rgba(230,247,250,1) 0%, rgba(240,230,250,1) 50%, rgba(255,255,255,0) 100%)',
                backgroundSize: 'contain',
                backgroundRepeat: 'no-repeat',
                width: '100%',
            }}
        >
            <Card
                sx={{
                    width: 400,
                    borderRadius: 3,
                    boxShadow: 6,
                    maxWidth: '90%',
                }}
            >
                <CardContent sx={{ textAlign: 'center', position: 'relative' }}>
                    {/* Go Back Arrow */}
                    <IconButton
                        onClick={handleGoBack}
                        sx={{ position: 'absolute', left: 8, top: 8 }}
                        aria-label="Go back"
                    >
                        <ArrowBack />
                    </IconButton>

                    {/* Logo */}
                    <Avatar
                        src="/logo.png"
                        alt="XAI"
                        sx={{ width: 80, height: 80, mx: 'auto', mb: 1 }}
                        variant="rounded"
                    />

                    <Typography variant="h4" gutterBottom>
                        Create Account
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Join us to explore XAI
                    </Typography>

                    <TextField
                        label="Full Name"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Person />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label="Email"
                        type="email"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Email />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label="Password"
                        type={showPassword ? 'text' : 'password'}
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Lock />
                                </InputAdornment>
                            ),
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={togglePasswordVisibility}
                                        edge="end"
                                    >
                                        {showPassword ? (
                                            <VisibilityOff />
                                        ) : (
                                            <Visibility />
                                        )}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                    />

                    <Button
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                        sx={{ mt: 2, mb: 2 }}
                        onClick={handleSignup}
                    >
                        Sign Up
                    </Button>

                    <Typography variant="body2">
                        Already have an account?{' '}
                        <MuiLink
                            component={Link}
                            to="/login"
                            underline="hover"
                            color="highlight.main"
                        >
                            Login
                        </MuiLink>
                    </Typography>
                </CardContent>
            </Card>
        </Box>
    )
}

export default SignupPage
