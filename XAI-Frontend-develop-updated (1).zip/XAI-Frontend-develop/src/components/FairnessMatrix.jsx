import React, { useState } from 'react'
import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
} from '@mui/material'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    Legend,
    ResponsiveContainer,
} from 'recharts'

// --- Mock Data for Fairness Dashboard ---
// This data simulates model performance across different demographic groups.
// In a real application, these metrics would be computed by a backend service
// analyzing your model's predictions on historical or live data.
const mockFairnessData = {
    overallPerformance: {
        accuracy: 0.82,
        precision: 0.75,
        recall: 0.7,
        f1Score: 0.72,
    },
    sensitiveAttributes: [
        {
            name: 'Sex',
            groups: [
                {
                    label: 'Female',
                    metrics: {
                        accuracy: 0.9, // Model performs better for females
                        precision: 0.85,
                        recall: 0.88,
                        f1Score: 0.86,
                        tpr: 0.88, // True Positive Rate (Sensitivity)
                        fpr: 0.05, // False Positive Rate
                        fnr: 0.12, // False Negative Rate
                    },
                    actual: { survived: 233, notSurvived: 81 },
                    predicted: { survived: 200, notSurvived: 114 },
                },
                {
                    label: 'Male',
                    metrics: {
                        accuracy: 0.7, // Model performs worse for males
                        precision: 0.6,
                        recall: 0.5,
                        f1Score: 0.55,
                        tpr: 0.5,
                        fpr: 0.2,
                        fnr: 0.5,
                    },
                    actual: { survived: 109, notSurvived: 468 },
                    predicted: { survived: 150, notSurvived: 427 },
                },
            ],
        },
        {
            name: 'PClass',
            groups: [
                {
                    label: '1st Class',
                    metrics: {
                        accuracy: 0.92,
                        precision: 0.9,
                        recall: 0.95,
                        f1Score: 0.92,
                        tpr: 0.95,
                        fpr: 0.03,
                        fnr: 0.05,
                    },
                    actual: { survived: 136, notSurvived: 80 },
                    predicted: { survived: 140, notSurvived: 76 },
                },
                {
                    label: '2nd Class',
                    metrics: {
                        accuracy: 0.85,
                        precision: 0.8,
                        recall: 0.82,
                        f1Score: 0.81,
                        tpr: 0.82,
                        fpr: 0.1,
                        fnr: 0.18,
                    },
                    actual: { survived: 87, notSurvived: 97 },
                    predicted: { survived: 85, notSurvived: 99 },
                },
                {
                    label: '3rd Class',
                    metrics: {
                        accuracy: 0.65,
                        precision: 0.55,
                        recall: 0.4,
                        f1Score: 0.46,
                        tpr: 0.4,
                        fpr: 0.3,
                        fnr: 0.6,
                    },
                    actual: { survived: 119, notSurvived: 372 },
                    predicted: { survived: 100, notSurvived: 391 },
                },
            ],
        },
        {
            name: 'Age Group',
            groups: [
                {
                    label: 'Child (<18)',
                    metrics: {
                        accuracy: 0.88,
                        precision: 0.8,
                        recall: 0.85,
                        f1Score: 0.82,
                        tpr: 0.85,
                        fpr: 0.08,
                        fnr: 0.15,
                    },
                    actual: { survived: 61, notSurvived: 49 },
                    predicted: { survived: 65, notSurvived: 45 },
                },
                {
                    label: 'Adult (18-60)',
                    metrics: {
                        accuracy: 0.8,
                        precision: 0.72,
                        recall: 0.68,
                        f1Score: 0.7,
                        tpr: 0.68,
                        fpr: 0.18,
                        fnr: 0.32,
                    },
                    actual: { survived: 250, notSurvived: 400 },
                    predicted: { survived: 240, notSurvived: 410 },
                },
                {
                    label: 'Elderly (>60)',
                    metrics: {
                        accuracy: 0.6,
                        precision: 0.45,
                        recall: 0.3,
                        f1Score: 0.36,
                        tpr: 0.3,
                        fpr: 0.4,
                        fnr: 0.7,
                    },
                    actual: { survived: 18, notSurvived: 40 },
                    predicted: { survived: 15, notSurvived: 43 },
                },
            ],
        },
    ],
}

// Helper for status color mapping (e.g., for disparity)
const getDisparityColor = (disparity) => {
    if (Math.abs(disparity) > 0.15) return 'error' // High disparity
    if (Math.abs(disparity) > 0.05) return 'warning' // Moderate disparity
    return 'success' // Low disparity
}

const FairnessDashboard = () => {
    const [selectedAttribute, setSelectedAttribute] = useState('Sex') // Default sensitive attribute to view

    // Find the data for the currently selected sensitive attribute
    const currentAttributeData = mockFairnessData.sensitiveAttributes.find(
        (attr) => attr.name === selectedAttribute
    )

    // Prepare data for the comparison bar charts
    // We'll create separate datasets for each metric (Accuracy, TPR, FPR, etc.)
    const chartMetrics = [
        'accuracy',
        'tpr',
        'fpr',
        'precision',
        'recall',
        'f1Score',
    ]
    const chartData = {}
    chartMetrics.forEach((metric) => {
        chartData[metric] =
            currentAttributeData?.groups.map((group) => ({
                name: group.label,
                value: group.metrics[metric],
            })) || []
    })

    // Calculate disparity (difference from the first group as a reference)
    const referenceGroup = currentAttributeData?.groups[0]
    const disparityMetrics = {}
    if (referenceGroup) {
        chartMetrics.forEach((metric) => {
            currentAttributeData?.groups.forEach((group, index) => {
                if (index > 0) {
                    // Compare to reference group (index 0)
                    const diff =
                        group.metrics[metric] - referenceGroup.metrics[metric]
                    disparityMetrics[
                        `${group.label} vs ${referenceGroup.label} ${metric}`
                    ] = diff
                }
            })
        })
    }

    return (
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
            <Box
                item
                xs={12}
                width="100%"
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}
            >
                <Typography variant="h4" sx={{ fontWeight: 600, mb: 2 }}>
                    Titanic Survival: Fairness Analysis Dashboard
                </Typography>
                <Button
                    variant="contained"
                    startIcon={<PlayArrowIcon />}
                    sx={{ mb: 2 }}
                >
                    Explain with AI
                </Button>
            </Box>

            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 4 }}>
                Evaluate model performance across different demographic groups
                to assess fairness and identify potential biases.
            </Typography>

            <Grid container spacing={3}>
                {/* Overall Model Performance */}
                <Grid item xs={12}>
                    <Paper
                        elevation={3}
                        sx={{
                            p: 3,
                            borderRadius: '12px',
                            display: 'flex',
                            flexDirection: 'column',
                            height: '100%',
                        }}
                    >
                        <Typography variant="h5" sx={{ mb: 2 }}>
                            Overall Model Performance
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <Grid container spacing={2}>
                            <Grid item xs={6} sm={3} md={3} lg={3} xl={3}>
                                <Typography variant="h6" color="primary">
                                    Accuracy
                                </Typography>
                                <Typography variant="h4">
                                    {mockFairnessData.overallPerformance.accuracy.toFixed(
                                        2
                                    )}
                                </Typography>
                            </Grid>
                            <Grid item xs={6} sm={3} md={3} lg={3} xl={3}>
                                <Typography variant="h6" color="primary">
                                    Precision
                                </Typography>
                                <Typography variant="h4">
                                    {mockFairnessData.overallPerformance.precision.toFixed(
                                        2
                                    )}
                                </Typography>
                            </Grid>
                            <Grid item xs={6} sm={3} md={3} lg={3} xl={3}>
                                <Typography variant="h6" color="primary">
                                    Recall
                                </Typography>
                                <Typography variant="h4">
                                    {mockFairnessData.overallPerformance.recall.toFixed(
                                        2
                                    )}
                                </Typography>
                            </Grid>
                            <Grid item xs={6} sm={3} md={3} lg={3} xl={3}>
                                <Typography variant="h6" color="primary">
                                    F1-Score
                                </Typography>
                                <Typography variant="h4">
                                    {mockFairnessData.overallPerformance.f1Score.toFixed(
                                        2
                                    )}
                                </Typography>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>

                {/* Sensitive Attribute Selection */}
                {/* Moved to align better with other elements and provide clear control */}
                <Grid item xs={12} md={6} lg={4} xl={3}>
                    {' '}
                    {/* Reduced width on larger screens for a tighter fit */}
                    <Paper
                        elevation={3}
                        sx={{
                            p: 3,
                            borderRadius: '12px',
                            height: '100%',
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                        }}
                    >
                        <Typography variant="h5" sx={{ mb: 2 }}>
                            Select Attribute
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <FormControl fullWidth>
                            <InputLabel id="sensitive-attribute-select-label">
                                Sensitive Attribute
                            </InputLabel>
                            <Select
                                labelId="sensitive-attribute-select-label"
                                value={selectedAttribute}
                                label="Sensitive Attribute"
                                onChange={(e) =>
                                    setSelectedAttribute(e.target.value)
                                }
                            >
                                {mockFairnessData.sensitiveAttributes.map(
                                    (attr) => (
                                        <MenuItem
                                            key={attr.name}
                                            value={attr.name}
                                        >
                                            {attr.name}
                                        </MenuItem>
                                    )
                                )}
                            </Select>
                        </FormControl>
                    </Paper>
                </Grid>

                {/* Performance Metrics by Group (Bar Charts) */}
                {currentAttributeData && (
                    <>
                        {/* Adjusted xl size for the first two charts to be next to the selector */}
                        <Grid item xs={12} md={6} lg={8} xl={4.5}>
                            {' '}
                            {/* Occupies remaining space next to selector */}
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: '12px',
                                    height: '100%',
                                }}
                            >
                                <Typography variant="h5" sx={{ mb: 2 }}>
                                    Accuracy by {selectedAttribute}
                                </Typography>
                                <ResponsiveContainer width="100%" height={250}>
                                    <BarChart data={chartData.accuracy}>
                                        <XAxis dataKey="name" />
                                        <YAxis
                                            domain={[0, 1]}
                                            tickFormatter={(tick) =>
                                                (tick * 100).toFixed(0) + '%'
                                            }
                                        />
                                        <Tooltip
                                            formatter={(value) =>
                                                (value * 100).toFixed(2) + '%'
                                            }
                                        />
                                        <Bar dataKey="value" fill="#8884d8" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>
                        <Grid item xs={12} md={6} lg={6} xl={4.5}>
                            {' '}
                            {/* Occupies remaining space next to selector */}
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: '12px',
                                    height: '100%',
                                }}
                            >
                                <Typography variant="h5" sx={{ mb: 2 }}>
                                    True Positive Rate (Recall) by{' '}
                                    {selectedAttribute}
                                </Typography>
                                <ResponsiveContainer width="100%" height={250}>
                                    <BarChart data={chartData.tpr}>
                                        <XAxis dataKey="name" />
                                        <YAxis
                                            domain={[0, 1]}
                                            tickFormatter={(tick) =>
                                                (tick * 100).toFixed(0) + '%'
                                            }
                                        />
                                        <Tooltip
                                            formatter={(value) =>
                                                (value * 100).toFixed(2) + '%'
                                            }
                                        />
                                        <Bar dataKey="value" fill="#82ca9d" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>
                        {/* Remaining two charts on a new row for visual balance */}
                        <Grid item xs={12} md={6} lg={6} xl={6}>
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: '12px',
                                    height: '100%',
                                }}
                            >
                                <Typography variant="h5" sx={{ mb: 2 }}>
                                    False Positive Rate by {selectedAttribute}
                                </Typography>
                                <ResponsiveContainer width="100%" height={250}>
                                    <BarChart data={chartData.fpr}>
                                        <XAxis dataKey="name" />
                                        <YAxis
                                            domain={[0, 1]}
                                            tickFormatter={(tick) =>
                                                (tick * 100).toFixed(0) + '%'
                                            }
                                        />
                                        <Tooltip
                                            formatter={(value) =>
                                                (value * 100).toFixed(2) + '%'
                                            }
                                        />
                                        <Bar dataKey="value" fill="#ffc658" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>
                        <Grid item xs={12} md={6} lg={6} xl={6}>
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: '12px',
                                    height: '100%',
                                }}
                            >
                                <Typography variant="h5" sx={{ mb: 2 }}>
                                    F1-Score by {selectedAttribute}
                                </Typography>
                                <ResponsiveContainer width="100%" height={250}>
                                    <BarChart data={chartData.f1Score}>
                                        <XAxis dataKey="name" />
                                        <YAxis
                                            domain={[0, 1]}
                                            tickFormatter={(tick) =>
                                                (tick * 100).toFixed(0) + '%'
                                            }
                                        />
                                        <Tooltip
                                            formatter={(value) =>
                                                (value * 100).toFixed(2) + '%'
                                            }
                                        />
                                        <Bar dataKey="value" fill="#ff7300" />
                                    </BarChart>
                                </ResponsiveContainer>
                            </Paper>
                        </Grid>

                        {/* Disparity Metrics (Difference from Reference Group) */}
                        <Grid item xs={12}>
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: '12px',
                                    height: '100%',
                                }}
                            >
                                <Typography variant="h5" sx={{ mb: 2 }}>
                                    Disparity Metrics (Compared to{' '}
                                    {referenceGroup?.label || 'Reference Group'}
                                    )
                                </Typography>
                                <Divider sx={{ mb: 2 }} />
                                <Grid container spacing={2}>
                                    {Object.entries(disparityMetrics).map(
                                        ([key, value]) => (
                                            <Grid
                                                item
                                                xs={12}
                                                sm={6}
                                                md={4}
                                                lg={4}
                                                xl={3}
                                                key={key}
                                            >
                                                <Box
                                                    sx={{
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        mb: 1,
                                                    }}
                                                >
                                                    <Typography
                                                        variant="body1"
                                                        sx={{ flexGrow: 1 }}
                                                    >
                                                        {key
                                                            .split(' ')
                                                            .slice(0, -1)
                                                            .join(' ')}
                                                        :
                                                    </Typography>
                                                    <Chip
                                                        label={`${(value * 100).toFixed(2)}%`}
                                                        color={getDisparityColor(
                                                            value
                                                        )}
                                                        sx={{ ml: 1 }}
                                                    />
                                                    <Typography
                                                        variant="body2"
                                                        color="text.secondary"
                                                        ml={1}
                                                    >
                                                        ({key.split(' ').pop()})
                                                    </Typography>
                                                </Box>
                                            </Grid>
                                        )
                                    )}
                                </Grid>
                            </Paper>
                        </Grid>

                        {/* Actual vs. Predicted Counts Table */}
                        <Grid item xs={12}>
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 3,
                                    borderRadius: '12px',
                                    height: '100%',
                                }}
                            >
                                <Typography variant="h5" sx={{ mb: 2 }}>
                                    Actual vs. Predicted Counts by{' '}
                                    {selectedAttribute}
                                </Typography>
                                <TableContainer>
                                    <Table size="small">
                                        <TableHead>
                                            <TableRow>
                                                <TableCell>Group</TableCell>
                                                <TableCell
                                                    align="center"
                                                    colSpan={2}
                                                >
                                                    Actual
                                                </TableCell>
                                                <TableCell
                                                    align="center"
                                                    colSpan={2}
                                                >
                                                    Predicted
                                                </TableCell>
                                            </TableRow>
                                            <TableRow>
                                                <TableCell></TableCell>
                                                <TableCell>Survived</TableCell>
                                                <TableCell>
                                                    Not Survived
                                                </TableCell>
                                                <TableCell>Survived</TableCell>
                                                <TableCell>
                                                    Not Survived
                                                </TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {currentAttributeData.groups.map(
                                                (group) => (
                                                    <TableRow key={group.label}>
                                                        <TableCell
                                                            component="th"
                                                            scope="row"
                                                        >
                                                            {group.label}
                                                        </TableCell>
                                                        <TableCell>
                                                            {
                                                                group.actual
                                                                    .survived
                                                            }
                                                        </TableCell>
                                                        <TableCell>
                                                            {
                                                                group.actual
                                                                    .notSurvived
                                                            }
                                                        </TableCell>
                                                        <TableCell>
                                                            {
                                                                group.predicted
                                                                    .survived
                                                            }
                                                        </TableCell>
                                                        <TableCell>
                                                            {
                                                                group.predicted
                                                                    .notSurvived
                                                            }
                                                        </TableCell>
                                                    </TableRow>
                                                )
                                            )}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Grid>
                    </>
                )}
            </Grid>
        </Container>
    )
}

export default FairnessDashboard
