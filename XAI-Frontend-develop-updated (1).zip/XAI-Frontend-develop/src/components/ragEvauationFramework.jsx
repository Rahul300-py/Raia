import React from 'react'
import {
    Box,
    Container,
    Grid,
    Paper,
    Typography,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import EmojiObjectsIcon from '@mui/icons-material/EmojiObjects'
import FlashOnIcon from '@mui/icons-material/FlashOn'
import SecurityIcon from '@mui/icons-material/Security'

const sections = [
    {
        title: 'Response Quality Metrics',
        icon: <EmojiObjectsIcon />,
        description: 'Multi-dimensional assessment of LLM outputs',
        items: [
            [
                'Coherence Score',
                'Semantic consistency and logical flow analysis',
            ],
            ['Fluency Metrics', 'Grammar, syntax, and readability assessment'],
            ['Relevance Scoring', 'Query-response alignment measurement'],
            ['Completeness Check', 'Answer comprehensiveness evaluation'],
            ['Creativity Index', 'Novelty and originality measurement'],
        ],
    },
    {
        title: 'Hallucination Detection',
        icon: <FlashOnIcon />,
        description:
            'Advanced framework for identifying and quantifying hallucinations',
        items: [
            ['Factual Grounding', 'Cross-reference with knowledge bases'],
            ['Consistency Checking', 'Multi-query validation framework'],
            ['Source Attribution', 'Verify claims against provided context'],
            [
                'Confidence Calibration',
                'Uncertainty quantification in responses',
            ],
            [
                'Hallucination Taxonomy',
                'Categorize intrinsic vs extrinsic hallucinations',
            ],
        ],
    },
    {
        title: 'Safety & Alignment',
        icon: <SecurityIcon />,
        description:
            'Ensure LLM outputs align with safety guidelines and ethical standards',
        items: [
            [
                'Toxicity Detection',
                'Multi-label harmful content classification',
            ],
            ['Bias Assessment', 'Demographic and ideological bias scoring'],
            ['Prompt Injection Detection', 'Security vulnerability scanning'],
            [
                'Jailbreak Attempts',
                'Identify bypass attempts of safety measures',
            ],
            ['Value Alignment', 'Measure adherence to specified principles'],
        ],
    },
    {
        title: 'Performance Benchmarks',
        icon: <SecurityIcon />,
        description:
            'Comprehensive performance evaluation across standard benchmarks',
        items: [
            ['Task-Specific Metrics:', 'BLEU, ROUGE, BERTScore, METEOR'],
            ['Reasoning Capabilities:', 'Chain-of-thought evaluation'],
            ['Multi-turn Dialogue:', 'Context retention and coherence'],
            ['Multilingual Assessment:', 'Cross-lingual performance'],
            ['Domain Expertise:', 'Specialized knowledge evaluation'],
        ],
    },
]

const RagEvaluationFramework = () => {
    return (
        <Box
            sx={{
                color: '#fff',
                py: 8,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="h3"
                    sx={{
                        color: '#B4A3FF',
                        fontWeight: 700,
                        mb: 2,
                        textAlign: 'center',
                    }}
                >
                    LLM & RAG Evaluation Frameworks
                </Typography>
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'center',
                        maxWidth: '600px',
                        mx: 'auto',
                    }}
                >
                    Comprehensive evaluation suite for Large Language Models and
                    Retrieval-Augmented Generation systems
                </Typography>
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'left',
                        maxWidth: '600px',
                    }}
                >
                    🤖 Large Language Model Evaluation
                </Typography>

                {/*  Large Language Model Evaluation */}
                <Grid container spacing={3}>
                    {sections.map((section, idx) => (
                        <Grid item xs={12} md={4} key={idx}>
                            <Paper
                                elevation={0}
                                sx={{
                                    border: '1px solid rgb(16, 17, 17)',
                                    borderRadius: '16px',
                                    p: 3,
                                    height: '100%',
                                    maxWidth: '360px',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 1,
                                        mb: 2,
                                    }}
                                >
                                    <Box
                                        sx={{
                                            background:
                                                'linear-gradient(135deg, #8B5CF6, #6366F1)',
                                            borderRadius: '10px',
                                            p: 1,
                                            display: 'flex',
                                        }}
                                    >
                                        {section.icon}
                                    </Box>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 700 }}
                                    >
                                        {section.title}
                                    </Typography>
                                </Box>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        mb: 2,
                                    }}
                                >
                                    {section.description}
                                </Typography>
                                <List dense>
                                    {section.items.map(([label, text], i) => (
                                        <ListItem key={i} disableGutters>
                                            <ListItemIcon
                                                sx={{
                                                    minWidth: '30px',
                                                }}
                                            >
                                                <CheckCircleIcon fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText
                                                primary={
                                                    <Box component="span">
                                                        <Typography
                                                            component="span"
                                                            sx={{
                                                                fontWeight: 600,
                                                            }}
                                                        >
                                                            {label}:{' '}
                                                        </Typography>
                                                        <Typography
                                                            component="span"
                                                            sx={{}}
                                                        >
                                                            {text}
                                                        </Typography>
                                                    </Box>
                                                }
                                            />
                                        </ListItem>
                                    ))}
                                </List>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>

                {/* RAG System Evaluation */}
            </Container>
        </Box>
    )
}

export default RagEvaluationFramework
