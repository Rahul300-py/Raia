// src/components/ContentPreviewSection.js
import React from 'react'
import {
    Box,
    Typography,
    Paper,
    Grid,
    Stack,
    Container,
    Link,
} from '@mui/material'
// import CheckCircleIcon from '@mui/icons-material/CheckCircle'
// import WarningIcon from '@mui/icons-material/Warning'
// import ArrowForwardIcon from '@mui/icons-material/ArrowForward'

const features = [
    {
        icon: '🔍',
        title: 'Deep Explainability',
        description:
            'SHAP, LIME, and What-if Analysis for complete model transparency across all ML architectures.',
    },
    {
        icon: '📊',
        title: 'Drift Detection',
        description:
            'Real-time monitoring of data drift, model drift, and performance degradation with intelligent alerts.',
    },
    {
        icon: '⚖️',
        title: 'Fairness Analytics',
        description:
            'Comprehensive bias detection and mitigation strategies for ethical AI deployment.',
    },
]

const ContentPreviewSection = () => {
    return (
        <Container
            maxWidth="lg"
            sx={{
                mt: { xs: 5, md: 10 },
                py: 5,
                position: 'relative',
                zIndex: 2,
            }}
        >
            <Grid
                container
                spacing={4}
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    flexWrap: 'wrap',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                }}
            >
                {features.map((feature, index) => (
                    <Grid item xs={12} sm={6} md={3} key={index} flex={1}>
                        <Stack
                            spacing={2}
                            sx={{
                                p: 3,
                                border: '3px solid white',
                                borderRadius: '16px',
                                height: '100%',
                                cursor: 'pointer',
                                alignItems: 'center',
                                textAlign: 'center',
                                transition: 'all 0.3s ease',
                                '&:hover': {
                                    boxShadow: '0 6px 20px rgba(0,0,0,0.08)',
                                    transform: 'translateY(-3px)',
                                },
                            }}
                        >
                            <Box
                                sx={{
                                    color: 'highlight.main',
                                    fontSize: 40,
                                }}
                            >
                                {feature.icon}
                            </Box>
                            <Typography variant="h6" sx={{ fontWeight: 600 }}>
                                {feature.title}
                            </Typography>
                            <Typography
                                variant="body2"
                                sx={{
                                    color: 'text.secondary',
                                    flexGrow: 1,
                                }}
                            >
                                {feature.description}
                            </Typography>
                        </Stack>
                    </Grid>
                ))}
            </Grid>
        </Container>

        // <Container
        //     maxWidth="lg"
        //     sx={{
        //         mt: { xs: 5, md: 10 },
        //         py: 5,
        //         position: 'relative',
        //         zIndex: 2,
        //     }}
        // >
        //     <Grid container spacing={3} justifyContent="center">
        //         {/* Conversation Card */}
        //         <Grid item xs={12} md={5}>
        //             <Paper
        //                 elevation={3}
        //                 sx={{
        //                     p: 4,
        //                     borderRadius: '15px',
        //                     minHeight: { xs: 'auto', md: '450px' },
        //                     display: 'flex',
        //                     flexDirection: 'column',
        //                 }}
        //             >
        //                 <Typography
        //                     variant="h5"
        //                     sx={{ fontWeight: 600, mb: 3 }}
        //                 >
        //                     Conversation
        //                 </Typography>
        //                 <Box
        //                     sx={{
        //                         backgroundColor: '#f5f5f5',
        //                         p: 3,
        //                         borderRadius: '8px',
        //                         flexGrow: 1,
        //                         display: 'flex',
        //                         flexDirection: 'column',
        //                         justifyContent: 'space-between', // Distribute content
        //                         color: 'text.secondary',
        //                     }}
        //                 >
        //                     <Stack
        //                         direction="row"
        //                         alignItems="center"
        //                         spacing={1}
        //                         sx={{ mb: 2 }}
        //                     >
        //                         <Box
        //                             sx={{
        //                                 width: 10,
        //                                 height: 10,
        //                                 borderRadius: '50%',
        //                                 bgcolor: 'primary.main',
        //                             }}
        //                         />
        //                         <Typography
        //                             variant="body2"
        //                             sx={{ fontWeight: 'bold' }}
        //                         >
        //                             Agent • 5m
        //                         </Typography>
        //                     </Stack>
        //                     <Box
        //                         sx={{
        //                             backgroundColor: 'white',
        //                             height: 20,
        //                             borderRadius: '4px',
        //                             mb: 1,
        //                             width: '80%',
        //                         }}
        //                     />
        //                     <Box
        //                         sx={{
        //                             backgroundColor: 'white',
        //                             height: 20,
        //                             borderRadius: '4px',
        //                             width: '60%',
        //                         }}
        //                     />

        //                     <Stack
        //                         direction="row"
        //                         alignItems="center"
        //                         spacing={1}
        //                         sx={{ mt: 3, mb: 2 }}
        //                     >
        //                         <Box
        //                             sx={{
        //                                 width: 10,
        //                                 height: 10,
        //                                 borderRadius: '50%',
        //                                 bgcolor: 'grey.500',
        //                             }}
        //                         />
        //                         <Typography
        //                             variant="body2"
        //                             sx={{ fontWeight: 'bold' }}
        //                         >
        //                             User • 3m
        //                         </Typography>
        //                     </Stack>
        //                     <Box
        //                         sx={{
        //                             backgroundColor: 'white',
        //                             height: 20,
        //                             borderRadius: '4px',
        //                             width: '70%',
        //                         }}
        //                     />

        //                     <Stack
        //                         direction="row"
        //                         alignItems="center"
        //                         spacing={1}
        //                         sx={{ mt: 3, mb: 2 }}
        //                     >
        //                         <Box
        //                             sx={{
        //                                 width: 10,
        //                                 height: 10,
        //                                 borderRadius: '50%',
        //                                 bgcolor: 'primary.main',
        //                             }}
        //                         />
        //                         <Typography
        //                             variant="body2"
        //                             sx={{ fontWeight: 'bold' }}
        //                         >
        //                             Agent • 3m
        //                         </Typography>
        //                     </Stack>
        //                     <Box
        //                         sx={{
        //                             backgroundColor: 'white',
        //                             height: 20,
        //                             borderRadius: '4px',
        //                             mb: 1,
        //                             width: '75%',
        //                         }}
        //                     />
        //                     <Box
        //                         sx={{
        //                             backgroundColor: 'white',
        //                             height: 20,
        //                             borderRadius: '4px',
        //                             width: '50%',
        //                         }}
        //                     />
        //                 </Box>
        //             </Paper>
        //         </Grid>

        //         {/* Evaluations Card */}
        //         <Grid item xs={12} md={7}>
        //             <Paper
        //                 elevation={3}
        //                 sx={{
        //                     p: 4,
        //                     borderRadius: '15px',
        //                     minHeight: { xs: 'auto', md: '450px' },
        //                     display: 'flex',
        //                     flexDirection: 'column',
        //                 }}
        //             >
        //                 <Typography
        //                     variant="h5"
        //                     sx={{ fontWeight: 600, mb: 3 }}
        //                 >
        //                     Evaluations
        //                 </Typography>
        //                 <Grid container spacing={3}>
        //                     {/* Safety */}
        //                     <Grid item xs={12} sm={6}>
        //                         <Box
        //                             sx={{
        //                                 border: '1px solid #eee',
        //                                 borderRadius: '8px',
        //                                 p: 2,
        //                             }}
        //                         >
        //                             <Stack
        //                                 direction="row"
        //                                 alignItems="center"
        //                                 justifyContent="space-between"
        //                                 mb={1}
        //                             >
        //                                 <Typography variant="body1">
        //                                     Safety
        //                                 </Typography>
        //                                 <Box
        //                                     sx={{
        //                                         backgroundColor: '#e6ffe6',
        //                                         color: '#28a745',
        //                                         px: 1.5,
        //                                         py: 0.5,
        //                                         borderRadius: '15px',
        //                                         fontSize: '0.8em',
        //                                         fontWeight: 'bold',
        //                                         display: 'flex',
        //                                         alignItems: 'center',
        //                                     }}
        //                                 >
        //                                     Pass{' '}
        //                                     <CheckCircleIcon
        //                                         sx={{
        //                                             fontSize: '1em',
        //                                             ml: 0.5,
        //                                         }}
        //                                     />
        //                                 </Box>
        //                             </Stack>
        //                             {/* Chart Placeholder (Vertical bars) */}
        //                             <Stack
        //                                 direction="row"
        //                                 spacing={0.5}
        //                                 justifyContent="center"
        //                                 alignItems="flex-end"
        //                                 sx={{ height: '60px', mt: 1 }}
        //                             >
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '50%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '70%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '30%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '90%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '60%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '40%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '80%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '20%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '65%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                             </Stack>
        //                         </Box>
        //                     </Grid>

        //                     {/* Session Success */}
        //                     <Grid item xs={12} sm={6}>
        //                         <Box
        //                             sx={{
        //                                 border: '1px solid #eee',
        //                                 borderRadius: '8px',
        //                                 p: 2,
        //                             }}
        //                         >
        //                             <Stack
        //                                 direction="row"
        //                                 alignItems="center"
        //                                 justifyContent="space-between"
        //                                 mb={1}
        //                             >
        //                                 <Typography variant="body1">
        //                                     Session success
        //                                 </Typography>
        //                                 <Box
        //                                     sx={{
        //                                         backgroundColor: '#e6ffe6',
        //                                         color: '#28a745',
        //                                         px: 1.5,
        //                                         py: 0.5,
        //                                         borderRadius: '15px',
        //                                         fontSize: '0.8em',
        //                                         fontWeight: 'bold',
        //                                         display: 'flex',
        //                                         alignItems: 'center',
        //                                     }}
        //                                 >
        //                                     Pass{' '}
        //                                     <CheckCircleIcon
        //                                         sx={{
        //                                             fontSize: '1em',
        //                                             ml: 0.5,
        //                                         }}
        //                                     />
        //                                 </Box>
        //                             </Stack>
        //                             {/* Chart Placeholder (Horizontal bars) */}
        //                             <Stack
        //                                 direction="row"
        //                                 spacing={0.5}
        //                                 justifyContent="center"
        //                                 alignItems="flex-end"
        //                                 sx={{ height: '60px', mt: 1 }}
        //                             >
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '60%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '90%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '40%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '75%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '30%',
        //                                         bgcolor: 'error.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />{' '}
        //                                 {/* Red bar */}
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '80%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '50%',
        //                                         bgcolor: 'secondary.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '8%',
        //                                         height: '20%',
        //                                         bgcolor: 'error.main',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />{' '}
        //                                 {/* Red bar */}
        //                             </Stack>
        //                         </Box>
        //                     </Grid>

        //                     {/* Style */}
        //                     <Grid item xs={12} sm={6}>
        //                         <Box
        //                             sx={{
        //                                 border: '1px solid #eee',
        //                                 borderRadius: '8px',
        //                                 p: 2,
        //                             }}
        //                         >
        //                             <Stack
        //                                 direction="row"
        //                                 alignItems="center"
        //                                 justifyContent="space-between"
        //                                 mb={1}
        //                             >
        //                                 <Typography variant="body1">
        //                                     Style
        //                                 </Typography>
        //                                 <Box
        //                                     sx={{
        //                                         backgroundColor: '#fffbe6', // Light yellow
        //                                         color: '#ffc107', // Dark yellow
        //                                         px: 1.5,
        //                                         py: 0.5,
        //                                         borderRadius: '15px',
        //                                         fontSize: '0.8em',
        //                                         fontWeight: 'bold',
        //                                         display: 'flex',
        //                                         alignItems: 'center',
        //                                     }}
        //                                 >
        //                                     Warning{' '}
        //                                     <WarningIcon
        //                                         sx={{
        //                                             fontSize: '1em',
        //                                             ml: 0.5,
        //                                         }}
        //                                     />
        //                                 </Box>
        //                             </Stack>
        //                             {/* Chart Placeholder (Orange bars) */}
        //                             <Stack
        //                                 direction="row"
        //                                 spacing={0.5}
        //                                 justifyContent="center"
        //                                 alignItems="flex-end"
        //                                 sx={{ height: '60px', mt: 1 }}
        //                             >
        //                                 <Box
        //                                     sx={{
        //                                         width: '15%',
        //                                         height: '70%',
        //                                         bgcolor: '#ff8c00',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '15%',
        //                                         height: '40%',
        //                                         bgcolor: '#ff8c00',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '15%',
        //                                         height: '80%',
        //                                         bgcolor: '#ff8c00',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                                 <Box
        //                                     sx={{
        //                                         width: '15%',
        //                                         height: '50%',
        //                                         bgcolor: '#ff8c00',
        //                                         borderRadius: '3px',
        //                                     }}
        //                                 />
        //                             </Stack>
        //                         </Box>
        //                     </Grid>

        //                     {/* Relevance */}
        //                     <Grid item xs={12} sm={6}>
        //                         <Box
        //                             sx={{
        //                                 border: '1px solid #eee',
        //                                 borderRadius: '8px',
        //                                 p: 2,
        //                             }}
        //                         >
        //                             <Stack
        //                                 direction="row"
        //                                 alignItems="center"
        //                                 justifyContent="space-between"
        //                                 mb={1}
        //                             >
        //                                 <Typography variant="body1">
        //                                     Relevance
        //                                 </Typography>
        //                                 <Box
        //                                     sx={{
        //                                         backgroundColor: '#e6ffe6',
        //                                         color: '#28a745',
        //                                         px: 1.5,
        //                                         py: 0.5,
        //                                         borderRadius: '15px',
        //                                         fontSize: '0.8em',
        //                                         fontWeight: 'bold',
        //                                         display: 'flex',
        //                                         alignItems: 'center',
        //                                     }}
        //                                 >
        //                                     Pass{' '}
        //                                     <CheckCircleIcon
        //                                         sx={{
        //                                             fontSize: '1em',
        //                                             ml: 0.5,
        //                                         }}
        //                                     />
        //                                 </Box>
        //                             </Stack>
        //                             {/* Chart Placeholder (Line graph) */}
        //                             <Box
        //                                 sx={{
        //                                     backgroundColor: '#eee',
        //                                     height: '60px',
        //                                     borderRadius: '5px',
        //                                     position: 'relative',
        //                                     overflow: 'hidden', // Hide overflow from SVG or canvas if real
        //                                 }}
        //                             >
        //                                 {/* Simplified SVG for wavy lines - for demonstration only */}
        //                                 <svg
        //                                     width="100%"
        //                                     height="100%"
        //                                     viewBox="0 0 100 60"
        //                                     preserveAspectRatio="none"
        //                                 >
        //                                     <path
        //                                         d="M 0 50 Q 25 30 50 40 T 100 20"
        //                                         stroke="purple"
        //                                         fill="none"
        //                                         strokeWidth="2"
        //                                     />
        //                                     <path
        //                                         d="M 0 30 Q 25 45 50 25 T 100 50"
        //                                         stroke="orange"
        //                                         fill="none"
        //                                         strokeWidth="2"
        //                                     />
        //                                 </svg>
        //                             </Box>
        //                         </Box>
        //                     </Grid>
        //                 </Grid>
        //                 <Box sx={{ textAlign: 'right', mt: 3 }}>
        //                     <Link
        //                         href="#"
        //                         sx={{
        //                             display: 'inline-flex',
        //                             alignItems: 'center',
        //                             color: 'primary.main',
        //                             fontWeight: 'bold',
        //                         }}
        //                     >
        //                         Explore traces{' '}
        //                         <ArrowForwardIcon
        //                             sx={{ ml: 0.5, fontSize: '1em' }}
        //                         />
        //                     </Link>
        //                 </Box>
        //             </Paper>
        //         </Grid>
        //     </Grid>
        // </Container>
    )
}

export default ContentPreviewSection
