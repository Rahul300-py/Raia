// src/Dashboard.js
import React, { useState } from 'react'
import {
    Container,
    Grid,
    Card,
    CardContent,
    Typography,
    Box,
    Button,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Chip,
    Paper,
    Alert,
} from '@mui/material'
import {
    ResponsiveContainer,
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    Legend,
    LineChart,
    Line,
} from 'recharts'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import { mockDriftData } from './mockDriftData' // Import your mock data

// --- Helper for status color mapping ---
const getStatusColor = (status) => {
    switch (status) {
        case 'High':
            return 'error'
        case 'Moderate':
            return 'warning'
        case 'Low':
            return 'success'
        case 'Stable':
            return 'info'
        default:
            return 'default'
    }
}

// --- Component for a single feature distribution chart ---
const FeatureDistributionChart = ({ featureName, data }) => {
    if (!data || data.length === 0) {
        return (
            <Card>
                <CardContent>
                    <Typography
                        variant="h6"
                        gutterBottom
                    >{`${featureName} Distribution Drift`}</Typography>
                    <Typography color="text.secondary">
                        No distribution data available for {featureName}.
                    </Typography>
                </CardContent>
            </Card>
        )
    }

    // Determine if it's categorical (like Pclass) or binned continuous (like Age) for XAxis key
    const dataKey = data[0].bin ? 'bin' : 'category'

    return (
        <Card>
            <CardContent>
                <Typography
                    variant="h6"
                    gutterBottom
                >{`${featureName} Distribution Drift`}</Typography>
                <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={data}>
                        <XAxis dataKey={dataKey} />
                        <YAxis
                            tickFormatter={(tick) =>
                                `${(tick * 100).toFixed(0)}%`
                            }
                        />
                        <Tooltip
                            formatter={(value) =>
                                `${(value * 100).toFixed(2)}%`
                            }
                        />
                        <Legend />
                        <Bar
                            dataKey="trainPct"
                            fill="#8884d8"
                            name="Training Data"
                        />
                        <Bar
                            dataKey="livePct"
                            fill="#82ca9d"
                            name="Live Data"
                        />
                    </BarChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    )
}

// --- Component for a feature's drift score card ---
const DriftScoreCard = ({ feature, psi, status }) => (
    <Card elevation={2}>
        <CardContent>
            <Typography variant="h6" component="div">
                {feature}
            </Typography>
            <Box
                display="flex"
                alignItems="center"
                justifyContent="space-between"
                mt={1}
            >
                <Typography variant="h4" color={getStatusColor(status)}>
                    {psi.toFixed(2)}
                </Typography>
                <Chip
                    label={status}
                    color={getStatusColor(status)}
                    size="small"
                />
            </Box>
            <Typography variant="body2" color="text.secondary">
                Population Stability Index
            </Typography>
        </CardContent>
    </Card>
)

// --- Component for overall or target drift summary ---
const OverallSummaryCard = ({
    title,
    value,
    unit = '',
    status = null,
    description = '',
}) => (
    <Card elevation={3}>
        <CardContent>
            <Typography variant="h5" gutterBottom>
                {title}
            </Typography>
            <Box
                display="flex"
                alignItems="center"
                justifyContent="space-between"
            >
                <Typography
                    variant="h3"
                    color={status ? getStatusColor(status) : 'primary'}
                >
                    {value.toFixed(2)}
                    {unit}
                </Typography>
                {status && (
                    <Chip
                        label={status}
                        color={getStatusColor(status)}
                        size="medium"
                    />
                )}
            </Box>
            <Typography variant="body2" color="text.secondary">
                {description}
            </Typography>
        </CardContent>
    </Card>
)

// --- Component for drift over time ---
const DriftTimeSeriesChart = ({ data, selectedFeature }) => {
    if (!data || data.length === 0)
        return <Typography>No time series data available.</Typography>

    // Dynamically get all features that have time series data (excluding 'overallPsi' and 'date')
    // const featuresWithTimeSeries = Object.keys(data[0]).filter(
    //     (key) => key !== 'date' && key !== 'overallPsi'
    // )

    return (
        <Card>
            <CardContent>
                <Typography variant="h6" gutterBottom>
                    Drift Over Time:{' '}
                    {selectedFeature === 'overallPsi'
                        ? 'Overall'
                        : selectedFeature}
                </Typography>
                <ResponsiveContainer width="100%" height={300}>
                    <LineChart data={data}>
                        <XAxis dataKey="date" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        {selectedFeature === 'overallPsi' ? (
                            <Line
                                type="monotone"
                                dataKey="overallPsi"
                                stroke="#ffc658"
                                name="Overall PSI"
                            />
                        ) : (
                            <Line
                                type="monotone"
                                dataKey={selectedFeature}
                                stroke="#8884d8"
                                name={`${selectedFeature} PSI`}
                            />
                        )}
                        {/* You can add more lines here if you want to compare multiple features */}
                    </LineChart>
                </ResponsiveContainer>
            </CardContent>
        </Card>
    )
}

// --- Main Dashboard Component ---
const Dashboard = () => {
    const [selectedFeature, setSelectedFeature] = useState('Age') // Default feature for detailed view
    const [selectedTrendFeature, setSelectedTrendFeature] =
        useState('overallPsi') // Default for time series

    // In a real app, you'd fetch data here with useEffect.
    // For this demo, we're using the imported mock data directly.
    const driftData = mockDriftData

    // Dynamically get available features for selection dropdowns
    const availableFeatures = driftData.featureDriftScores.map((f) => f.feature)
    // const availableTrendFeatures = ['overallPsi', ...availableFeatures]

    return (
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
            {/* <Typography variant="h3" component="h1" gutterBottom sx={{ mb: 4 }}>
                Titanic Data Drift Dashboard
            </Typography> */}

            <Grid container spacing={3}>
                <Box
                    item
                    xs={12}
                    width="100%"
                    sx={{
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                    }}
                >
                    {/* Overall Drift Summary */}
                    <Grid item xs={12} md={6} lg={4}>
                        <OverallSummaryCard
                            title="Overall Data Drift (PSI)"
                            value={driftData.overallDriftScore}
                            status={
                                driftData.overallDriftScore > 0.25
                                    ? 'High'
                                    : driftData.overallDriftScore > 0.1
                                      ? 'Moderate'
                                      : 'Low'
                            }
                            description="Weighted average PSI across all features"
                        />
                    </Grid>

                    {/* Target Variable Drift (Survived) */}
                    <Grid item xs={12} md={6} lg={4}>
                        <OverallSummaryCard
                            title="Survival Rate Drift (Live)"
                            value={driftData.targetDrift.liveSurvivedPct * 100}
                            unit="%"
                            status={driftData.targetDrift.status}
                            description={`Training: ${(driftData.targetDrift.trainSurvivedPct * 100).toFixed(2)}% | PSI: ${driftData.targetDrift.psi.toFixed(2)}`}
                        />
                    </Grid>

                    {/* Feature Selection for Detailed Distribution View */}
                    <Grid item xs={12} md={6} lg={4}>
                        <Card>
                            <CardContent>
                                <Typography variant="h6" gutterBottom>
                                    Inspect Feature Distribution
                                </Typography>
                                <FormControl fullWidth>
                                    <InputLabel id="select-feature-label">
                                        Select Feature
                                    </InputLabel>
                                    <Select
                                        labelId="select-feature-label"
                                        value={selectedFeature}
                                        label="Select Feature"
                                        onChange={(e) =>
                                            setSelectedFeature(e.target.value)
                                        }
                                    >
                                        {availableFeatures.map((feature) => (
                                            <MenuItem
                                                key={feature}
                                                value={feature}
                                            >
                                                {feature}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </CardContent>
                        </Card>
                    </Grid>
                    <Grid>
                        <Button
                            variant="contained"
                            startIcon={<PlayArrowIcon />}
                            sx={{ mb: 2 }}
                        >
                            Explain with AI
                        </Button>
                    </Grid>
                </Box>

                {/* Detailed Feature Distribution Chart */}
                <Grid item xs={12} md={12} sx={{ width: '100%' }}>
                    <FeatureDistributionChart
                        featureName={selectedFeature}
                        data={driftData.featureDistributions[selectedFeature]}
                    />
                </Grid>

                {/* Feature Drift Scores Table/Cards */}
                <Grid item xs={12} md={4}>
                    <Card>
                        <CardContent>
                            <Typography variant="h6" gutterBottom>
                                Feature Drift Scores Summary
                            </Typography>
                            <Grid container spacing={2}>
                                {driftData.featureDriftScores.map((item) => (
                                    <Grid
                                        item
                                        xs={12}
                                        sm={6}
                                        key={item.feature}
                                    >
                                        <DriftScoreCard
                                            feature={item.feature}
                                            psi={item.psi}
                                            status={item.status}
                                        />
                                    </Grid>
                                ))}
                            </Grid>
                        </CardContent>
                    </Card>
                </Grid>

                {/* --- Drift Over Time Section --- */}
                <Grid item xs={12}>
                    <Card>
                        <CardContent>
                            <Box
                                display="flex"
                                justifyContent="space-between"
                                alignItems="center"
                                mb={2}
                            >
                                <Typography variant="h6">
                                    Drift Over Time
                                </Typography>
                                <FormControl sx={{ minWidth: 150 }}>
                                    <InputLabel id="select-trend-feature-label">
                                        Select Trend
                                    </InputLabel>
                                    <Select
                                        labelId="select-trend-feature-label"
                                        value={selectedTrendFeature}
                                        label="Select Trend"
                                        onChange={(e) =>
                                            setSelectedTrendFeature(
                                                e.target.value
                                            )
                                        }
                                    >
                                        <MenuItem value="overallPsi">
                                            Overall Drift (PSI)
                                        </MenuItem>
                                        {availableFeatures.map((feature) => (
                                            <MenuItem
                                                key={feature}
                                                value={feature}
                                            >
                                                {`${feature} PSI`}
                                            </MenuItem>
                                        ))}
                                    </Select>
                                </FormControl>
                            </Box>
                            <DriftTimeSeriesChart
                                data={driftData.timeSeriesDrift}
                                selectedFeature={selectedTrendFeature}
                            />
                        </CardContent>
                    </Card>
                </Grid>

                {/* Potential Alerting Section */}
                {driftData.overallDriftScore > 0.25 && (
                    <Grid item xs={12}>
                        <Alert severity="error" sx={{ mt: 2 }}>
                            <Typography variant="h6">
                                High Overall Data Drift Detected!
                            </Typography>
                            <Typography variant="body1">
                                Significant changes in data patterns may be
                                impacting model performance. Review features
                                with 'High' drift status in the summary section.
                            </Typography>
                        </Alert>
                    </Grid>
                )}
            </Grid>
        </Container>
    )
}

export default Dashboard
