// src/components/Header.js
import React from 'react'
import {
    AppBar,
    Toolbar,
    Button,
    Typography,
    Box,
    Link,
    Stack,
    Menu,
    MenuItem,
} from '@mui/material'
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown'
import GitHubIcon from '@mui/icons-material/GitHub'

// Assuming your logo is in public folder or imported from assets
const logoSrc = '/logo-nav.png' // Adjust path if using assets folder and import

const Header = () => {
    const [anchorElProduct, setAnchorElProduct] = React.useState(null)
    const [anchorElPricing, setAnchorElPricing] = React.useState(null)
    const [anchorElResources, setAnchorElResources] = React.useState(null)

    const handleMenuOpen = (event, setter) => setter(event.currentTarget)
    const handleMenuClose = (setter) => setter(null)

    return (
        <>
            <Box
                sx={{
                    width: '100%',
                    backgroundColor: '#000',
                    color: '#fff',
                    textAlign: 'center',
                    py: 1.5,
                    fontSize: '0.85em',
                    position: 'relative',
                    zIndex: 100, // Ensure it's on top
                }}
            >
                Achieve confidence in your AI. Ensure your models are
                interpretable, unbiased, and ready for deployment – across all
                changes.
                <Link
                    href="#"
                    color="inherit"
                    underline="none"
                    sx={{ ml: 0.5, '&:hover': { textDecoration: 'underline' } }}
                >
                    &gt;
                </Link>
            </Box>
            <AppBar position="static" color="transparent" elevation={0}>
                <Toolbar
                    sx={{
                        justifyContent: 'space-between',
                        maxWidth: 'lg', // Use theme's large max-width
                        width: '100%',
                        mx: 'auto',
                        py: 1,
                        px: { xs: 2, sm: 3, md: 4 }, // Responsive padding
                    }}
                >
                    {/* Logo */}
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <img
                            src={logoSrc}
                            alt="XAI Logo"
                            style={{ width: '100px', marginRight: '10px' }}
                        />
                        {/* <Typography variant="h6" component="div" sx={{ fontWeight: 'bold' }}>
            XAI AI // Removed as it's part of the logo image
          </Typography> */}
                    </Box>

                    {/* Navigation */}
                    <Stack
                        direction="row"
                        spacing={{ xs: 2, md: 3 }}
                        alignItems="center"
                        sx={{ display: { xs: 'none', md: 'flex' } }}
                    >
                        {[
                            {
                                name: 'Product',
                                menuState: anchorElProduct,
                                setMenuState: setAnchorElProduct,
                                items: ['Product Item 1', 'Product Item 2'],
                            },
                            {
                                name: 'Pricing',
                                menuState: anchorElPricing,
                                setMenuState: setAnchorElPricing,
                                items: ['Pricing Item 1', 'Pricing Item 2'],
                            },
                        ].map((item) => (
                            <React.Fragment key={item.name}>
                                <Link
                                    href="#"
                                    color="inherit"
                                    sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                    }}
                                    onClick={(e) =>
                                        handleMenuOpen(e, item.setMenuState)
                                    }
                                >
                                    {item.name}{' '}
                                    <KeyboardArrowDownIcon
                                        sx={{ fontSize: '0.8em', ml: 0.5 }}
                                    />
                                </Link>
                                <Menu
                                    anchorEl={item.menuState}
                                    open={Boolean(item.menuState)}
                                    onClose={() =>
                                        handleMenuClose(item.setMenuState)
                                    }
                                >
                                    {item.items.map((menuItem, index) => (
                                        <MenuItem
                                            key={index}
                                            onClick={() =>
                                                handleMenuClose(
                                                    item.setMenuState
                                                )
                                            }
                                        >
                                            {menuItem}
                                        </MenuItem>
                                    ))}
                                </Menu>
                            </React.Fragment>
                        ))}
                        <Link href="#" color="inherit">
                            Docs
                        </Link>
                        <React.Fragment>
                            <Link
                                href="#"
                                color="inherit"
                                sx={{ display: 'flex', alignItems: 'center' }}
                                onClick={(e) =>
                                    handleMenuOpen(e, setAnchorElResources)
                                }
                            >
                                Resources{' '}
                                <KeyboardArrowDownIcon
                                    sx={{ fontSize: '0.8em', ml: 0.5 }}
                                />
                            </Link>
                            <Menu
                                anchorEl={anchorElResources}
                                open={Boolean(anchorElResources)}
                                onClose={() =>
                                    handleMenuClose(setAnchorElResources)
                                }
                            >
                                <MenuItem
                                    onClick={() =>
                                        handleMenuClose(setAnchorElResources)
                                    }
                                >
                                    Resource Item 1
                                </MenuItem>
                                <MenuItem
                                    onClick={() =>
                                        handleMenuClose(setAnchorElResources)
                                    }
                                >
                                    Resource Item 2
                                </MenuItem>
                            </Menu>
                        </React.Fragment>

                        <Button
                            variant="outlined"
                            size="small"
                            startIcon={<GitHubIcon />}
                            sx={{
                                textTransform: 'none',
                                borderColor: 'grey.300',
                                color: 'text.primary',
                                backgroundColor: 'grey.100',
                                '&:hover': { backgroundColor: 'grey.200' },
                            }}
                        >
                            GitHub
                            <Box
                                component="span"
                                sx={{
                                    ml: 1,
                                    pl: 1,
                                    borderLeft: '1px solid',
                                    borderColor: 'grey.300',
                                    fontSize: '0.8em',
                                    color: 'text.secondary',
                                }}
                            >
                                6,249
                            </Box>
                        </Button>
                    </Stack>

                    {/* Auth Buttons */}
                    <Stack
                        direction="row"
                        spacing={1}
                        sx={{ display: { xs: 'none', md: 'flex' } }}
                    >
                        <Button color="inherit" href="/login">
                            Log in
                        </Button>
                        <Button variant="contained" href="/signup">
                            Sign up
                        </Button>
                        {/* <Button variant="contained" color="primary">
                        Get demo
                    </Button> */}
                    </Stack>

                    {/* Placeholder for Mobile Menu Icon (Hamburger) */}
                    {/* <IconButton
          color="inherit"
          aria-label="open drawer"
          edge="end"
          sx={{ display: { xs: 'flex', md: 'none' } }}
        >
          <MenuIcon />
        </IconButton> */}
                </Toolbar>
            </AppBar>
        </>
    )
}

export default Header
