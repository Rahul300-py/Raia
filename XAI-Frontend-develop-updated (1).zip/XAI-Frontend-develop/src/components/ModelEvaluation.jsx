import React from 'react'
import { Box, Typography, Grid, Paper, Button, Divider } from '@mui/material'

const MetricCard = ({ label, value, change }) => (
    <Paper elevation={1} sx={{ p: 2, minWidth: 150 }}>
        <Typography variant="subtitle2" color="textSecondary">
            {label}
        </Typography>
        <Typography variant="h5" fontWeight={600}>
            {value}
        </Typography>
        <Typography
            variant="caption"
            color={change.startsWith('+') ? 'success.main' : 'error.main'}
        >
            {change}
        </Typography>
    </Paper>
)

const ModelEvaluation = () => {
    return (
        <Box sx={{ px: 6, py: 4 }}>
            <Typography variant="h5" fontWeight={600} gutterBottom>
                Model Evaluation
            </Typography>
            <Typography variant="body2" color="textSecondary" gutterBottom>
                Evaluate the performance of your model using a variety of
                metrics and visualizations.
            </Typography>

            {/* Performance Summary */}
            <Box mt={4}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Performance Summary
                </Typography>
                <Grid container spacing={2}>
                    <Grid item>
                        <MetricCard label="Accuracy" value="92%" change="+2%" />
                    </Grid>
                    <Grid item>
                        <MetricCard
                            label="Precision"
                            value="88%"
                            change="-1%"
                        />
                    </Grid>
                    <Grid item>
                        <MetricCard label="Recall" value="90%" change="+3%" />
                    </Grid>
                </Grid>
            </Box>

            {/* Confusion Matrix */}
            <Box mt={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Confusion Matrix
                </Typography>
                <Box
                    sx={{
                        display: 'flex',
                        justifyContent: 'space-between',
                        border: '1px solid #ccc',
                        borderRadius: 2,
                        mt: 1,
                        overflow: 'hidden',
                    }}
                >
                    <Box
                        sx={{
                            flex: 1,
                            height: 80,
                            bgcolor: '#f5f5f5',
                            borderRight: '1px solid #ccc',
                        }}
                    />
                    <Box sx={{ flex: 1, height: 80, bgcolor: '#f5f5f5' }} />
                </Box>
                <Grid container justifyContent="space-between" mt={1}>
                    <Grid item>
                        <Typography variant="caption" color="textSecondary">
                            Predicted Negative
                        </Typography>
                    </Grid>
                    <Grid item>
                        <Typography variant="caption" color="textSecondary">
                            Predicted Positive
                        </Typography>
                    </Grid>
                </Grid>
            </Box>

            {/* ROC and PR Curves */}
            <Box mt={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    ROC and PR Curves
                </Typography>
                <Box
                    sx={{
                        width: '100%',
                        height: 120,
                        bgcolor: '#f5f5f5',
                        borderRadius: 2,
                    }}
                />
                <Grid container justifyContent="space-between" mt={1}>
                    <Grid item>
                        <Typography variant="caption" color="textSecondary">
                            False Positive Rate
                        </Typography>
                    </Grid>
                    <Grid item>
                        <Typography variant="caption" color="textSecondary">
                            True Positive Rate
                        </Typography>
                    </Grid>
                </Grid>
            </Box>

            {/* Predicted Probabilities */}
            <Box mt={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Predicted Probabilities
                </Typography>
                <Box
                    sx={{
                        width: '100%',
                        height: 80,
                        bgcolor: '#f5f5f5',
                        borderRadius: 2,
                    }}
                />
                <Typography variant="caption" color="textSecondary" mt={1}>
                    Probability
                </Typography>
            </Box>

            {/* Smart Summary by LLM */}
            <Box mt={6}>
                <Typography variant="subtitle1" fontWeight={600} gutterBottom>
                    Smart Summary by LLM
                </Typography>
                <Button variant="outlined" size="small" sx={{ mb: 1 }}>
                    Generate Summary
                </Button>
                <Typography variant="body2" color="textSecondary">
                    The model demonstrates strong overall performance with an
                    accuracy of 92%. While precision is slightly lower at 88%,
                    recall is high at 90%, indicating the model effectively
                    identifies positive cases. Further analysis of the confusion
                    matrix and ROC/PR curves can provide deeper insights into
                    specific areas for improvement.
                </Typography>
            </Box>
        </Box>
    )
}

export default ModelEvaluation
