import React, { useState } from 'react'
import {
    Box,
    Button,
    Divider,
    FormControl,
    Grid,
    InputLabel,
    MenuItem,
    Paper,
    Select,
    Stack,
    TextField,
    Typography,
    Container, // Added Container for overall page width
    Snackbar, // For user feedback instead of alert()
    Alert,
    Card, // For Snackbar content
} from '@mui/material'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import { PieChart, Pie, Cell, ResponsiveContainer } from 'recharts'

// Dummy data for the passenger dropdown
const passengers = [
    {
        id: 1,
        name: 'Futrelle, Mrs. Jacques Heath (Lily May Peel)',
        age: 35,
        sex: 'female',
        pclass: '1st',
        deck: 'C',
        embarked: 'Southampton',
        fare: 53.1,
        parch: 0,
        sibsp: 1,
    },
    {
        id: 2,
        name: 'Allen, Mr. William Henry',
        age: 65,
        sex: 'male',
        pclass: '2nd',
        deck: 'Unknown',
        embarked: 'Southampton',
        fare: 26.55,
        parch: 0,
        sibsp: 0,
    },
    {
        id: 3,
        name: 'Bonell, Miss. Elizabeth',
        age: 58,
        sex: 'female',
        pclass: '1st',
        deck: 'C',
        embarked: 'Southampton',
        fare: 26.55,
        parch: 0,
        sibsp: 0,
    },
    {
        id: 4,
        name: 'Braund, Mr. Owen Harris',
        age: 22,
        sex: 'male',
        pclass: '3rd',
        deck: 'Unknown',
        embarked: 'Southampton',
        fare: 7.25,
        parch: 0,
        sibsp: 1,
    },
    {
        id: 5,
        name: 'Cumings, Mrs. John Bradley (Florence Briggs Thayer)',
        age: 38,
        sex: 'female',
        pclass: '1st',
        deck: 'C',
        embarked: 'Cherbourg',
        fare: 71.28,
        parch: 0,
        sibsp: 1,
    },
    {
        id: 6,
        name: 'Heikkinen, Miss. Laina',
        age: 26,
        sex: 'female',
        pclass: '3rd',
        deck: 'Unknown',
        embarked: 'Southampton',
        fare: 7.925,
        parch: 0,
        sibsp: 0,
    },
]

const WhatIfAnalysis = () => {
    // State for all the input fields
    const [selectedPassengerId, setSelectedPassengerId] = useState('') // Changed to store ID
    const [observedSurvival, setObservedSurvival] = useState('survived')
    const [whatIfName, setWhatIfName] = useState(
        'Futrelle, Mrs. Jacques Heath (Lily May Peel)'
    )
    const [whatIfAge, setWhatIfAge] = useState(35)
    const [whatIfSex, setWhatIfSex] = useState('female')
    const [whatIfClass, setWhatIfClass] = useState('1st')
    const [whatIfDeck, setWhatIfDeck] = useState('C')
    const [whatIfEmbarked, setWhatIfEmbarked] = useState('Southampton')
    const [whatIfFare, setWhatIfFare] = useState(53.1)
    const [whatIfParentsChildren, setWhatIfParentsChildren] = useState(0)
    const [whatIfSiblingsSpouses, setWhatIfSiblingsSpouses] = useState(1)

    // Snackbar state for user feedback
    const [snackbarOpen, setSnackbarOpen] = useState(false)
    const [snackbarMessage, setSnackbarMessage] = useState('')
    const [snackbarSeverity, setSnackbarSeverity] = useState('info')

    // Placeholder prediction logic - this would be replaced by your actual model's output
    // Simple rule-based prediction for demo
    const isPredictedToSurvive =
        whatIfSex === 'female' &&
        whatIfAge < 18 && // Age is a strong factor, let's make it a bit more strict
        (whatIfClass === '1st' || whatIfClass === '2nd') &&
        whatIfFare > 20

    const predictionProbability = isPredictedToSurvive ? 0.926 : 0.074
    const predictionLabel = isPredictedToSurvive ? 'Survived' : 'Not Survived'

    // Data for the Recharts PieChart
    const chartData = [
        { name: 'Prediction', value: predictionProbability * 100 },
        { name: 'Remainder', value: (1 - predictionProbability) * 100 },
    ]

    const COLORS = [isPredictedToSurvive ? '#2e7d32' : '#d32f2f', '#f0f0f0'] // Green for survive, Red for not, Grey for remainder

    // Function to handle passenger selection and populate form fields
    const handlePassengerSelect = (id) => {
        setSelectedPassengerId(id)
        const passenger = passengers.find((p) => p.id === id)
        if (passenger) {
            setWhatIfName(passenger.name)
            setWhatIfAge(passenger.age)
            setWhatIfSex(passenger.sex)
            setWhatIfClass(passenger.pclass)
            setWhatIfDeck(passenger.deck)
            setWhatIfEmbarked(passenger.embarked)
            setWhatIfFare(passenger.fare)
            setWhatIfParentsChildren(passenger.parch)
            setWhatIfSiblingsSpouses(passenger.sibsp)
            setSnackbarMessage(`Loaded data for ${passenger.name}`)
            setSnackbarSeverity('success')
            setSnackbarOpen(true)
        }
    }

    const handleRandomPassenger = () => {
        const randomIndex = Math.floor(Math.random() * passengers.length)
        const randomPassenger = passengers[randomIndex]
        handlePassengerSelect(randomPassenger.id) // Reuse the select handler
    }

    const handleSnackbarClose = (event, reason) => {
        if (reason === 'clickaway') {
            return
        }
        setSnackbarOpen(false)
    }

    return (
        <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
            {/* <Typography variant="h4" sx={{ fontWeight: 600, mb: 2 }}>
                Titanic Survival: What If... Analysis
            </Typography>
            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 4 }}>
                Adjust passenger attributes to see how the predicted survival
                probability changes.
            </Typography> */}

            <Grid container spacing={3}>
                {/* Left Column: Passenger Selection & Feature Inputs */}
                <Grid item xs={12} md={7}>
                    <Paper
                        elevation={3}
                        sx={{ p: 3, borderRadius: '12px', height: '100%' }}
                    >
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography variant="h5" sx={{ mb: 2 }}>
                                Passenger & Feature Controls
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Divider sx={{ mb: 2 }} />

                        {/* Passenger Selection */}
                        <Typography variant="h6" sx={{ mt: 3, mb: 1 }}>
                            Select Passenger
                        </Typography>
                        <Stack
                            direction={{ xs: 'column', sm: 'row' }}
                            spacing={2}
                            sx={{ mb: 3 }}
                        >
                            <FormControl fullWidth size="small">
                                <InputLabel id="passenger-select-label">
                                    Select from list
                                </InputLabel>
                                <Select
                                    labelId="passenger-select-label"
                                    value={selectedPassengerId}
                                    label="Select from list"
                                    onChange={(e) =>
                                        handlePassengerSelect(e.target.value)
                                    }
                                >
                                    {passengers.map((p) => (
                                        <MenuItem key={p.id} value={p.id}>
                                            {p.name}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                            <Button
                                variant="outlined"
                                onClick={handleRandomPassenger}
                                sx={{ whiteSpace: 'nowrap' }} // Prevent text wrapping
                            >
                                Random Passenger
                            </Button>
                        </Stack>

                        <FormControl fullWidth size="small" sx={{ mb: 3 }}>
                            <InputLabel id="observed-survival-label">
                                Observed Survival (Actual Outcome)
                            </InputLabel>
                            <Select
                                labelId="observed-survival-label"
                                value={observedSurvival}
                                label="Observed Survival (Actual Outcome)"
                                onChange={(e) =>
                                    setObservedSurvival(e.target.value)
                                }
                            >
                                <MenuItem value="survived">Survived</MenuItem>
                                <MenuItem value="not-survived">
                                    Not Survived
                                </MenuItem>
                            </Select>
                        </FormControl>

                        <Divider sx={{ my: 3 }} />

                        {/* Feature Inputs Section */}
                        <Typography variant="h5" sx={{ mb: 2 }}>
                            Adjust Features
                        </Typography>
                        <Grid container spacing={2}>
                            <Grid item xs={12} sm={6} md={6}>
                                <TextField
                                    label="Name"
                                    fullWidth
                                    size="small"
                                    value={whatIfName}
                                    onChange={(e) =>
                                        setWhatIfName(e.target.value)
                                    }
                                />
                            </Grid>
                            <Grid item xs={12} sm={6} md={6}>
                                <TextField
                                    label="Age"
                                    type="number"
                                    fullWidth
                                    size="small"
                                    value={whatIfAge}
                                    onChange={(e) =>
                                        setWhatIfAge(Number(e.target.value))
                                    }
                                    helperText="Range: 0.42 - 83.0"
                                />
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <FormControl fullWidth size="small">
                                    <InputLabel>Sex</InputLabel>
                                    <Select
                                        value={whatIfSex}
                                        label="Sex"
                                        onChange={(e) =>
                                            setWhatIfSex(e.target.value)
                                        }
                                    >
                                        <MenuItem value="male">Male</MenuItem>
                                        <MenuItem value="female">
                                            Female
                                        </MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <FormControl fullWidth size="small">
                                    <InputLabel>Passenger Class</InputLabel>
                                    <Select
                                        value={whatIfClass}
                                        label="Passenger Class"
                                        onChange={(e) =>
                                            setWhatIfClass(e.target.value)
                                        }
                                    >
                                        <MenuItem value="1st">1st</MenuItem>
                                        <MenuItem value="2nd">2nd</MenuItem>
                                        <MenuItem value="3rd">3rd</MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <FormControl fullWidth size="small">
                                    <InputLabel>Deck</InputLabel>
                                    <Select
                                        value={whatIfDeck}
                                        label="Deck"
                                        onChange={(e) =>
                                            setWhatIfDeck(e.target.value)
                                        }
                                    >
                                        <MenuItem value="A">A</MenuItem>
                                        <MenuItem value="B">B</MenuItem>
                                        <MenuItem value="C">C</MenuItem>
                                        <MenuItem value="D">D</MenuItem>
                                        <MenuItem value="E">E</MenuItem>
                                        <MenuItem value="F">F</MenuItem>
                                        <MenuItem value="G">G</MenuItem>
                                        <MenuItem value="Unknown">
                                            Unknown
                                        </MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <FormControl fullWidth size="small">
                                    <InputLabel>Embarked</InputLabel>
                                    <Select
                                        value={whatIfEmbarked}
                                        label="Embarked"
                                        onChange={(e) =>
                                            setWhatIfEmbarked(e.target.value)
                                        }
                                    >
                                        <MenuItem value="Southampton">
                                            Southampton
                                        </MenuItem>
                                        <MenuItem value="Cherbourg">
                                            Cherbourg
                                        </MenuItem>
                                        <MenuItem value="Queenstown">
                                            Queenstown
                                        </MenuItem>
                                    </Select>
                                </FormControl>
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <TextField
                                    label="Fare"
                                    type="number"
                                    fullWidth
                                    size="small"
                                    value={whatIfFare}
                                    onChange={(e) =>
                                        setWhatIfFare(Number(e.target.value))
                                    }
                                    helperText="Range: 0.0 - 512.33"
                                    inputProps={{ step: '0.1' }} // Allow decimal steps
                                />
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <TextField
                                    label="Parents/Children Aboard"
                                    type="number"
                                    fullWidth
                                    size="small"
                                    value={whatIfParentsChildren}
                                    onChange={(e) =>
                                        setWhatIfParentsChildren(
                                            Number(e.target.value)
                                        )
                                    }
                                    helperText="Range: 0 - 6"
                                />
                            </Grid>
                            <Grid item xs={12} sm={6} md={4}>
                                <TextField
                                    label="Siblings/Spouses Aboard"
                                    type="number"
                                    fullWidth
                                    size="small"
                                    value={whatIfSiblingsSpouses}
                                    onChange={(e) =>
                                        setWhatIfSiblingsSpouses(
                                            Number(e.target.value)
                                        )
                                    }
                                    helperText="Range: 0 - 8"
                                />
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>

                {/* Right Column: Prediction & Outcome */}
                <Grid item xs={12} md={12} sx={{ width: '100%' }}>
                    <Card
                        elevation={3}
                        sx={{
                            p: 3,
                            borderRadius: '12px',
                            height: '100%',
                            display: 'flex',
                            flexDirection: 'column',
                            width: '100%',
                        }}
                    >
                        <Box
                            item
                            xs={12}
                            width="100%"
                            sx={{
                                display: 'flex',
                                flexDirection: 'row',
                                justifyContent: 'space-between',
                            }}
                        >
                            <Typography variant="h5" sx={{ mb: 2 }}>
                                Survival Prediction
                            </Typography>
                            <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                                sx={{ mb: 2 }}
                            >
                                Explain with AI
                            </Button>
                        </Box>

                        <Divider sx={{ mb: 2 }} />

                        <Box
                            sx={{
                                flexGrow: 1, // Allows box to take available vertical space
                                display: 'flex',
                                flexDirection: 'column',
                                alignItems: 'center',
                                justifyContent: 'center',
                                border: '1px dashed',
                                borderColor: 'grey.400',
                                borderRadius: '8px',
                                bgcolor: 'grey.50',
                                position: 'relative',
                                py: 3, // Padding top/bottom
                            }}
                        >
                            <Box
                                sx={{
                                    width: 160, // Increased size for visibility
                                    height: 160,
                                    position: 'relative', // Ensures PieChart takes its own space
                                }}
                            >
                                <ResponsiveContainer>
                                    <PieChart>
                                        <Pie
                                            data={chartData}
                                            cx="50%"
                                            cy="50%"
                                            innerRadius={60} // Adjusted radius
                                            outerRadius={75} // Adjusted radius
                                            startAngle={90}
                                            endAngle={450}
                                            paddingAngle={0}
                                            dataKey="value"
                                        >
                                            {chartData.map((entry, index) => (
                                                <Cell
                                                    key={`cell-${index}`}
                                                    fill={
                                                        COLORS[
                                                            index %
                                                                COLORS.length
                                                        ]
                                                    }
                                                    stroke={
                                                        COLORS[
                                                            index %
                                                                COLORS.length
                                                        ]
                                                    }
                                                />
                                            ))}
                                        </Pie>
                                    </PieChart>
                                </ResponsiveContainer>
                                {/* Overlay text for probability inside the chart area */}
                                <Box
                                    sx={{
                                        position: 'absolute',
                                        top: '50%',
                                        left: '50%',
                                        transform: 'translate(-50%, -50%)',
                                        textAlign: 'center',
                                    }}
                                >
                                    <Typography
                                        variant="h4"
                                        sx={{
                                            fontWeight: 'bold',
                                            color: isPredictedToSurvive
                                                ? 'success.main'
                                                : 'error.main',
                                        }}
                                    >
                                        {(predictionProbability * 100).toFixed(
                                            1
                                        )}
                                        %
                                    </Typography>
                                    <Typography
                                        variant="body2"
                                        sx={{ color: 'text.secondary' }}
                                    >
                                        Probability
                                    </Typography>
                                </Box>
                            </Box>
                            <Typography
                                variant="h5"
                                sx={{ fontWeight: 600, mt: 2 }}
                            >
                                Predicted: {predictionLabel}
                            </Typography>
                            <Typography
                                variant="body2"
                                color="text.secondary"
                                mt={1}
                            >
                                The model's prediction based on current inputs.
                            </Typography>
                        </Box>

                        <TextField
                            label="Predicted probability range"
                            fullWidth
                            size="small"
                            defaultValue="0.0 - 1.0"
                            InputProps={{ readOnly: true }}
                            sx={{ mt: 3 }}
                        />

                        <Stack
                            direction="row"
                            spacing={2}
                            justifyContent="flex-end" // Align buttons to the right
                            sx={{ mt: 'auto', pt: 3 }} // Push buttons to bottom, add padding-top
                        >
                            <Button variant="outlined">
                                Add to Comparison
                            </Button>
                            {/* <Button
                                variant="contained"
                                startIcon={<PlayArrowIcon />}
                            >
                                Explain with AI
                            </Button> */}
                        </Stack>
                    </Card>
                </Grid>
            </Grid>

            {/* Snackbar for alerts */}
            <Snackbar
                open={snackbarOpen}
                autoHideDuration={3000}
                onClose={handleSnackbarClose}
            >
                <Alert
                    onClose={handleSnackbarClose}
                    severity={snackbarSeverity}
                    sx={{ width: '100%' }}
                >
                    {snackbarMessage}
                </Alert>
            </Snackbar>
        </Container>
    )
}

export default WhatIfAnalysis
