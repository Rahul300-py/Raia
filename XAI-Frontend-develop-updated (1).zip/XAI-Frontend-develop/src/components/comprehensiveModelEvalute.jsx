import React from 'react'
import {
    Box,
    Typography,
    Paper,
    Grid,
    Container,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'

const evaluationFeatures = [
    {
        icon: '🏷️',
        title: 'Classification Evaluator',
        subtitle: 'Deep insights into classification model performance',
        points: [
            'Confusion matrices & ROC curves',
            'Precision-recall analysis',
            'Class imbalance detection',
            'Multi-class performance metrics',
        ],
    },
    {
        icon: '📐',
        title: 'Regression Evaluator',
        subtitle: 'Comprehensive regression model assessment',
        points: [
            'Residual analysis & diagnostics',
            'Heteroscedasticity detection',
            'Prediction intervals',
            'Feature contribution analysis',
        ],
    },
    {
        icon: '🏛️',
        title: 'Recommendation Evaluator',
        subtitle: 'Specialized metrics for recommendation systems',
        points: [
            'Coverage and diversity metrics',
            'Novelty and serendipity scores',
            'User satisfaction prediction',
            'A/B testing framework',
        ],
    },
]

const ComprehensiveModelEvalute = () => {
    return (
        <Box
            sx={{
                color: '#fff',
                py: 8,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="h4"
                    sx={{
                        color: '#B4A3FF',
                        fontWeight: 700,
                        mb: 2,
                        textAlign: 'center',
                    }}
                >
                    Comprehensive Model Evaluators{' '}
                </Typography>
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'center',
                        maxWidth: '600px',
                        mx: 'auto',
                    }}
                >
                    Specialized evaluation tools for every AI model type, from
                    traditional ML to cutting-edge LLMs.
                </Typography>

                <Grid container spacing={4}>
                    {evaluationFeatures.map((feature, index) => (
                        <Grid item xs={12} sm={6} md={4} key={index}>
                            <Paper
                                elevation={0}
                                sx={{
                                    // backgroundColor: '#111827',
                                    border: '1px solid rgb(158, 180, 211)',
                                    borderRadius: '16px',
                                    p: 4,
                                    height: '100%',
                                    cursor: 'pointer',
                                    maxWidth: '350px',
                                    transition: 'all 0.3s ease',
                                    '&:hover': {
                                        boxShadow:
                                            '0 6px 20px rgba(0,0,0,0.08)',
                                        transform: 'translateY(-3px)',
                                    },
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    sx={{
                                        fontWeight: 700,

                                        mb: 1,
                                    }}
                                >
                                    {feature.icon} {feature.title}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        mb: 2,
                                    }}
                                >
                                    {feature.subtitle}
                                </Typography>

                                <List dense>
                                    {feature.points.map((point, i) => (
                                        <ListItem key={i} disableGutters>
                                            <ListItemIcon
                                                sx={{
                                                    minWidth: '30px',
                                                    color: '#22C55E',
                                                }}
                                            >
                                                <CheckCircleIcon fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText primary={point} />
                                        </ListItem>
                                    ))}
                                </List>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>
                <br />
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'center',
                        maxWidth: '600px',
                        mx: 'auto',
                    }}
                >
                    For detailed LLM and RAG evaluation capabilities, see our
                    dedicated{' '}
                    <Box component="span" sx={{ color: 'secondary.main' }}>
                        LLM & RAG section{' '}
                    </Box>{' '}
                    below ↓
                </Typography>
            </Container>
        </Box>
    )
}

export default ComprehensiveModelEvalute
