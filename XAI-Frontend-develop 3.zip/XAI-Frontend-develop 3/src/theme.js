// src/theme.js
import { createTheme } from '@mui/material/styles'

const theme = createTheme({
    palette: {
        primary: {
            main: '#007bff', // A blue for primary buttons/links, adjust as needed
            light: '#e0f7fa', // Light blue/purple for hero background
            dark: '#0d0d2b', // A purple for specific text elements
        },
        secondary: {
            main: '#0d0d2b', // Use purple as secondary for highlighting
        },
        highlight: {
            main: '#ff65c4',
        },
        text: {
            primary: '#333',
            secondary: '#555',
            disabled: '#aaa',
            highlight: '#ff65c4',
            light: '#fff',
        },
        background: {
            default: '#fff',
            paper: '#fff',
        },
        grey: {
            100: '#f6f8fa', // For GitHub button background
            200: '#eee', // For borders
            300: '#ddd', // For darker borders
        },
    },
    typography: {
        fontFamily:
            "'Neue Montreal Medium', 'Neue Montreal Medium Placeholder', sans-serif",
        h1: {
            fontSize: '3.5rem',
            fontWeight: 700,
            lineHeight: 1.2,
            '@media (max-width:900px)': {
                fontSize: '2.5rem',
            },
        },
        h3: {
            fontSize: '2.5rem',
            fontWeight: 700,
            lineHeight: 1.2,
            '@media (max-width:900px)': {
                fontSize: '2rem',
            },
        },
        h4: {
            fontSize: '2rem',
            fontWeight: 700,
            lineHeight: 1.3,
            '@media (max-width:900px)': {
                fontSize: '1.75rem',
            },
        },
        h5: {
            fontSize: '1.5rem',
            fontWeight: 600,
        },
        body1: {
            fontSize: '1.05rem',
            lineHeight: 1.6,
        },
        body2: {
            fontSize: '0.9rem',
            lineHeight: 1.5,
        },
        subtitle1: {
            fontSize: '1.1rem',
            fontWeight: 500,
        },
    },
    components: {
        MuiButton: {
            styleOverrides: {
                root: {
                    textTransform: 'none', // Prevent uppercase by default
                    borderRadius: '5px',
                    fontWeight: 'bold',
                },
                containedPrimary: {
                    backgroundColor: '#0d0d2b', // Match the blue in screenshots
                    '&:hover': {
                        backgroundColor: '#2a2a76',
                    },
                },
                outlined: {
                    borderColor: '#ddd',
                    color: 'text.primary',
                    '&:hover': {
                        borderColor: 'primary.main',
                        backgroundColor: 'rgba(0, 123, 255, 0.04)',
                    },
                },
            },
        },
        MuiLink: {
            defaultProps: {
                underline: 'none',
            },
            styleOverrides: {
                root: {
                    color: 'text.primary',
                    '&:hover': {
                        color: 'primary.main',
                    },
                },
            },
        },
        // MuiPaper: {
        //     styleOverrides: {
        //         root: {
        //             borderRadius: '15px',
        //         },
        //     },
        // },
        // MuiAppBar: {
        //     styleOverrides: {
        //         root: {
        //             borderBottom: '1px solid #eee',
        //         },
        //     },
        // },
    },
})

export default theme
