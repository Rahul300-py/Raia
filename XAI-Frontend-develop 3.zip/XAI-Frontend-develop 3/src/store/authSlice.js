import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'
import { showSuccessToast } from '../utils/toastUtility'

const url = 'http://localhost:8000/api'

// LOGIN
export const loginUser = createAsyncThunk(
    'auth/loginUser',
    async ({ username, password }, thunkAPI) => {
        try {
            const response = await axios.post(
                `${url}/login`,
                new URLSearchParams({ username, password }),
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                }
            )

            const { access_token, user_profile } = response.data

            localStorage.setItem('token', access_token)
            localStorage.setItem('user', JSON.stringify(user_profile))
            showSuccessToast('Login Successfull!')
            return { token: access_token, user: user_profile }
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail || 'Login failed'
            )
        }
    }
)

// SIGNUP
export const signupUser = createAsyncThunk(
    'auth/signupUser',
    async ({ name, email, username, password }, thunkAPI) => {
        try {
            const response = await axios.post(`${url}/users`, {
                name,
                email,
                username,
                password,
                tenant_id: 1,
            })
            if (response?.data?.message === 'User already exist') {
                return thunkAPI.rejectWithValue('User already exist')
            } else if (
                response?.data?.message ===
                'Email domain should be cirruslabs.io'
            ) {
                return thunkAPI.rejectWithValue('Email should be Cirruslabs ID')
            } else {
                return response.data
            }
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail || 'Signup failed'
            )
        }
    }
)

const initialState = {
    user: JSON.parse(localStorage.getItem('user')) || null,
    token: localStorage.getItem('token') || null,
    loading: false,
    error: null,
    signupSuccess: false,
}

const authSlice = createSlice({
    name: 'auth',
    initialState,
    reducers: {
        logout: (state) => {
            state.user = null
            state.token = null
            localStorage.removeItem('user')
            localStorage.removeItem('token')
        },
        clearAuthError: (state) => {
            state.error = null
        },
        clearSignupSuccess: (state) => {
            state.signupSuccess = false
        },
    },
    extraReducers: (builder) => {
        builder
            .addCase(loginUser.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(loginUser.fulfilled, (state, action) => {
                state.loading = false
                state.user = action.payload.user
                state.token = action.payload.token
                state.error = null
            })
            .addCase(loginUser.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            .addCase(signupUser.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(signupUser.fulfilled, (state) => {
                state.loading = false
                state.signupSuccess = true
            })
            .addCase(signupUser.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
    },
})

export const { logout, clearAuthError, clearSignupSuccess } = authSlice.actions
export default authSlice.reducer
