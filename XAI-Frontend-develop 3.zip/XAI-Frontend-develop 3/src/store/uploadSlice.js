import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'
import { fetchAllFairnessData } from './fairnessSlice'
import { fetchDriftReportColumns } from './driftReportSlice'
import { fetchRegressionColumns } from './regressionSlice'
import { fetchClassificationColumns } from './classificationSlice'

const url = 'http://localhost:8000/api'

// UPLOAD FILES
export const uploadFiles = createAsyncThunk(
    'upload/uploadFiles',
    async ({ user_id, tenant_id, files, analysis_type }, thunkAPI) => {
        const token = thunkAPI.getState().auth.token

        try {
            const formData = new FormData()
            formData.append('user_id', user_id)
            formData.append('tenant_id', tenant_id)
            formData.append('analysis_type', analysis_type)
            files.forEach((file) => formData.append('files', file))

            const response = await axios.post(`${url}/files_upload`, formData, {
                headers: {
                    Authorization: `Bearer ${token}`,
                    'Content-Type': 'multipart/form-data',
                },
            })

            thunkAPI.dispatch(fetchAllFairnessData())
            thunkAPI.dispatch(fetchDriftReportColumns())
            thunkAPI.dispatch(fetchRegressionColumns())
            thunkAPI.dispatch(fetchClassificationColumns())

            return response.data
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail || 'File upload failed'
            )
        }
    }
)

// UPLOAD CLASSIFICATION DATA
export const uploadClassificationData = createAsyncThunk(
    'upload/classificationData',
    async ({ user_id, tenant_id, files }, thunkAPI) => {
        const token = thunkAPI.getState().auth.token

        try {
            const formData = new FormData()
            formData.append('user_id', user_id)
            formData.append('tenant_id', tenant_id)
            formData.append('analysis_type', 'Classification')

            if (files.train) formData.append('train', files.train)
            if (files.test) formData.append('test', files.test)

            const response = await axios.post(
                `${url}/classification_upload`,
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'multipart/form-data',
                    },
                }
            )

            return response.data
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail ||
                    'Classification data upload failed'
            )
        }
    }
)

// UPLOAD MODELS
export const uploadModels = createAsyncThunk(
    'upload/uploadModels',
    async ({ user_id, tenant_id, files }, thunkAPI) => {
        const token = thunkAPI.getState().auth.token

        try {
            const formData = new FormData()
            formData.append('user_id', user_id)
            formData.append('tenant_id', tenant_id)
            files.forEach((file) => formData.append('files', file))

            const response = await axios.post(
                `${url}/models_upload`,
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'multipart/form-data',
                    },
                }
            )

            return response.data
        } catch (error) {
            return thunkAPI.rejectWithValue(
                error?.response?.data?.detail || 'Model upload failed'
            )
        }
    }
)

const uploadSlice = createSlice({
    name: 'upload',
    initialState: {
        loading: false,
        error: null,
        success: false,
        uploadedFiles: null,
        uploadedModels: null,
        classificationUpload: {
            loading: false,
            error: null,
            success: false,
            progress: 0,
        },
    },
    reducers: {
        clearUploadStatus: (state) => {
            state.success = false
            state.error = null
        },
        resetClassificationUpload: (state) => {
            state.classificationUpload = {
                loading: false,
                error: null,
                success: false,
                progress: 0,
            }
        },
    },
    extraReducers: (builder) => {
        builder
            // UPLOAD FILES
            .addCase(uploadFiles.pending, (state) => {
                state.loading = true
                state.error = null
                state.success = false
            })
            .addCase(uploadFiles.fulfilled, (state) => {
                state.loading = false
                state.success = true
            })
            .addCase(uploadFiles.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
                state.success = false
            })

            // UPLOAD MODELS
            .addCase(uploadModels.pending, (state) => {
                state.loading = true
                state.error = null
                state.success = false
            })
            .addCase(uploadModels.fulfilled, (state) => {
                state.loading = false
                state.success = true
            })
            .addCase(uploadModels.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
                state.success = false
            })

            // CLASSIFICATION UPLOAD
            .addCase(uploadClassificationData.pending, (state) => {
                state.classificationUpload.loading = true
                state.classificationUpload.error = null
                state.classificationUpload.success = false
            })
            .addCase(uploadClassificationData.fulfilled, (state) => {
                state.classificationUpload.loading = false
                state.classificationUpload.success = true
            })
            .addCase(uploadClassificationData.rejected, (state, action) => {
                state.classificationUpload.loading = false
                state.classificationUpload.error = action.payload
                state.classificationUpload.success = false
            })
    },
})

export const { clearUploadStatus, resetClassificationUpload } =
    uploadSlice.actions
export default uploadSlice.reducer
