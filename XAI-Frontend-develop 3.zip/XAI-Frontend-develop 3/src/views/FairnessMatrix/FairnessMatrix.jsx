/* eslint-disable no-unused-vars */
import React, { useState } from 'react'
import { useSelector } from 'react-redux'
import performAnalysisData from '../../mockdata/performanalysis.json' // Corrected import for performanalysis.json
import mitigationStrategiesData from '../../mockdata/mitigation_strategies.json'
import listDatasetsData from '../../mockdata/listdatasets.json'
/* eslint-disable no-unused-vars */

import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
    CircularProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    LinearProgress,
    Stack,
} from '@mui/material'
import { TabContext, TabList, TabPanel } from '@mui/lab'
import Tab from '@mui/material/Tab'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import AssessmentIcon from '@mui/icons-material/Assessment'
import PreviewIcon from '@mui/icons-material/Preview'
import DownloadIcon from '@mui/icons-material/Download'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    Radar,
    RadarChart,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    Legend,
    CartesianGrid,
} from 'recharts'

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
} from 'recharts'

import {
    Dashboard,
    DocumentScanner,
    Folder,
    InfoOutline,
    Launch,
} from '@mui/icons-material'
import SummaryLoaderPlaceholder from '../../components/SummaryLoaderPlaceholder'
import axios from 'axios'
// Helper for status color mapping (e.g., for disparity)
const getDisparityColor = (value) => {
    // These thresholds are examples; adjust based on domain knowledge
    if (Math.abs(value) > 0.1) return 'error' // High disparity
    if (Math.abs(value) > 0.03) return 'warning' // Moderate disparity
    return 'success' // Low disparity/good
}

// Helper for improvement percentage color mapping
const getImprovementColor = (percentage) => {
    if (percentage > 5) return 'success' // Significant positive improvement
    if (percentage > 0) return 'info' // Some positive improvement
    if (percentage < 0) return 'error' // Degradation or negative impact
    return 'default' // No change
}

function FairnessMatrix({ selectedTargetColumn }) {
    const { token, user } = useSelector((state) => state?.auth)
    const projectList = useSelector((state) => state.driftConfig.projectList)
    const { fairnessAnalysis, loading, datasets } = useSelector(
        (state) => state.fairness
    )

    const { features, metrics, llm_analysis_report, overview, plots } =
        fairnessAnalysis || {}

    const [selectedTab, setSelectedTab] = useState('overview')
    const [selectedAttribute, setSelectedAttribute] = useState(
        performAnalysisData?.features?.[0] || 'Age_Group'
    )

    const [selectedMitigationStrategy, setSelectedMitigationStrategy] =
        useState(
            mitigationStrategiesData?.strategies?.[0]?.value ||
                'exponentiated_gradient'
        )
    const [selectedDataset, setSelectedDataset] = useState(
        listDatasetsData?.files?.[0]?.file_name || 'ref_biased_age.csv'
    )

    const [llmExplanation, setLlmExplanation] = useState('')
    const [isLlmLoading, setIsLlmLoading] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)

    // Extract data for the currently selected sensitive attribute
    const currentAttributeMetrics =
        performAnalysisData?.metrics?.[selectedAttribute] || {}
    const llmAnalysisReport = llm_analysis_report || ''

    // Prepare data for the comparison bar charts (Before vs After Mitigation)
    const prepareChartData = (beforeData, afterData, metricKey) => {
        const data = []
        for (const group in beforeData) {
            data.push({
                name: group,
                'Before Mitigation': beforeData[group][metricKey],
                'After Mitigation': afterData[group][metricKey],
            })
        }
        return data
    }

    const accuracyChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'accuracy_score'
    )
    const selectionRateChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'selection_rate'
    )
    const tprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'tpr'
    )
    const fprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'fpr'
    )

    const grpWisePerfornameChartData = (data) =>
        Object.entries(data).map(([group, beforeMetrics]) => {
            const afterMetrics =
                metrics[selectedTargetColumn].group_performance_after?.[
                    group
                ] || {}

            return {
                group,
                'Accuracy (Before)': beforeMetrics.accuracy_score || 0,
                'Accuracy (After)': afterMetrics.accuracy_score || 0,
                'Selection Rate (Before)': beforeMetrics.selection_rate || 0,
                'Selection Rate (After)': afterMetrics.selection_rate || 0,
                'TPR (Before)': beforeMetrics.tpr || 0,
                'TPR (After)': afterMetrics.tpr || 0,
                'FPR (Before)': beforeMetrics.fpr || 0,
                'FPR (After)': afterMetrics.fpr || 0,
            }
        })

    const radarChartData = [
        {
            metric: 'Accuracy',
            Before: accuracyChartData[0]?.['Before Mitigation'] || 0,
            After: accuracyChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'Selection Rate',
            Before: selectionRateChartData[0]?.['Before Mitigation'] || 0,
            After: selectionRateChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'TPR',
            Before: tprChartData[0]?.['Before Mitigation'] || 0,
            After: tprChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'FPR',
            Before: fprChartData[0]?.['Before Mitigation'] || 0,
            After: fprChartData[0]?.['After Mitigation'] || 0,
        },
    ]

    return (
        <TabPanel value="detailed_metrics" sx={{ p: 0 }}>
            <Grid container spacing={3}>
                {/* Performance Metrics Bar Charts */}
                <Grid container spacing={3} width="100%">
                    <Grid item xs={12} flex={1}>
                        <Paper
                            elevation={0}
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                height: '100%',
                                border: '1px solid #e0e0e0',
                            }}
                        >
                            <Typography
                                variant="h6"
                                sx={{
                                    mb: 2,
                                    fontWeight: 600,
                                    color: '#232f3e',
                                }}
                            >
                                Overall Fairness Metrics Comparison by{' '}
                                {selectedTargetColumn}
                            </Typography>

                            {/* <ResponsiveContainer width="100%" height={400}>
                                <RadarChart data={radarChartData}>
                                    <PolarGrid />
                                    <PolarAngleAxis dataKey="metric" />
                                    <PolarRadiusAxis
                                        angle={30}
                                        domain={[0, 1]}
                                        tickFormatter={(tick) =>
                                            `${(tick * 100).toFixed(0)}%`
                                        }
                                    />
                                    <Tooltip
                                        formatter={(val) =>
                                            `${(val * 100).toFixed(2)}%`
                                        }
                                    />
                                    <Legend />
                                    <Radar
                                        name="Before Mitigation"
                                        dataKey="Before"
                                        stroke="#8884d8"
                                        fill="#8884d8"
                                        fillOpacity={0.6}
                                    />
                                    <Radar
                                        name="After Mitigation"
                                        dataKey="After"
                                        stroke="#82ca9d"
                                        fill="#82ca9d"
                                        fillOpacity={0.6}
                                    />
                                </RadarChart>
                            </ResponsiveContainer> */}
                        </Paper>
                    </Grid>
                    <Grid item xs={12} flex={1}>
                        <Paper
                            elevation={0}
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                height: '100%',
                                border: '1px solid #e0e0e0',
                            }}
                        >
                            <Typography
                                variant="h5"
                                sx={{
                                    mb: 2,
                                    fontWeight: 600,
                                    color: '#232f3e',
                                }}
                            >
                                Group-wise Fairness Metrics ({selectedAttribute}
                                )
                            </Typography>

                            {/* <ResponsiveContainer width="100%" height={400}>
                                <BarChart
                                    data={grpWisePerfornameChartData(
                                        metrics[selectedTargetColumn]
                                            ?.group_performance_before
                                    )}
                                    margin={{
                                        top: 20,
                                        right: 20,
                                        left: 0,
                                        bottom: 60,
                                    }}
                                >
                                    <CartesianGrid strokeDasharray="3 3" />
                                    <XAxis
                                        dataKey="group"
                                        angle={-45}
                                        textAnchor="end"
                                        height={80}
                                    />
                                    <YAxis
                                        domain={[0, 1]}
                                        tickFormatter={(tick) =>
                                            `${(tick * 100).toFixed(0)}%`
                                        }
                                    />
                                    <Tooltip
                                        formatter={(value) =>
                                            `${(value * 100).toFixed(2)}%`
                                        }
                                    />
                                    <Legend
                                        wrapperStyle={{
                                            paddingTop: '10px',
                                        }}
                                    />
                                  
                                    <Bar
                                        dataKey="Accuracy (Before)"
                                        fill="#3f51b5"
                                    />
                                    <Bar
                                        dataKey="Accuracy (After)"
                                        fill="#7986cb"
                                    />
                                    <Bar
                                        dataKey="Selection Rate (Before)"
                                        fill="#ff9800"
                                    />
                                    <Bar
                                        dataKey="Selection Rate (After)"
                                        fill="#ffb74d"
                                    />
                                    <Bar
                                        dataKey="TPR (Before)"
                                        fill="#673ab7"
                                    />
                                    <Bar dataKey="TPR (After)" fill="#9575cd" />
                                    <Bar
                                        dataKey="FPR (Before)"
                                        fill="#f44336"
                                    />
                                    <Bar dataKey="FPR (After)" fill="#e57373" />
                                </BarChart>
                            </ResponsiveContainer> */}
                        </Paper>
                    </Grid>
                </Grid>
                {/* Overall Fairness Metrics Table */}
                <Grid item xs={12} sx={{ width: '100%' }}>
                    <Paper
                        elevation={0}
                        sx={{
                            p: 3,
                            borderRadius: '8px',
                            height: '100%',
                            border: '1px solid #e0e0e0',
                        }}
                    >
                        <Typography
                            variant="h5"
                            sx={{
                                mb: 2,
                                fontWeight: 600,
                                color: '#232f3e',
                            }}
                        >
                            Overall Fairness Metrics Comparison
                        </Typography>
                        <TableContainer
                            sx={{
                                border: '1px solid #e0e0e0',
                                borderRadius: '8px',
                                overflow: 'hidden',
                            }}
                        >
                            <Table size="medium">
                                <TableHead sx={{ backgroundColor: '#fafafa' }}>
                                    <TableRow>
                                        <TableCell
                                            sx={{
                                                fontWeight: 'bold',
                                                color: '#232f3e',
                                            }}
                                        >
                                            Metric
                                        </TableCell>
                                        <TableCell
                                            align="right"
                                            sx={{
                                                fontWeight: 'bold',
                                                color: '#232f3e',
                                            }}
                                        >
                                            Before Mitigation
                                        </TableCell>
                                        <TableCell
                                            align="right"
                                            sx={{
                                                fontWeight: 'bold',
                                                color: '#232f3e',
                                            }}
                                        >
                                            After Mitigation
                                        </TableCell>
                                        <TableCell
                                            align="right"
                                            sx={{
                                                fontWeight: 'bold',
                                                color: '#232f3e',
                                            }}
                                        >
                                            Improvement (%)
                                        </TableCell>
                                    </TableRow>
                                </TableHead>
                                <TableBody>
                                    {Object.entries(
                                        metrics[selectedTargetColumn]
                                            ?.fairness_metrics_before || {}
                                    ).map(([metric, value]) => {
                                        const afterValue =
                                            metrics[selectedTargetColumn]
                                                ?.fairness_metrics_after?.[
                                                metric
                                            ]
                                        const improvement =
                                            value !== 0 &&
                                            afterValue !== undefined
                                                ? (
                                                      ((value - afterValue) /
                                                          value) *
                                                      100
                                                  ).toFixed(2)
                                                : 'N/A'
                                        return (
                                            <TableRow
                                                key={metric}
                                                sx={{
                                                    '&:nth-of-type(odd)': {
                                                        backgroundColor:
                                                            '#fdfdfd',
                                                    },
                                                    '&:last-child td, &:last-child th':
                                                        {
                                                            borderBottom: 0,
                                                        },
                                                }}
                                            >
                                                <TableCell
                                                    component="th"
                                                    scope="row"
                                                >
                                                    {metric.replace(/_/g, ' ')}
                                                </TableCell>
                                                <TableCell align="right">
                                                    {value?.toFixed(4) || 'N/A'}
                                                </TableCell>
                                                <TableCell align="right">
                                                    {afterValue?.toFixed(4) ||
                                                        'N/A'}
                                                </TableCell>
                                                <TableCell align="right">
                                                    <Chip
                                                        label={
                                                            improvement !==
                                                            'N/A'
                                                                ? `${improvement}%`
                                                                : 'N/A'
                                                        }
                                                        color={
                                                            improvement !==
                                                            'N/A'
                                                                ? getImprovementColor(
                                                                      parseFloat(
                                                                          improvement
                                                                      )
                                                                  )
                                                                : 'default'
                                                        }
                                                        size="small"
                                                        sx={{
                                                            minWidth: '70px',
                                                        }}
                                                    />
                                                </TableCell>
                                            </TableRow>
                                        )
                                    })}
                                </TableBody>
                            </Table>
                        </TableContainer>
                    </Paper>
                </Grid>
                <Grid container spacing={3} width="100%">
                    <Grid item xs={12} md={6} flex={1}>
                        <Paper
                            elevation={0}
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                height: '100%',
                                border: '1px solid #e0e0e0',
                            }}
                        >
                            <Typography
                                variant="h6"
                                sx={{
                                    mb: 2,
                                    fontWeight: 600,
                                    color: '#232f3e',
                                }}
                            >
                                True Positive Rate (TPR) by{' '}
                                {selectedTargetColumn}
                            </Typography>
                            <ResponsiveContainer width="100%" height={250}>
                                <BarChart data={tprChartData}>
                                    <XAxis
                                        dataKey="name"
                                        axisLine={false}
                                        tickLine={false}
                                    />
                                    <YAxis
                                        domain={[0, 1]}
                                        tickFormatter={(tick) =>
                                            (tick * 100).toFixed(0) + '%'
                                        }
                                    />
                                    <Tooltip
                                        formatter={(value) =>
                                            (value * 100).toFixed(2) + '%'
                                        }
                                    />
                                    <Legend
                                        wrapperStyle={{
                                            paddingTop: '10px',
                                        }}
                                    />
                                    <Bar
                                        dataKey="Before Mitigation"
                                        fill="#673ab7"
                                        radius={[4, 4, 0, 0]}
                                    />{' '}
                                    {/* Deep Purple */}
                                    <Bar
                                        dataKey="After Mitigation"
                                        fill="#00bcd4"
                                        radius={[4, 4, 0, 0]}
                                    />{' '}
                                    {/* Cyan */}
                                </BarChart>
                            </ResponsiveContainer>
                        </Paper>
                    </Grid>
                    <Grid item xs={12} md={6} flex={1}>
                        <Paper
                            elevation={0}
                            sx={{
                                p: 3,
                                borderRadius: '8px',
                                height: '100%',
                                border: '1px solid #e0e0e0',
                            }}
                        >
                            <Typography
                                variant="h6"
                                sx={{
                                    mb: 2,
                                    fontWeight: 600,
                                    color: '#232f3e',
                                }}
                            >
                                False Positive Rate (FPR) by{' '}
                                {selectedTargetColumn}
                            </Typography>
                            <ResponsiveContainer width="100%" height={250}>
                                <BarChart data={fprChartData}>
                                    <XAxis
                                        dataKey="name"
                                        axisLine={false}
                                        tickLine={false}
                                    />
                                    <YAxis
                                        domain={[0, 1]}
                                        tickFormatter={(tick) =>
                                            (tick * 100).toFixed(0) + '%'
                                        }
                                    />
                                    <Tooltip
                                        formatter={(value) =>
                                            (value * 100).toFixed(2) + '%'
                                        }
                                    />
                                    <Legend
                                        wrapperStyle={{
                                            paddingTop: '10px',
                                        }}
                                    />
                                    <Bar
                                        dataKey="Before Mitigation"
                                        fill="#795548"
                                        radius={[4, 4, 0, 0]}
                                    />{' '}
                                    {/* Brown */}
                                    <Bar
                                        dataKey="After Mitigation"
                                        fill="#607d8b"
                                        radius={[4, 4, 0, 0]}
                                    />{' '}
                                    {/* Blue Grey */}
                                </BarChart>
                            </ResponsiveContainer>
                        </Paper>
                    </Grid>
                </Grid>

                {/* Plots (Images) */}
                <Grid container spacing={3} width="100%">
                    {plots?.before_mitigation?.accuracy_plot && (
                        <Grid item xs={12} md={6} flex={1}>
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Accuracy Plot (Before Mitigation)
                                </Typography>
                                <img
                                    src={`data:image/png;base64,${plots.before_mitigation.accuracy_plot}`}
                                    alt="Accuracy Plot Before Mitigation"
                                    style={{
                                        maxWidth: '100%',
                                        height: 'auto',
                                        borderRadius: '4px',
                                        border: '1px solid #ddd',
                                    }}
                                />
                            </Paper>
                        </Grid>
                    )}
                    {plots?.after_mitigation?.accuracy_plot && (
                        <Grid item xs={12} md={6} flex={1}>
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Accuracy Plot (After Mitigation)
                                </Typography>
                                <img
                                    src={`data:image/png;base64,${plots.after_mitigation.accuracy_plot}`}
                                    alt="Accuracy Plot After Mitigation"
                                    style={{
                                        maxWidth: '100%',
                                        height: 'auto',
                                        borderRadius: '4px',
                                        border: '1px solid #ddd',
                                    }}
                                />
                            </Paper>
                        </Grid>
                    )}
                </Grid>
                <Grid container spacing={3} width="100%">
                    {' '}
                    {plots?.before_mitigation?.selection_rate_plot && (
                        <Grid item xs={12} md={6} flex={1}>
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Selection Rate Plot (Before Mitigation)
                                </Typography>
                                <img
                                    src={`data:image/png;base64,${plots.before_mitigation.selection_rate_plot}`}
                                    alt="Selection Rate Plot Before Mitigation"
                                    style={{
                                        maxWidth: '100%',
                                        height: 'auto',
                                        borderRadius: '4px',
                                        border: '1px solid #ddd',
                                    }}
                                />
                            </Paper>
                        </Grid>
                    )}
                    {plots?.after_mitigation?.selection_rate_plot && (
                        <Grid item xs={12} md={6} flex={1}>
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    alignItems: 'center',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Selection Rate Plot (After Mitigation)
                                </Typography>
                                <img
                                    src={`data:image/png;base64,${plots.after_mitigation.selection_rate_plot}`}
                                    alt="Selection Rate Plot After Mitigation"
                                    style={{
                                        maxWidth: '100%',
                                        height: 'auto',
                                        borderRadius: '4px',
                                        border: '1px solid #ddd',
                                    }}
                                />
                            </Paper>
                        </Grid>
                    )}
                </Grid>
            </Grid>
        </TabPanel>
    )
}

export default FairnessMatrix
