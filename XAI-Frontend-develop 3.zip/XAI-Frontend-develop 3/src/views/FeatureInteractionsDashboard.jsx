// src/views/FeatureInteractionsDashboard.jsx
import React, { useState } from 'react'
import {
    Box,
    Typography,
    Button,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Stack,
    Paper,
    Tooltip,
} from '@mui/material'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'

// Mock data for features
const MOCK_TITANIC_FEATURES = [
    'Sex',
    'PassengerClass',
    'Age',
    'Fare',
    'Embarked',
    'SibSp',
    'Parch',
    'Deck',
]

// Mock data for Feature Interactions (e.g., Sex and PassengerClass)
const MOCK_SEX_CLASS_INTERACTION = [
    { sex: 'male', class: '1st', interaction_effect: 0.15 },
    { sex: 'male', class: '2nd', interaction_effect: 0.05 },
    { sex: 'male', class: '3rd', interaction_effect: -0.1 },
    { sex: 'female', class: '1st', interaction_effect: 0.25 },
    { sex: 'female', class: '2nd', interaction_effect: 0.18 },
    { sex: 'female', class: '3rd', interaction_effect: 0.08 },
]

const FeatureInteractionsDashboard = ({
    setOpenSideBar,
    setSelectedProject,
    selectedProject,
    setShowChatBot,
}) => {
    const [interactionFeature1, setInteractionFeature1] = useState('Sex')
    const [interactionFeature2, setInteractionFeature2] =
        useState('PassengerClass')

    return (
        <Box mt={12}>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}
            >
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                    Feature Interaction Plots
                </Typography>
                <Button
                    variant="contained"
                    startIcon={<PlayArrowIcon />}
                    onClick={() => setShowChatBot && setShowChatBot(true)}
                    sx={{ mb: 2 }}
                >
                    Explain with AI
                </Button>
            </Box>

            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 3 }}>
                Explore how two features interact to influence the model's
                prediction.
            </Typography>

            <Stack
                direction={{ xs: 'column', sm: 'row' }}
                spacing={3}
                alignItems={{ xs: 'flex-start', sm: 'center' }}
                mb={4}
            >
                <FormControl
                    variant="outlined"
                    size="small"
                    sx={{ minWidth: 200 }}
                >
                    <InputLabel id="interaction-feature1-label">
                        Feature 1
                    </InputLabel>
                    <Select
                        labelId="interaction-feature1-label"
                        value={interactionFeature1}
                        onChange={(e) => setInteractionFeature1(e.target.value)}
                        label="Feature 1"
                    >
                        {MOCK_TITANIC_FEATURES.map((f) => (
                            <MenuItem key={f} value={f}>
                                {f}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
                <FormControl
                    variant="outlined"
                    size="small"
                    sx={{ minWidth: 200 }}
                >
                    <InputLabel id="interaction-feature2-label">
                        Feature 2
                    </InputLabel>
                    <Select
                        labelId="interaction-feature2-label"
                        value={interactionFeature2}
                        onChange={(e) => setInteractionFeature2(e.target.value)}
                        label="Feature 2"
                    >
                        {MOCK_TITANIC_FEATURES.map((f) => (
                            <MenuItem key={f} value={f}>
                                {f}
                            </MenuItem>
                        ))}
                    </Select>
                </FormControl>
            </Stack>

            <Paper
                variant="outlined"
                sx={{
                    p: 3,
                    borderRadius: '8px',
                    minHeight: '400px',
                    display: 'flex',
                    flexDirection: 'column',
                    alignItems: 'center',
                    justifyContent: 'center',
                    color: 'text.secondary',
                    bgcolor: 'grey.50',
                }}
            >
                <Typography variant="h6" sx={{ mb: 2 }}>
                    Interaction Plot for "{interactionFeature1}" and "
                    {interactionFeature2}"
                </Typography>
                <Box
                    sx={{
                        width: '90%',
                        height: '300px',
                        border: '1px dashed grey',
                        display: 'grid',
                        gridTemplateColumns: `repeat(${new Set(MOCK_SEX_CLASS_INTERACTION.map((d) => d.class)).size}, 1fr)`,
                        gridTemplateRows: `repeat(${new Set(MOCK_SEX_CLASS_INTERACTION.map((d) => d.sex)).size}, 1fr)`,
                        gap: 1,
                        p: 2,
                    }}
                >
                    {MOCK_SEX_CLASS_INTERACTION.map((data, idx) => (
                        <Tooltip
                            key={idx}
                            title={`Sex: ${data.sex}, Class: ${data.class}, Effect: ${data.interaction_effect.toFixed(2)}`}
                        >
                            <Box
                                sx={{
                                    bgcolor:
                                        data.interaction_effect > 0
                                            ? 'success.light'
                                            : 'error.light',
                                    border: `1px solid ${data.interaction_effect > 0 ? 'success.main' : 'error.main'}`,
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    fontWeight: 'bold',
                                    fontSize: '0.9em',
                                    color:
                                        data.interaction_effect > 0
                                            ? 'success.dark'
                                            : 'error.dark',
                                }}
                            >
                                {data.sex === 'female' ? 'F' : 'M'}/
                                {data.class.charAt(0)} (
                                {data.interaction_effect.toFixed(2)})
                            </Box>
                        </Tooltip>
                    ))}
                </Box>
                <Typography
                    variant="caption"
                    color="text.disabled"
                    sx={{ mt: 2 }}
                >
                    (Actual Interaction plots often use heatmaps or 3D surfaces
                    with charting libraries like Plotly.js)
                </Typography>
            </Paper>
        </Box>
    )
}

export default FeatureInteractionsDashboard
