import { useDispatch, useSelector } from 'react-redux'
import axios from 'axios'
import {
    setFairnessAnalysis,
    setFairnessAnalysisLoading,
} from '../store/fairnessSlice'
import {
    setRegressionAnalysis,
    setRegressionAnalysisLoading,
    setRegressionModelExplainibility,
    setRegressionModelExplainibilityisLoading,
} from '../store/regressionSlice'
import {
    setClassificationReport,
    setClassificationAnalysis,
    setClassificationDashboard,
    setClassificationLoading,
    clearClassificationData,
} from '../store/classificationSlice'

const AnalysisActions = ({
    selectedTargetColumn,
    selectedSensitiveFeature,
    selectedMitigationStrategy,
}) => {
    const dispatch = useDispatch()
    const { datasets } = useSelector((state) => state.fairness)
    const { token } = useSelector((state) => state.auth)

    const runFairnessAnalysis = async () => {
        const reference_file_url = datasets?.fairness?.files.find((e) =>
            e.file_name.includes('ref_')
        )
        const current_file_url = datasets?.fairness?.files.find((e) =>
            e.file_name.includes('cur_')
        )

        const modelFile = datasets?.fairness?.files.find(
            (e) => e.folder === 'models'
        )

        const formData = new FormData()
        formData.append('reference_file_url', reference_file_url?.url || '')
        formData.append('current_file_url', current_file_url?.url || '')
        formData.append('target_column', selectedTargetColumn || '')
        formData.append('sensitive_feature', selectedSensitiveFeature || '')
        formData.append('mitigation_strategy', selectedMitigationStrategy || '')
        formData.append('model_url', modelFile?.url || '')
        formData.append(
            'model_format',
            modelFile?.file_name?.split('.')?.[1] || ''
        )

        try {
            dispatch(setFairnessAnalysisLoading(true))
            const response = await axios.post(
                'http://localhost:8000/fairness/perform_analysis',
                formData,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'multipart/form-data',
                    },
                }
            )

            dispatch(setFairnessAnalysis(response.data))
            dispatch(setFairnessAnalysisLoading(false))
        } catch (error) {
            console.error(
                'Axios Error:',
                error?.response?.data || error.message
            )
            dispatch(setFairnessAnalysisLoading(false))
        }
    }

    const runRegressionAnalysis = async () => {
        dispatch(setRegressionModelExplainibility(null))
        dispatch(setRegressionAnalysis(null))
        const payload = {
            target_column: selectedTargetColumn || '',
            analysis_type: 'Regression',
        }
        try {
            dispatch(setRegressionAnalysisLoading(true))
            const response = await axios.post(
                'http://localhost:8000/regression/analyze/regression',
                payload,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )

            dispatch(setRegressionAnalysis(response.data))
            dispatch(setRegressionAnalysisLoading(false))
        } catch (error) {
            console.error(
                'Axios Error:',
                error?.response?.data || error.message
            )
            dispatch(setRegressionAnalysisLoading(false))
        }
    }

    const runRegressionModelExplainibility = async () => {
        const payload = {
            target_column: selectedTargetColumn || '',
            analysis_type: 'Regression',
        }
        try {
            dispatch(setRegressionModelExplainibilityisLoading(true))
            const response = await axios.post(
                'http://localhost:8000/regression/explain/model',
                payload,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )
            dispatch(setRegressionModelExplainibility(response.data))
            dispatch(setRegressionModelExplainibilityisLoading(false))
        } catch (error) {
            console.error(
                'Axios Error:',
                error?.response?.data || error.message
            )
            dispatch(setRegressionModelExplainibilityisLoading(false))
        }
    }

    const runClassificationReport = async () => {
        dispatch(clearClassificationData())
        const payload = {
            target_column: selectedTargetColumn || '',
        }
        try {
            dispatch(setClassificationLoading(true))
            const response = await axios.post(
                'http://localhost:8000/classification/report/html',
                payload,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )

            dispatch(setClassificationReport(response.data))
            dispatch(setClassificationLoading(false))
        } catch (error) {
            console.error(
                'Axios Error:',
                error?.response?.data || error.message
            )
            dispatch(setClassificationLoading(false))
        }
    }

    const runClassificationAnalysis = async () => {
        dispatch(clearClassificationData())
        const payload = {
            target_column: selectedTargetColumn || '',
        }
        try {
            dispatch(setClassificationLoading(true))
            const response = await axios.post(
                'http://localhost:8000/classification/analysis/markdown',
                payload,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )

            dispatch(setClassificationAnalysis(response.data))
            dispatch(setClassificationLoading(false))
        } catch (error) {
            console.error(
                'Axios Error:',
                error?.response?.data || error.message
            )
            dispatch(setClassificationLoading(false))
        }
    }

    const runClassificationDashboard = async () => {
        dispatch(clearClassificationData())
        const payload = {
            target_column: selectedTargetColumn || '',
        }
        try {
            dispatch(setClassificationLoading(true))
            const response = await axios.post(
                'http://localhost:8000/classification/dashboard/url',
                payload,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'Content-Type': 'application/json',
                    },
                }
            )

            dispatch(setClassificationDashboard(response.data))
            dispatch(setClassificationLoading(false))
        } catch (error) {
            console.error(
                'Axios Error:',
                error?.response?.data || error.message
            )
            dispatch(setClassificationLoading(false))
        }
    }

    return {
        runFairnessAnalysis,
        runRegressionAnalysis,
        runRegressionModelExplainibility,
        runClassificationReport,
        runClassificationAnalysis,
        runClassificationDashboard,
    }
}

export const useAnalysisActions = (props) => {
    return AnalysisActions(props)
}

export default AnalysisActions
