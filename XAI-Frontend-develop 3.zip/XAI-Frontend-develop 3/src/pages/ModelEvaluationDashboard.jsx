import React, { useState } from 'react'
import {
    Box,
    Button,
    TextField,
    Typography,
    List,
    ListItem,
    ListItemText,
    IconButton,
} from '@mui/material'
import ChatIcon from '@mui/icons-material/Chat'
import CloseIcon from '@mui/icons-material/Close'
import DashboardNavBar from '../components/DashboardNavbar'

export default function ModelEvaluationTabs() {
    const [messages, setMessages] = useState([
        {
            from: 'bot',
            text: 'Hi! How can I help you explain this dashboard?',
        },
    ])
    const [input, setInput] = useState('')
    const [chatOpen, setChatOpen] = useState(false)

    const handleSend = () => {
        if (!input.trim()) return
        setMessages((prev) => [...prev, { from: 'user', text: input }])
        setInput('')
        setTimeout(() => {
            setMessages((prev) => [
                ...prev,
                {
                    from: 'bot',
                    text: 'This is a demo response about the model.',
                },
            ])
        }, 1000)
    }

    return (
        <Box sx={{ display: 'flex', height: '100vh', overflow: 'hidden' }}>
            {/* Left: iframe area */}
            <Box
                sx={{
                    flex: chatOpen ? '0 0 70%' : '1 1 100%',
                    transition: 'flex 0.3s ease',
                    borderRight: chatOpen ? '1px solid #ccc' : 'none',
                }}
            >
                <iframe
                    src="https://titanicexplainer.herokuapp.com/classifier"
                    width="100%"
                    height="100%"
                    style={{ border: 0 }}
                />
            </Box>

            {/* Right: chatbot panel */}
            {chatOpen && (
                <Box
                    sx={{
                        flex: '0 0 30%',
                        display: 'flex',
                        flexDirection: 'column',
                        bgcolor: '#f9f9f9',
                        height: '93%',
                        transition: 'all 0.3s ease',
                    }}
                >
                    {/* Header with close button */}
                    <Box
                        sx={{
                            p: 2,
                            bgcolor: '#1976d2',
                            color: 'white',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                        }}
                    >
                        <Typography variant="h6">XAI Companion</Typography>
                        <IconButton
                            onClick={() => setChatOpen(false)}
                            sx={{ color: 'white' }}
                        >
                            <CloseIcon />
                        </IconButton>
                    </Box>

                    {/* Messages */}
                    <Box
                        sx={{
                            flex: 1,
                            p: 2,
                            overflowY: 'auto',
                        }}
                    >
                        <List>
                            {messages.map((msg, idx) => (
                                <ListItem
                                    key={idx}
                                    sx={{
                                        justifyContent:
                                            msg.from === 'user'
                                                ? 'flex-end'
                                                : 'flex-start',
                                    }}
                                >
                                    <ListItemText
                                        primary={msg.text}
                                        sx={{
                                            bgcolor:
                                                msg.from === 'user'
                                                    ? '#e0f7fa'
                                                    : '#e8eaf6',
                                            borderRadius: 2,
                                            p: 1.5,
                                            maxWidth: '80%',
                                        }}
                                    />
                                </ListItem>
                            ))}
                        </List>
                    </Box>

                    {/* Input */}
                    <Box
                        sx={{
                            display: 'flex',
                            p: 2,
                            borderTop: '1px solid #ccc',
                        }}
                    >
                        <TextField
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSend()
                            }}
                            placeholder="Ask me anything..."
                            fullWidth
                            size="small"
                        />
                        <Button
                            onClick={handleSend}
                            variant="contained"
                            sx={{ ml: 1 }}
                        >
                            Send
                        </Button>
                    </Box>
                </Box>
            )}

            {/* Toggle button to open chat when closed */}
            {/* {!chatOpen && (
                <Box
                    onClick={() => setChatOpen(true)}
                    sx={{
                        position: 'fixed',
                        bottom: 20,
                        right: 20,
                        display: 'flex',
                        flexDirection: 'row',
                        alignItems: 'center',
                        bgcolor: '#1976d2',
                        borderRadius: 2,
                        padding: '2px 10px 2px 10px',
                        cursor: 'pointer',
                    }}
                >
                    <Typography sx={{ color: '#fff' }}>
                        Explain with AI
                    </Typography>
                    <IconButton
                        sx={{
                            bgcolor: '#1976d2',
                            color: 'white',
                            '&:hover': { bgcolor: '#115293' },
                            zIndex: 1000,
                        }}
                        aria-label="open chat"
                    >
                        <ChatIcon />
                    </IconButton>
                </Box>
            )} */}
        </Box>
    )
}
