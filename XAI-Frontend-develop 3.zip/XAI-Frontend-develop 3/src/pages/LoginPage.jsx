import {
    Box,
    Button,
    Card,
    CardContent,
    TextField,
    Typography,
    InputAdornment,
    IconButton,
    Avatar,
    Link as MuiLink,
    CircularProgress,
} from '@mui/material'
import {
    Email,
    Lock,
    Visibility,
    VisibilityOff,
    ArrowBack,
    Shower,
} from '@mui/icons-material'
import { useNavigate, Link } from 'react-router-dom'
import { useState, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { loginUser } from '../store/authSlice' // ✅ Make sure path is correct
import { showErrorToast } from '../utils/toastUtility'
import theme from '../theme'

function LoginPage() {
    const navigate = useNavigate()
    const dispatch = useDispatch()
    // const { signupSuccess, error } = useSelector((state) => state.auth)

    const [showPassword, setShowPassword] = useState(false)
    const [email, setEmail] = useState('')
    const [password, setPassword] = useState('')

    const [emailError, setEmailError] = useState(false)
    const [passwordError, setPasswordError] = useState(false)

    const handleEmailChange = (e) => {
        const value = e.target.value
        setEmail(value)
        setEmailError(/\s/.test(value)) // error if any space present
    }

    const handlePasswordChange = (e) => {
        const value = e.target.value
        setPassword(value)
        setPasswordError(/\s/.test(value)) // error if any space present
    }
    // Redux state
    const { loading, error, user } = useSelector((state) => state.auth)

    const isFormValid = email.trim() !== '' && password.trim() !== ''

    // console.log(error, 'error')
    // Handle login submit
    // const handleLogin = () => {
    //     dispatch(loginUser({ username: email, password }))
    // }

    const handleLogin = () => {
        try {
            dispatch(loginUser({ username: email, password })).unwrap()
            // showSuccessToast('Login successful!')
            // optionally: navigate("/dashboard") or similar
        } catch (error) {
            showErrorToast(error?.message || 'Login failed')
        }
    }

    useEffect(() => {
        if (user) {
            // showSuccessToast('Login Successfull!')
            navigate('/home')
        } else {
            showErrorToast(error)
        }
    }, [user, navigate, error])

    const togglePasswordVisibility = () => {
        setShowPassword(!showPassword)
    }

    const handleGoBack = () => {
        navigate('/')
    }

    return (
        <Box
            display="flex"
            justifyContent="center"
            alignItems="center"
            minHeight="100vh"
            sx={{
                bgcolor: 'transparent', // Make background transparent to show gradient/pattern
                color: theme.palette.text.primary,

                boxShadow: theme.shadows[6], // Stronger shadow for depth

                textAlign: 'center',
                overflow: 'hidden',
                position: 'relative',
                zIndex: 1, // Ensure content is above background
                // AI-themed background gradient and subtle pattern
                background: `linear-gradient(135deg, ${theme.palette.primary.dark} 0%, ${theme.palette.secondary.dark} 100%)`, // Deep gradient
                '&::before': {
                    // Pseudo-element for circuit pattern
                    content: '""',
                    position: 'absolute',
                    top: 0,
                    left: 0,
                    right: 0,
                    bottom: 0,
                    background: `repeating-linear-gradient(
                        45deg,
                        rgba(255,255,255,0.02) 0px,
                        rgba(255,255,255,0.02) 2px,
                        transparent 2px,
                        transparent 20px
                    ),
                    repeating-linear-gradient(
                        -45deg,
                        rgba(255,255,255,0.02) 0px,
                        rgba(255,255,255,0.02) 2px,
                        transparent 2px,
                        transparent 20px
                    )`,
                    opacity: 0.8, // Make it very subtle
                    zIndex: -1, // Behind the content
                },
            }}
        >
            <Card
                sx={{
                    width: 400,
                    borderRadius: 3,
                    boxShadow: 6,
                    maxWidth: '90%',
                }}
            >
                <CardContent
                    sx={{
                        textAlign: 'center',
                        position: 'relative',
                        width: 'auto',
                        height: 'auto',
                    }}
                >
                    <IconButton
                        onClick={handleGoBack}
                        sx={{ position: 'absolute', left: 8, top: 8 }}
                        aria-label="Go back"
                    >
                        <ArrowBack />
                    </IconButton>

                    <Avatar
                        src="/logo-nav.png"
                        alt="XAI"
                        sx={{
                            width: '35%',
                            height: '100%',
                            mx: 'auto',
                            mb: 3,
                        }}
                        variant="rounded"
                    />
                    <Typography variant="h5" gutterBottom>
                        Welcome Back
                    </Typography>
                    <Typography variant="body2" color="text.secondary" mb={3}>
                        Please login to your account
                    </Typography>

                    <TextField
                        label={
                            <>
                                Email<span style={{ color: 'red' }}> *</span>
                            </>
                        }
                        type="username"
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        value={email}
                        onChange={handleEmailChange}
                        error={emailError}
                        helperText={emailError ? 'Spaces are not allowed' : ''}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Email />
                                </InputAdornment>
                            ),
                        }}
                    />

                    <TextField
                        label={
                            <>
                                Password<span style={{ color: 'red' }}> *</span>
                            </>
                        }
                        type={showPassword ? 'text' : 'password'}
                        fullWidth
                        margin="normal"
                        variant="outlined"
                        sx={{
                            '& input::-ms-reveal': { display: 'none' },
                            '& input::-ms-clear': { display: 'none' },
                        }}
                        value={password}
                        onChange={handlePasswordChange}
                        error={passwordError}
                        helperText={
                            passwordError ? 'Spaces are not allowed' : ''
                        }
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <Lock />
                                </InputAdornment>
                            ),
                            endAdornment: (
                                <InputAdornment position="end">
                                    <IconButton
                                        onClick={togglePasswordVisibility}
                                        edge="end"
                                    >
                                        {showPassword ? (
                                            <VisibilityOff />
                                        ) : (
                                            <Visibility />
                                        )}
                                    </IconButton>
                                </InputAdornment>
                            ),
                        }}
                    />

                    {/* {error && (
                        <Typography
                            color="error"
                            variant="body2"
                            sx={{ mt: 1 }}
                        >
                            {error}
                        </Typography>
                    )} */}

                    <Button
                        variant="contained"
                        color="primary"
                        fullWidth
                        size="large"
                        sx={{ mt: 2, mb: 2 }}
                        onClick={handleLogin}
                        disabled={!isFormValid || loading}
                        startIcon={loading && <CircularProgress size={20} />}
                    >
                        {loading ? 'Logging in...' : 'Login'}
                    </Button>

                    <Typography variant="body2">
                        New to RAIA?{' '}
                        <MuiLink
                            component={Link}
                            to="/signup"
                            underline="hover"
                            color="primary"
                        >
                            Sign up
                        </MuiLink>
                    </Typography>
                </CardContent>
            </Card>
        </Box>
    )
}

export default LoginPage
