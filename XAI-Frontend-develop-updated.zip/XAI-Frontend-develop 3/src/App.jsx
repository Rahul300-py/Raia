import {
    BrowserRouter as Router,
    Routes,
    Route,
    useLocation,
} from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import LoginPage from './pages/LoginPage'
import HomePage from './pages/HomePage'
import SignupPage from './pages/SignupPage'
import NewAnalysis from './pages/NewAnalysis'
import ModelEvaluationTabs from './pages/ModelEvaluationDashboard'
import Header from './components/Header'
import DashboardNavBar from './components/DashboardNavbar'
import XAIDashboardPage from './pages/XAIDashboardPage'
import ProtectedRoute from './utils/ProtectedRoute.js'
import NewLandingPage from './pages/NewLandingPage.jsx'
import { ToastContainer } from 'react-toastify'
import { useEffect } from 'react'
import { fetchDatasets } from './store/fairnessSlice.js'
import { useDispatch } from 'react-redux'
import { fetchDriftReportColumns } from './store/driftReportSlice.js'
import { fetchRegressionColumns } from './store/regressionSlice.js'
import { fetchClassificationColumns } from './store/classificationSlice.js'

function AppContent() {
    const location = useLocation()
    const PrivateHeader = [
        '/dashboard',
        '/new-analysis',
        '/home',
        '/demo',
    ].includes(location.pathname)
    const PublicHeader = ['/'].includes(location.pathname)

    return (
        <>
            {/* {PrivateHeader && <DashboardNavBar />} */}
            {PublicHeader && <Header />}
            <Routes>
                <Route path="/" element={<NewLandingPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route path="/newui" element={<NewLandingPage />} />

                {/* ✅ Protected Routes */}
                <Route
                    path="/home"
                    element={
                        <ProtectedRoute>
                            <HomePage />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/dashboard"
                    element={
                        <ProtectedRoute>
                            <XAIDashboardPage />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/demo"
                    element={
                        <ProtectedRoute>
                            <ModelEvaluationTabs />
                        </ProtectedRoute>
                    }
                />
                <Route
                    path="/new-analysis"
                    element={
                        <ProtectedRoute>
                            <NewAnalysis />
                        </ProtectedRoute>
                    }
                />

                <Route path="*" element={<h2>404 - Not Found</h2>} />
            </Routes>
            <ToastContainer position="top-right" autoClose={3000} />
        </>
    )
}

function App() {
    const dispatch = useDispatch()
    useEffect(() => {
        dispatch(fetchDatasets())
        dispatch(fetchDriftReportColumns())
        dispatch(fetchRegressionColumns())
        dispatch(fetchClassificationColumns())
    }, [dispatch])
    return (
        <Router>
            <AppContent />
        </Router>
    )
}

export default App
