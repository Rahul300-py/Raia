import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

export const fetchDriftReport = createAsyncThunk(
    'driftReport/fetchDriftReport',
    async (_, { rejectWithValue }) => {
        const token = await localStorage.getItem('token')
        try {
            const response = await axios.post(
                'http://13.204.101.134:8000/data_drift/full_drift_report',
                {},
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )
            const data = response.data

            // Get available columns from ref_preview[0] keys
            const refPreview = data.data_preview?.ref_preview?.[0] || {}
            const availableColumns = Object.keys(refPreview)

            return {
                driftSummary: data.drift_summary,
                availableColumns: availableColumns,
            }
        } catch (error) {
            console.error(error)
            return rejectWithValue(
                error.response?.data || 'Failed to fetch report'
            )
        }
    }
)
export const fetchDriftReportColumns = createAsyncThunk(
    'driftReport/fetchDriftReportColumns',
    async (_, { rejectWithValue }) => {
        try {
            const token = localStorage.getItem('token')

            const response = await axios.get(
                'http://13.204.101.134:8000/data_drift/columns/Data Drift',
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )
            if (response.data.error) return []
            // Check if response.data is an object and has keys
            const data = response?.data
            const keys =
                data && typeof data === 'object' ? Object.keys(data) : []

            // Safely extract the first key's value or fallback to empty array
            const payload = keys.length > 0 ? data[keys[0]] || [] : []

            return payload
        } catch (error) {
            console.error('Error fetching drift report columns:', error)
            return rejectWithValue(
                error?.response?.data || 'Failed to fetch report'
            )
        }
    }
)

const driftReportSlice = createSlice({
    name: 'driftReport',
    initialState: {
        driftSummary: null,
        availableColumns: [],
        loading: false,
        error: null,
    },
    reducers: {},
    extraReducers: (builder) => {
        builder
            .addCase(fetchDriftReport.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchDriftReport.fulfilled, (state, action) => {
                state.loading = false
                state.driftSummary = action.payload.driftSummary
                state.availableColumns = action.payload.availableColumns
            })
            .addCase(fetchDriftReport.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
            .addCase(fetchDriftReportColumns.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchDriftReportColumns.fulfilled, (state, action) => {
                state.loading = false
                state.availableColumns = action.payload
            })
            .addCase(fetchDriftReportColumns.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
    },
})

export default driftReportSlice.reducer
