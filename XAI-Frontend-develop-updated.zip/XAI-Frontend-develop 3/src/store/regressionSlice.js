import { createSlice, createAsyncThunk } from '@reduxjs/toolkit'
import axios from 'axios'

const BASE_URL = 'http://13.204.101.134:8000'

export const fetchDataPreview = createAsyncThunk(
    'regression/fetchDataPreview',

    async (_, thunkAPI) => {
        const file =
            thunkAPI.getState().regression?.datasets?.regression?.files[0]
        try {
            const token = thunkAPI.getState().auth.token
            const response = await axios.get(
                `${BASE_URL}/regression/preview_dataset`,
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                    params: {
                        file_url: file.url,
                    },
                }
            )
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'Failed to fetch datasets'
            )
        }
    }
)

export const fetchRegressionHealth = createAsyncThunk(
    'regression/fetchregressionHealth',
    async (_, thunkAPI) => {
        try {
            const token = localStorage.getItem('token')
            const response = await axios.get(`${BASE_URL}/regression/health`, {
                headers: { Authorization: `Bearer ${token}` },
            })
            return response.data
        } catch (err) {
            return thunkAPI.rejectWithValue(
                err?.response?.data?.detail ||
                    err?.message ||
                    'regression service health check failed'
            )
        }
    }
)

export const fetchRegressionColumns = createAsyncThunk(
    'regression/fetchRegressionColumns',
    async (_, { rejectWithValue }) => {
        try {
            const token = localStorage.getItem('token')

            const response = await axios.get(
                'http://13.204.101.134:8000/data_drift/columns/Regression',
                {
                    headers: {
                        Authorization: `Bearer ${token}`,
                    },
                }
            )

            // Check if response.data is an object and has keys
            if (response.data.error) return []
            const data = response?.data

            const keys =
                data && typeof data === 'object' ? Object.keys(data) : []

            // Safely extract the first key's value or fallback to empty array
            const payload = keys.length > 0 ? data[keys[0]] || [] : []

            return payload
        } catch (error) {
            console.error('Error fetching drift report columns:', error)
            return rejectWithValue(
                error?.response?.data || 'Failed to fetch report'
            )
        }
    }
)

// Initial state
const initialState = {
    health: null,
    availableColumns: [],
    mitigationStrategies: [],
    datasets: [],
    dataPreview: null,
    regressionAnalysis: null,
    regressionModelExplainibility: null,
    loading: false,
    error: null,
}

const regressionSlice = createSlice({
    name: 'regression',
    initialState,
    reducers: {
        setRegressionAnalysis: (state, action) => {
            state.regressionAnalysis = action.payload
        },
        setRegressionModelExplainibility: (state, action) => {
            state.regressionModelExplainibility = action.payload
        },
        setRegressionAnalysisLoading: (state, action) => {
            state.loading = action.payload
        },
        setRegressionModelExplainibilityisLoading: (state, action) => {
            state.loading = action.payload
        },
    },
    extraReducers: (builder) => {
        // Mitigation Strategies
        builder
            .addCase(fetchDataPreview.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchDataPreview.fulfilled, (state, action) => {
                state.loading = false
                state.dataPreview = action.payload || []
            })
            .addCase(fetchDataPreview.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            // Health
            .addCase(fetchRegressionHealth.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchRegressionHealth.fulfilled, (state, action) => {
                state.loading = false
                state.health = action.payload
            })
            .addCase(fetchRegressionHealth.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })

            .addCase(fetchRegressionColumns.pending, (state) => {
                state.loading = true
                state.error = null
            })
            .addCase(fetchRegressionColumns.fulfilled, (state, action) => {
                state.loading = false
                state.availableColumns = action.payload
            })
            .addCase(fetchRegressionColumns.rejected, (state, action) => {
                state.loading = false
                state.error = action.payload
            })
    },
})

export const {
    setRegressionAnalysis,
    setRegressionAnalysisLoading,
    setRegressionModelExplainibility,
    setRegressionModelExplainibilityisLoading,
} = regressionSlice.actions

export default regressionSlice.reducer
