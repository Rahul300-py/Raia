import React from 'react'
/* eslint-disable no-unused-vars */
import {
    Box,
    ListItem,
    Typography,
    Card,
    CardContent,
    Button,
    Slider,
    Checkbox,
    FormControlLabel,
    Select,
    MenuItem,
    Chip,
    OutlinedInput,
    InputLabel,
    FormControl,
    TextField,
    Stack,
    ListItemText,
} from '@mui/material'
import {
    Close as CloseIcon,
    ArrowDropDown,
    ArrowDropUp,
} from '@mui/icons-material'
import { useDispatch } from 'react-redux'

// Import the new common components
import DrawerIconList from '../common/DrawerIconList'
import FileUploadBox from '../common/FileUploadBox'
import ColumnSelector from '../common/ColumnSelector'

function DataDriftDrawer({
    open,
    setOpen,
    showUploadForm1,
    setShowUploadForm1,
    handleBrowse,
    fileState,
    handleSave,
    loading,
    showUploadForm2,
    setShowUploadForm2,
    percentage,
    setPercentage,
    availableColumnsLoading,
    excludedColumns,
    setExcludedColumns,
    availableColumns,
    useDateColumnSplit,
    setUseDateColumnSplit,
    selectedDateColumn,
    setSelectedDateColumn,
    referenceStartDate,
    setReferenceStartDate,
    currentStartDate,
    setCurrentStartDate,
    handleFetchDetails,
}) {
    const dispatch = useDispatch()

    return open ? (
        <ListItem disablePadding sx={{ display: 'block', px: 2.5, mt: 3 }}>
            <Typography
                variant="subtitle"
                sx={{ color: '#fff', fontWeight: 'bold' }}
            >
                Upload Data for analysis
            </Typography>

            {/* Option 1: Separate Files */}
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                        onClick={() =>
                            !showUploadForm1 && setShowUploadForm1(true)
                        }
                        sx={{ cursor: 'pointer' }}
                    >
                        <Typography
                            variant="subtitle2"
                            sx={{ mb: 1, fontWeight: 'bold' }}
                        >
                            Option 1: Reference & Current files
                        </Typography>
                        <Button
                            onClick={() => setShowUploadForm1((prev) => !prev)}
                            sx={{ minWidth: 0 }}
                        >
                            {showUploadForm1 ? (
                                <ArrowDropUp />
                            ) : (
                                <ArrowDropDown />
                            )}
                        </Button>
                    </Stack>

                    {showUploadForm1 && (
                        <Box>
                            <FileUploadBox
                                title="Drag and drop Train (Reference) file"
                                description="Limit 200MB per file • CSV"
                                buttonText="Browse files"
                                onBrowse={() => handleBrowse('train')}
                                file={fileState.train}
                            />
                            <FileUploadBox
                                title="Drag and drop Test (Current) file"
                                description="Limit 200MB per file • CSV"
                                buttonText="Browse files"
                                onBrowse={() => handleBrowse('test')}
                                file={fileState.test}
                            />
                            <Button
                                onClick={handleSave}
                                variant="contained"
                                sx={{ width: '100%', mt: 2 }}
                                disabled={
                                    loading ||
                                    !(fileState.test || fileState.train)
                                }
                            >
                                {loading && fileState.test && fileState.train
                                    ? 'Uploading...'
                                    : 'Save'}
                            </Button>
                        </Box>
                    )}
                </CardContent>
            </Card>

            {/* Option 2: Combined File */}
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <Stack
                        direction="row"
                        alignItems="center"
                        justifyContent="space-between"
                        onClick={() =>
                            !showUploadForm2 && setShowUploadForm2(true)
                        }
                        sx={{ cursor: 'pointer' }}
                    >
                        <Typography
                            variant="subtitle2"
                            sx={{ mb: 1, fontWeight: 'bold' }}
                        >
                            Option 2: Combined CSV file
                        </Typography>
                        <Button
                            onClick={() => setShowUploadForm2((prev) => !prev)}
                            sx={{ minWidth: 0 }}
                        >
                            {showUploadForm2 ? (
                                <ArrowDropUp />
                            ) : (
                                <ArrowDropDown />
                            )}
                        </Button>
                    </Stack>
                    {showUploadForm2 && (
                        <Stack>
                            <FileUploadBox
                                title="Drag and drop combined CSV file"
                                description="Limit 200MB per file • CSV"
                                buttonText="Browse files"
                                onBrowse={() => handleBrowse('combined')}
                                file={fileState.combined}
                            />
                            {/* Percentage Splitter Slider */}
                            <Box sx={{ mt: 2, px: 2 }}>
                                <Typography variant="body2" sx={{ mb: 1 }}>
                                    Select percentage split: {percentage}%
                                </Typography>
                                <Slider
                                    value={percentage}
                                    onChange={(e, val) => setPercentage(val)}
                                    aria-label="Percentage Split"
                                    valueLabelDisplay="auto"
                                    step={1}
                                    min={0}
                                    max={100}
                                />
                            </Box>
                            <Button
                                variant="contained"
                                onClick={handleSave}
                                sx={{ width: '100%', mt: 2 }}
                                disabled={loading || !fileState.combined}
                            >
                                {loading && fileState.combined
                                    ? 'Uploading...'
                                    : 'Save'}
                            </Button>
                        </Stack>
                    )}
                </CardContent>
            </Card>

            {/* Exclude Columns */}
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <Typography
                        variant="subtitle2"
                        sx={{ mb: 1, fontWeight: 'bold', whiteSpace: 'normal' }}
                    >
                        Select columns to exclude from drift analysis
                    </Typography>
                    {/* This multi-select is highly specific, so we leave it here */}
                    <FormControl fullWidth size="small">
                        <InputLabel id="exclude-columns-label">
                            Exclude Columns
                        </InputLabel>
                        <Select
                            labelId="exclude-columns-label"
                            multiple
                            value={excludedColumns}
                            onChange={(e) =>
                                dispatch(
                                    setExcludedColumns(
                                        typeof e.target.value === 'string'
                                            ? e.target.value.split(',')
                                            : e.target.value
                                    )
                                )
                            }
                            input={<OutlinedInput label="Exclude Columns" />}
                            renderValue={(selected) => (
                                <Box
                                    sx={{
                                        display: 'flex',
                                        flexWrap: 'wrap',
                                        gap: 0.5,
                                    }}
                                >
                                    {selected.map((value) => (
                                        <Chip
                                            key={value}
                                            label={value}
                                            onDelete={() =>
                                                dispatch(
                                                    setExcludedColumns(
                                                        excludedColumns.filter(
                                                            (col) =>
                                                                col !== value
                                                        )
                                                    )
                                                )
                                            }
                                            deleteIcon={<CloseIcon />}
                                        />
                                    ))}
                                </Box>
                            )}
                        >
                            {availableColumns.map((column) => (
                                <MenuItem key={column} value={column}>
                                    <Checkbox
                                        checked={
                                            excludedColumns.indexOf(column) > -1
                                        }
                                    />
                                    <ListItemText
                                        primary={
                                            <Typography fontSize="14px">
                                                {column}
                                            </Typography>
                                        }
                                    />
                                </MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </CardContent>
            </Card>

            {/* Date-based Split */}
            <Card sx={{ my: 2, borderRadius: '8px' }}>
                <CardContent sx={{ p: 2 }}>
                    <FormControlLabel
                        control={
                            <Checkbox
                                checked={useDateColumnSplit}
                                onChange={(e) =>
                                    dispatch(
                                        setUseDateColumnSplit(e.target.checked)
                                    )
                                }
                            />
                        }
                        label="Use date column to split reference/current datasets"
                        sx={{
                            fontWeight: 'bold',
                            whiteSpace: 'normal',
                            width: '100%',
                        }}
                    />
                    {useDateColumnSplit && (
                        <Box>
                            <ColumnSelector
                                label="Select Date Column"
                                value={selectedDateColumn}
                                onChange={(e) =>
                                    dispatch(
                                        setSelectedDateColumn(e.target.value)
                                    )
                                }
                                options={availableColumns}
                                loading={availableColumnsLoading}
                                placeholder="Select Date Column"
                            />
                            <TextField
                                label="Reference Start"
                                type="date"
                                size="small"
                                value={referenceStartDate}
                                onChange={(e) =>
                                    dispatch(
                                        setReferenceStartDate(e.target.value)
                                    )
                                }
                                InputLabelProps={{ shrink: true }}
                                fullWidth
                                sx={{ my: 2 }}
                            />
                            <TextField
                                label="Current Start"
                                type="date"
                                size="small"
                                value={currentStartDate}
                                onChange={(e) =>
                                    dispatch(
                                        setCurrentStartDate(e.target.value)
                                    )
                                }
                                InputLabelProps={{ shrink: true }}
                                fullWidth
                            />
                        </Box>
                    )}
                </CardContent>
            </Card>

            <Button
                sx={{
                    textTransform: 'none',
                    color: '#fff',
                    backgroundColor: '#8c52ff',
                    width: '100%',
                    padding: 1,
                    '&:hover': { backgroundColor: '#5a31ab' },
                }}
                onClick={handleFetchDetails}
            >
                Fetch Details
            </Button>
        </ListItem>
    ) : (
        // Use the common component for the closed state
        <DrawerIconList onIconClick={() => setOpen(true)} />
    )
}

export default DataDriftDrawer
