// src/components/TestimonialsSection.js
import React from 'react'
import {
    Box,
    Typography,
    Container,
    Grid,
    Paper,
    Avatar,
    Stack,
} from '@mui/material'

const testimonials = [
    {
        avatar: '/user-avatar-1.jpg', // Placeholder, replace with actual paths
        name: 'Demetris Papadopoulos',
        title: 'Director of Engineering, Marlach, Flo Health',
        quote: '"XAI is a neat and easy to use product. My team built and owns the business ML platform, and XAI has been one of our choices for its composition. Our model performance monitoring module with XAI at its core allows us to keep an eye on our productioned models and act early."',
    },
    {
        avatar: '/user-avatar-2.jpg', // Placeholder
        name: 'Moe Antar',
        title: 'Senior Data Engineer, PlushCare',
        quote: '"We use XAI to continuously monitor our business-critical ML models at all stages of the ML lifecycle. It has become an invaluable tool, enabling us to flag model drift and data quality issues directly from our CI/CD and model monitoring DAGs. We can proactively address potential issues before they impact our end users."',
    },
    {
        avatar: '/user-avatar-3.jpg', // Placeholder
        name: 'Jonathan Bown',
        title: 'MLOps Engineer, Western Governors University',
        quote: '"The user experience of our MLOps platform has been enhanced by integrating XAI alongside new preset tests and metrics expedited the provision of infrastructure with the tools for monitoring models. XAI enhanced the flexibility of our platform for data scientists to further customize tests, metrics, and dashboards to meet their unique requirements."',
    },
    // Add more testimonials here based on your screenshots
]

const TestimonialsSection = () => {
    return (
        <Box
            sx={{
                backgroundColor: 'background.default',
                py: { xs: 8, md: 12 },
            }}
        >
            <Container maxWidth="lg" sx={{ textAlign: 'center' }}>
                <Typography
                    variant="overline"
                    display="block"
                    color="text.secondary"
                    sx={{ mb: 2, textTransform: 'uppercase' }}
                >
                    Testimonials
                </Typography>
                <Typography
                    variant="h3"
                    component="h2"
                    sx={{ fontWeight: 'bold', mb: 8 }}
                >
                    Trusted by{' '}
                    <Box component="span" sx={{ color: 'secondary.main' }}>
                        AI teams worldwide
                    </Box>
                </Typography>
                <Typography
                    variant="body1"
                    sx={{ color: 'text.secondary', mb: 8 }}
                >
                    XAI is used in 1000s of companies, from startups to
                    enterprise.
                </Typography>

                <Grid container spacing={4} justifyContent="center">
                    {testimonials.map((testimonial, index) => (
                        <Grid item xs={12} sm={6} md={4} key={index}>
                            <Paper
                                elevation={3}
                                sx={{
                                    p: 4,
                                    borderRadius: '15px',
                                    height: '100%',
                                    display: 'flex',
                                    flexDirection: 'column',
                                    textAlign: 'left',
                                }}
                            >
                                <Typography
                                    variant="body1"
                                    sx={{
                                        fontStyle: 'italic',
                                        mb: 3,
                                        flexGrow: 1,
                                    }}
                                >
                                    {testimonial.quote}
                                </Typography>
                                <Stack
                                    direction="row"
                                    spacing={2}
                                    alignItems="center"
                                    sx={{ mt: 3 }}
                                >
                                    <Avatar
                                        src={testimonial.avatar}
                                        alt={testimonial.name}
                                        sx={{ width: 56, height: 56 }}
                                    />
                                    <Box>
                                        <Typography
                                            variant="subtitle1"
                                            sx={{ fontWeight: 600 }}
                                        >
                                            {testimonial.name}
                                        </Typography>
                                        <Typography
                                            variant="body2"
                                            color="text.secondary"
                                        >
                                            {testimonial.title}
                                        </Typography>
                                    </Box>
                                </Stack>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>
                {/* Placeholder for small dashboard image at bottom right */}
                <Box
                    sx={{
                        position: 'relative',
                        width: '100%',
                        height: '0', // Placeholder for aspect ratio
                        pb: '20%', // Adjust for desired aspect ratio
                        mt: 8,
                        overflow: 'hidden',
                        // backgroundImage: 'url(/path/to/small-dashboard-mock.png)', // If you have an image
                        // backgroundSize: 'contain',
                        // backgroundRepeat: 'no-repeat',
                        // backgroundPosition: 'bottom right',
                    }}
                >
                    <Box
                        sx={{
                            position: 'absolute',
                            bottom: 0,
                            right: 0,
                            width: { xs: '150px', md: '200px' },
                            height: { xs: '100px', md: '130px' },
                            backgroundColor: 'grey.200', // Placeholder
                            borderRadius: '8px',
                            boxShadow: '0 5px 15px rgba(0,0,0,0.1)',
                            display: 'flex',
                            alignItems: 'center',
                            justifyContent: 'center',
                            fontSize: '0.8em',
                            color: 'text.secondary',
                        }}
                    >
                        Dashboard Mock
                    </Box>
                </Box>
            </Container>
        </Box>
    )
}

export default TestimonialsSection
