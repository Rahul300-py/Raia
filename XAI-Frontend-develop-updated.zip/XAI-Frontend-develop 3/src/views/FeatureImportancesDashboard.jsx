// src/views/FeatureImportancesDashboard.jsx
import React, { useState } from 'react'
import {
    Box,
    Typography,
    Button,
    Select,
    MenuItem,
    FormControl,
    InputLabel,
    Stack,
    Paper,
    Divider,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
} from '@mui/material'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    CartesianGrid,
    ResponsiveContainer,
    LabelList,
    Tooltip,
} from 'recharts'

// Mock data for Titanic features and SHAP values
const MOCK_TITANIC_SHAP_DATA = [
    {
        feature: 'Sex',
        description: 'Gender of passenger (male/female)',
        importance: 0.28,
        type: 'Categorical',
    },
    {
        feature: 'PassengerClass',
        description: 'Ticket class (1st, 2nd, 3rd)',
        importance: 0.22,
        type: 'Categorical',
    },
    {
        feature: 'Age',
        description: 'Age in years',
        importance: 0.18,
        type: 'Numerical',
    },
    {
        feature: 'Fare',
        description: 'Passenger fare',
        importance: 0.15,
        type: 'Numerical',
    },
    {
        feature: 'Embarked',
        description: 'Port of embarkation (C, Q, S)',
        importance: 0.1,
        type: 'Categorical',
    },
    {
        feature: 'SibSp',
        description: 'Number of siblings/spouses aboard',
        importance: 0.07,
        type: 'Numerical',
    },
    {
        feature: 'Parch',
        description: 'Number of parents/children aboard',
        importance: 0.05,
        type: 'Numerical',
    },
    {
        feature: 'Deck',
        description: 'Deck level (A-G, T)',
        importance: 0.03,
        type: 'Categorical',
    },
].sort((a, b) => b.importance - a.importance)

const FeatureImportancesDashboard = ({
    setOpenSideBar,
    setSelectedProject,
    selectedProject,
    setShowChatBot,
}) => {
    const [importanceType, setImportanceType] = useState('SHAP values')
    const [depth, setDepth] = useState('All')

    // Custom Recharts tooltip
    const CustomTooltip = ({ active, payload, label }) => {
        if (active && payload && payload.length) {
            const feature = MOCK_TITANIC_SHAP_DATA.find(
                (f) => f.feature === label
            )
            return (
                <Paper
                    elevation={3}
                    sx={{
                        p: 1.5,
                        borderRadius: '8px',
                        bgcolor: 'rgba(255,255,255,0.95)',
                    }}
                >
                    <Typography
                        variant="subtitle2"
                        sx={{ fontWeight: 'bold', color: 'primary.main' }}
                    >
                        {label}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                        Importance: {(payload[0].value * 100).toFixed(2)}%
                    </Typography>
                    {feature && (
                        <Typography variant="caption" color="text.disabled">
                            {feature.description}
                        </Typography>
                    )}
                </Paper>
            )
        }
        return null
    }

    return (
        <Box mt={12}>
            <Box
                sx={{
                    display: 'flex',
                    flexDirection: 'row',
                    alignItems: 'center',
                    justifyContent: 'space-between',
                }}
            >
                <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                    Feature Importances
                </Typography>
                <Button
                    variant="contained"
                    startIcon={<LightbulbIcon />}
                    onClick={() => setShowChatBot && setShowChatBot(true)}
                    sx={{
                        textTransform: 'none',
                        backgroundColor: '#333',
                        '&:hover': { backgroundColor: '#555' },
                    }}
                >
                    Explain with AI
                </Button>
            </Box>

            <Typography variant="body1" sx={{ color: 'text.secondary', mb: 3 }}>
                Which features had the biggest impact on predicting survival?
            </Typography>

            <Stack
                direction={{ xs: 'column', sm: 'row' }}
                spacing={3}
                alignItems={{ xs: 'flex-start', sm: 'center' }}
                mb={4}
            >
                <FormControl
                    variant="outlined"
                    size="small"
                    sx={{ minWidth: 200 }}
                >
                    <InputLabel id="importance-type-label">
                        Importances type
                    </InputLabel>
                    <Select
                        labelId="importance-type-label"
                        value={importanceType}
                        onChange={(e) => setImportanceType(e.target.value)}
                        label="Importances type"
                    >
                        <MenuItem value="SHAP values">SHAP values</MenuItem>
                        <MenuItem value="Permutation Importance">
                            Permutation Importance
                        </MenuItem>
                    </Select>
                </FormControl>

                <FormControl
                    variant="outlined"
                    size="small"
                    sx={{ minWidth: 120 }}
                >
                    <InputLabel id="depth-label">Depth</InputLabel>
                    <Select
                        labelId="depth-label"
                        value={depth}
                        onChange={(e) => setDepth(e.target.value)}
                        label="Depth"
                    >
                        <MenuItem value="All">All</MenuItem>
                        <MenuItem value="5">5</MenuItem>
                        <MenuItem value="10">10</MenuItem>
                    </Select>
                </FormControl>
            </Stack>

            <Typography
                variant="body2"
                sx={{
                    textAlign: 'center',
                    mb: 2,
                    color: 'text.secondary',
                }}
            >
                Average Impact on predicted Survival (mean absolute SHAP value)
            </Typography>

            <Paper variant="outlined" sx={{ p: 3, mb: 4, borderRadius: '8px' }}>
                <ResponsiveContainer width="100%" height={350}>
                    <BarChart
                        data={MOCK_TITANIC_SHAP_DATA}
                        layout="vertical"
                        margin={{
                            top: 5,
                            right: 30,
                            left: 80,
                            bottom: 5,
                        }}
                    >
                        <CartesianGrid
                            strokeDasharray="3 3"
                            horizontal={false}
                        />
                        <XAxis
                            type="number"
                            tickFormatter={(value) =>
                                `${(value * 100).toFixed(0)}%`
                            }
                        />
                        <YAxis
                            type="category"
                            dataKey="feature"
                            width={100}
                            tickLine={false}
                            axisLine={false}
                        />
                        <Tooltip content={<CustomTooltip />} />
                        <Bar
                            dataKey="importance"
                            fill="#042d56ff"
                            minPointSize={5}
                        >
                            <LabelList
                                dataKey="importance"
                                position="right"
                                formatter={(value) =>
                                    (value * 100).toFixed(1) + '%'
                                }
                                fill="#333"
                            />
                        </Bar>
                    </BarChart>
                </ResponsiveContainer>
                <Box sx={{ textAlign: 'right', mt: 2 }}>
                    <Button
                        variant="outlined"
                        size="small"
                        sx={{ textTransform: 'none' }}
                    >
                        Popout
                    </Button>
                </Box>
            </Paper>

            <Divider sx={{ my: 4 }} />

            <Typography variant="h5" sx={{ fontWeight: 600, mb: 3 }}>
                Feature Descriptions
            </Typography>

            <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                mb={2}
            >
                <FormControl
                    variant="outlined"
                    size="small"
                    sx={{ minWidth: 150 }}
                >
                    <InputLabel id="sort-features-label">
                        Sort Features
                    </InputLabel>
                    <Select
                        labelId="sort-features-label"
                        value="Alphabetical"
                        onChange={() => {}} // Placeholder for sorting
                        label="Sort Features"
                    >
                        <MenuItem value="Alphabetical">Alphabetical</MenuItem>
                        <MenuItem value="Importance">Importance</MenuItem>
                    </Select>
                </FormControl>
                <Button
                    onClick={() => setShowChatBot && setShowChatBot(true)}
                    variant="contained"
                    startIcon={<LightbulbIcon />}
                    sx={{
                        textTransform: 'none',
                        backgroundColor: '#333',
                        '&:hover': { backgroundColor: '#555' },
                    }}
                >
                    Explain with AI
                </Button>
            </Stack>

            <TableContainer
                component={Paper}
                variant="outlined"
                sx={{ borderRadius: '8px' }}
            >
                <Table size="small" aria-label="feature descriptions table">
                    <TableHead>
                        <TableRow sx={{ bgcolor: 'grey.100' }}>
                            <TableCell sx={{ fontWeight: 'bold' }}>
                                Feature
                            </TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>
                                Type
                            </TableCell>
                            <TableCell sx={{ fontWeight: 'bold' }}>
                                Description
                            </TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {MOCK_TITANIC_SHAP_DATA.map((feature, index) => (
                            <TableRow key={index}>
                                <TableCell>{feature.feature}</TableCell>
                                <TableCell>{feature.type}</TableCell>
                                <TableCell>{feature.description}</TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
        </Box>
    )
}

export default FeatureImportancesDashboard
