/* eslint-disable no-unused-vars */
import React, { useState, useEffect } from 'react'
import {
    Container,
    Grid,
    Paper,
    Typography,
    Box,
    Divider,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Chip,
    Button,
    CircularProgress,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogActions,
    LinearProgress,
    Stack,
} from '@mui/material'
import { TabContext, TabList, TabPanel } from '@mui/lab'
import Tab from '@mui/material/Tab'
import PlayArrowIcon from '@mui/icons-material/PlayArrow'
import AssessmentIcon from '@mui/icons-material/Assessment'
import PreviewIcon from '@mui/icons-material/Preview'
import DownloadIcon from '@mui/icons-material/Download'
import LightbulbIcon from '@mui/icons-material/Lightbulb'
import {
    Radar,
    RadarChart,
    PolarGrid,
    PolarAngleAxis,
    PolarRadiusAxis,
    Legend,
    CartesianGrid,
} from 'recharts'

import {
    BarChart,
    Bar,
    XAxis,
    YAxis,
    Tooltip,
    ResponsiveContainer,
    PieChart,
    Pie,
    Cell,
} from 'recharts'

// --- Mock Data Imports ---
// Assuming these paths are correct relative to where this component is located
import performAnalysisData from '../../mockdata/performanalysis.json' // Corrected import for performanalysis.json
import mitigationStrategiesData from '../../mockdata/mitigation_strategies.json'
import listDatasetsData from '../../mockdata/listdatasets.json'
import previewDatasetData from '../../mockdata/preview_dataset.json' // Added preview_dataset.json import
import {
    Dashboard,
    DocumentScanner,
    Folder,
    InfoOutline,
    Launch,
} from '@mui/icons-material'
import SummaryLoaderPlaceholder from '../../components/SummaryLoaderPlaceholder'
import axios from 'axios'
import { useSelector } from 'react-redux'

// Helper for status color mapping (e.g., for disparity)
const getDisparityColor = (value) => {
    // These thresholds are examples; adjust based on domain knowledge
    if (Math.abs(value) > 0.1) return 'error' // High disparity
    if (Math.abs(value) > 0.03) return 'warning' // Moderate disparity
    return 'success' // Low disparity/good
}

// Helper for improvement percentage color mapping
const getImprovementColor = (percentage) => {
    if (percentage > 5) return 'success' // Significant positive improvement
    if (percentage > 0) return 'info' // Some positive improvement
    if (percentage < 0) return 'error' // Degradation or negative impact
    return 'default' // No change
}

const FairnessDashboard = ({
    setOpenSideBar,
    selectedProject,
    setSelectedProject,
    selectedSensitiveFeature,
}) => {
    const { token, user } = useSelector((state) => state?.auth)
    const projectList = useSelector((state) => state.driftConfig.projectList)
    const { fairnessAnalysis, loading, datasets } = useSelector(
        (state) => state.fairness
    )
    const { features, metrics, llm_analysis_report, overview, plots } =
        fairnessAnalysis || {}

    const [selectedTab, setSelectedTab] = useState('overview')
    const [selectedAttribute, setSelectedAttribute] = useState(
        performAnalysisData?.features?.[0] || 'Age_Group'
    )
    const [selectedTargetColumn, setSelectedTargetColumn] = useState(
        previewDatasetData?.columns?.find((col) =>
            col.includes('Performance')
        ) || 'Performance_Score'
    )
    const [selectedMitigationStrategy, setSelectedMitigationStrategy] =
        useState(
            mitigationStrategiesData?.strategies?.[0]?.value ||
                'exponentiated_gradient'
        )
    const [selectedDataset, setSelectedDataset] = useState(
        listDatasetsData?.files?.[0]?.file_name || 'ref_biased_age.csv'
    )

    const [llmExplanation, setLlmExplanation] = useState('')
    const [isLlmLoading, setIsLlmLoading] = useState(false)
    const [isModalOpen, setIsModalOpen] = useState(false)

    // Extract data for the currently selected sensitive attribute
    const currentAttributeMetrics =
        performAnalysisData?.metrics?.[selectedAttribute] || {}
    const llmAnalysisReport = llm_analysis_report || ''

    // Prepare data for the comparison bar charts (Before vs After Mitigation)
    const prepareChartData = (beforeData, afterData, metricKey) => {
        const data = []
        for (const group in beforeData) {
            data.push({
                name: group,
                'Before Mitigation': beforeData[group][metricKey],
                'After Mitigation': afterData[group][metricKey],
            })
        }
        return data
    }

    const accuracyChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'accuracy_score'
    )
    const selectionRateChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'selection_rate'
    )
    const tprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'tpr'
    )
    const fprChartData = prepareChartData(
        currentAttributeMetrics.group_performance_before,
        currentAttributeMetrics.group_performance_after,
        'fpr'
    )

    const grpWisePerfornameChartData = (data) =>
        Object.entries(data).map(([group, beforeMetrics]) => {
            const afterMetrics =
                metrics[features[0]].group_performance_after?.[group] || {}

            return {
                group,
                'Accuracy (Before)': beforeMetrics.accuracy_score || 0,
                'Accuracy (After)': afterMetrics.accuracy_score || 0,
                'Selection Rate (Before)': beforeMetrics.selection_rate || 0,
                'Selection Rate (After)': afterMetrics.selection_rate || 0,
                'TPR (Before)': beforeMetrics.tpr || 0,
                'TPR (After)': afterMetrics.tpr || 0,
                'FPR (Before)': beforeMetrics.fpr || 0,
                'FPR (After)': afterMetrics.fpr || 0,
            }
        })

    const radarChartData = [
        {
            metric: 'Accuracy',
            Before: accuracyChartData[0]?.['Before Mitigation'] || 0,
            After: accuracyChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'Selection Rate',
            Before: selectionRateChartData[0]?.['Before Mitigation'] || 0,
            After: selectionRateChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'TPR',
            Before: tprChartData[0]?.['Before Mitigation'] || 0,
            After: tprChartData[0]?.['After Mitigation'] || 0,
        },
        {
            metric: 'FPR',
            Before: fprChartData[0]?.['Before Mitigation'] || 0,
            After: fprChartData[0]?.['After Mitigation'] || 0,
        },
    ]

    // Handle LLM explanation
    const handleExplainWithAI = async () => {
        setIsLlmLoading(true)
        setIsModalOpen(true)
        try {
            const prompt = `Analyze the following fairness analysis report and provide a concise, easy-to-understand executive summary, highlighting key biases, their impact, and the overall effectiveness of the mitigation applied. Also, suggest the most appropriate next steps based on the report.
            \n\n${llmAnalysisReport}`

            // Placeholder for API call. In a real application, this would call a backend.
            // For now, it simulates a delay and provides a simplified response.
            await new Promise((resolve) => setTimeout(resolve, 2000)) // Simulate API call delay
            setLlmExplanation(
                `AI-Generated Explanation (Simulated):\n\nBased on the analysis, the model shows significant fairness disparities primarily affecting the '${selectedAttribute}' group, particularly 'Senior' individuals. The 'demographic_parity' and 'equalized_odds' metrics indicate notable bias before mitigation.\n\nWhile the 'exponentiated_gradient' mitigation strategy has shown some positive impact, reducing disparities in metrics like demographic parity and equalized odds by approximately ${Math.abs(((currentAttributeMetrics.overall_fairness_metrics_before?.demographic_parity - currentAttributeMetrics.overall_fairness_metrics_after?.demographic_parity) / currentAttributeMetrics.overall_fairness_metrics_before?.demographic_parity) * 100).toFixed(2) || 0}% and ${Math.abs(((currentAttributeMetrics.overall_fairness_metrics_before?.equalized_odds - currentAttributeMetrics.overall_fairness_metrics_after?.equalized_odds) / currentAttributeMetrics.overall_fairness_metrics_before?.equalized_odds) * 100).toFixed(2) || 0}% respectively, further action is required to achieve full compliance.\n\n**Key Findings:**\n* Accuracy remains lower for the 'Senior' group even after mitigation.\n* Selection rate disparities persist, indicating unequal treatment or opportunity.\n\n**Most Appropriate Next Step:**\nFocus on **Pre-processing techniques** (e.g., Reweighing or Data Augmentation). The persistent accuracy gap suggests fundamental issues in the training data representation. Addressing bias at the data source level is often more effective for significant and lasting improvements. This will help address root causes rather than just symptoms of bias. Additional in-processing or post-processing fine-tuning can follow if needed.`
            )
        } catch (error) {
            console.error('Error calling LLM API:', error)
            setLlmExplanation(
                'An error occurred while fetching the explanation. Please check console for details.'
            )
        } finally {
            setIsLlmLoading(false)
        }
    }

    // Helper to render markdown content
    const renderMarkdown = (markdownText) => {
        let html = markdownText
            // Headings
            .replace(/^### (.*$)/gim, '<h4 class="md-h4">$1</h4>')
            .replace(/^## (.*$)/gim, '<h3 class="md-h3">$1</h3>')
            .replace(/^# (.*$)/gim, '<h2 class="md-h2">$1</h2>')

            // Lists
            .replace(/^\* (.*$)/gim, '<li>$1</li>')
            .replace(/^- (.*$)/gim, '<li>$1</li>')

            // Bold & Italic
            .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/gim, '<em>$1</em>')

            // Inline code
            .replace(/`([^`]+)`/gim, '<code class="md-code-inline">$1</code>')

            // Paragraphs (wrap isolated text blocks)
            .replace(
                /^(?!<h|<ul|<li|<code|<strong|<em|<p|<blockquote)(.+)$/gim,
                '<p class="md-paragraph">$1</p>'
            )

        // Wrap <li> blocks in <ul> only once
        html = html.replace(/(<li>.*?<\/li>)/gims, '<ul class="md-ul">$1</ul>')

        return (
            <div
                className="markdown-container"
                dangerouslySetInnerHTML={{ __html: html }}
            />
        )
    }

    const handleDeleteProject = (projectId) => {
        const confirmDelete = window.confirm(
            'Are you sure you want to delete this project?'
        )
        if (!confirmDelete) return

        // Update state
        const updatedProjects = projectList.filter(
            (p) => p.timestamp !== projectId
        )
    }

    if (loading) return <SummaryLoaderPlaceholder />

    if (!features) {
        return (
            <Container
                maxWidth="xl"
                sx={{
                    mt: 4,
                    mb: 4,
                    fontFamily: 'Inter, sans-serif',
                    '& .MuiPaper-root': {
                        boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
                    },
                }}
            >
                {/* Page Header */}
                <Box sx={{ mb: 4 }}>
                    <Typography
                        variant="h4"
                        sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                    >
                        AI Fairness Analysis Platform
                    </Typography>
                    <Typography
                        variant="body1"
                        sx={{ color: 'text.secondary' }}
                    >
                        Evaluate model performance across different demographic
                        groups to assess fairness and identify potential biases.{' '}
                        <Button
                            // onClick={() => setShowDescription(true)}
                            variant="text"
                            color="primary.dark"
                            sx={{ fontSize: '1rem', padding: 0 }}
                        >
                            Learn More
                            <InfoOutline
                                sx={{
                                    fontSize: '1rem',
                                    ml: '4px',
                                }}
                            />
                        </Button>
                    </Typography>
                </Box>
                <Box>
                    {/* <Typography
                        variant="h6"
                        fontWeight={600}
                        gutterBottom
                        sx={{
                            display: 'flex',
                            flexDirection: 'row',
                            alignItems: 'center',
                        }}
                    >
                        <Folder
                            sx={{
                                color: 'orange',
                                fontSize: '1.5rem',
                                mr: '4px',
                            }}
                        />
                        Browse Projects
                    </Typography>
                    <Typography
                        variant="body2"
                        color="text.secondary"
                        gutterBottom
                    >
                        Select an existing project to view its fairness analysis
                        report, or create a new one to get started.
                    </Typography> */}

                    {datasets && datasets?.fairness?.files?.length > 0 ? (
                        <Box
                            sx={{
                                mt: 2,
                                display: 'flex',
                                flexDirection: 'column',
                                overflowX: 'auto',
                                gap: 2,
                                pb: 1,
                                width: '100%',
                            }}
                        >
                            <Typography>Files</Typography>
                            {datasets?.fairness?.files?.map((project, i) => (
                                <Paper
                                    key={i}
                                    elevation={1}
                                    sx={{
                                        minWidth: 300,
                                        px: 3,
                                        py: 2,
                                        borderRadius: 2,
                                        display: 'flex',
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                        justifyContent: 'space-between',
                                        border: '1px solid #e0e0e0',
                                        position: 'relative',
                                    }}
                                >
                                    <Box
                                        sx={{
                                            display: 'flex',
                                            alignItems: 'center',
                                            gap: 1,
                                        }}
                                    >
                                        <Dashboard
                                            sx={{
                                                color: 'green',
                                                fontSize: '1.6rem',
                                            }}
                                        />
                                        <Typography
                                            variant="subtitle1"
                                            fontWeight={600}
                                        >
                                            {project.file_name}
                                        </Typography>
                                    </Box>

                                    <Box
                                        sx={{
                                            display: 'flex',
                                            justifyContent: 'flex-end',
                                            gap: 1,
                                        }}
                                    >
                                        <Button
                                            variant="outlined"
                                            // onClick={() =>
                                            //     startAnalysisHandler(project)
                                            // }
                                            disabled
                                            sx={{ color: 'primary.dark' }}
                                        >
                                            View Details
                                            <Launch fontSize="small" />
                                        </Button>
                                    </Box>
                                </Paper>
                            ))}
                        </Box>
                    ) : (
                        <Box
                            sx={{
                                border: '1px dashed #ccc',
                                borderRadius: 2,
                                p: 4,
                                mt: 4,
                                textAlign: 'center',
                                backgroundColor: '#fafafa',
                            }}
                        >
                            <Typography
                                variant="subtitle1"
                                fontWeight={500}
                                gutterBottom
                            >
                                No Past Analysis Found
                            </Typography>
                            <Typography
                                variant="body2"
                                color="text.secondary"
                                sx={{ maxWidth: 500, margin: '0 auto' }}
                            >
                                You haven’t created any drift monitoring
                                projects yet. Create one to begin analyzing
                                model stability over time.
                            </Typography>
                            <Button
                                variant="contained"
                                sx={{ mt: 3 }}
                                onClick={() => setOpenSideBar(true)}
                            >
                                Create Analysis
                            </Button>
                        </Box>
                    )}
                </Box>
            </Container>
        )
    }

    return (
        <Container
            maxWidth="xl"
            sx={{
                mt: 4,
                mb: 4,
                fontFamily: 'Inter, sans-serif',
                '& .MuiPaper-root': {
                    boxShadow: '0px 1px 3px rgba(0, 0, 0, 0.1)',
                },
            }}
        >
            {/* Page Header */}
            <Box sx={{ mb: 4 }}>
                <Typography
                    variant="h4"
                    sx={{ fontWeight: 600, mb: 1, color: '#232f3e' }}
                >
                    AI Fairness Analysis Platform
                </Typography>
                <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                    Evaluate model performance across different demographic
                    groups to assess fairness and identify potential biases.{' '}
                    <Button
                        // onClick={() => setShowDescription(true)}
                        variant="text"
                        color="primary.dark"
                        sx={{ fontSize: '1rem', padding: 0 }}
                    >
                        Learn More
                        <InfoOutline
                            sx={{
                                fontSize: '1rem',
                                ml: '4px',
                            }}
                        />
                    </Button>
                </Typography>
            </Box>

            {/* Tabs for Overview, Detailed Metrics, Mitigation */}
            <TabContext value={selectedTab}>
                <Box sx={{ borderBottom: 1, borderColor: '#e0e0e0', mb: 3 }}>
                    <TabList
                        onChange={(e, newValue) => setSelectedTab(newValue)}
                        aria-label="fairness dashboard tabs"
                        sx={{
                            '& .MuiTab-root': {
                                textTransform: 'none',
                                fontWeight: 600,
                                color: '#545b64',
                                '&.Mui-selected': {
                                    color: '#232f3e',
                                    borderBottom: '2px solid #ff9900', // AWS orange highlight
                                },
                            },
                            '& .MuiTabs-indicator': {
                                backgroundColor: 'transparent', // Hide default indicator
                            },
                        }}
                    >
                        <Tab label="Overview" value="overview" />
                        <Tab
                            label="Detailed Metrics"
                            value="detailed_metrics"
                        />
                        <Tab label="Mitigation Strategies" value="mitigation" />
                    </TabList>
                </Box>

                {/* Overview Tab Content */}
                <TabPanel value="overview" sx={{ p: 0 }}>
                    <Grid container spacing={3}>
                        {/* Mitigation Strategy Used*/}
                        <Grid item xs={12} width="100%">
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h5"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Mitigation Strategy Used
                                </Typography>
                                <Typography
                                    variant="body1"
                                    sx={{
                                        textTransform: 'capitalize',
                                        color: '#5f6368',
                                        fontWeight: 500,
                                        fontSize: '1.1rem',
                                    }}
                                >
                                    {overview?.mitigation_strategy_used ||
                                        'N/A'}
                                </Typography>
                            </Paper>
                        </Grid>

                        {/* Fairness Scores Container */}
                        <Grid container spacing={3} width="100%">
                            {/* Fairness Score After Mitigation */}
                            <Grid item xs={12} flex={1}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        height: '100%',
                                        border: '1px solid #e0e0e0',
                                    }}
                                >
                                    <Typography
                                        variant="h5"
                                        sx={{
                                            mb: 2,
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        Fairness Score After Mitigation
                                    </Typography>
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} sm={6}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Score
                                            </Typography>
                                            <Typography
                                                variant="h4"
                                                sx={{
                                                    color:
                                                        overview
                                                            ?.fairness_score_after
                                                            ?.color ||
                                                        '#1a73e8',
                                                    fontWeight: 'bold',
                                                }}
                                            >
                                                {overview?.fairness_score_after?.score?.toFixed(
                                                    1
                                                ) || 'N/A'}
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12} sm={6}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Grade
                                            </Typography>
                                            <Typography
                                                variant="h4"
                                                sx={{
                                                    color:
                                                        overview
                                                            ?.fairness_score_after
                                                            ?.color ||
                                                        '#1a73e8',
                                                    fontWeight: 'bold',
                                                }}
                                            >
                                                {overview?.fairness_score_after
                                                    ?.grade || 'N/A'}
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Assessment
                                            </Typography>
                                            <Typography
                                                variant="body2"
                                                sx={{
                                                    color: '#5f6368',
                                                    lineHeight: 1.5,
                                                }}
                                            >
                                                {overview?.fairness_score_after
                                                    ?.description || 'N/A'}
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Improvement Potential
                                            </Typography>
                                            <Typography
                                                variant="h6"
                                                sx={{
                                                    color: '#1a73e8',
                                                    fontWeight: 600,
                                                }}
                                            >
                                                {overview?.fairness_score_after?.improvement_potential?.toFixed(
                                                    1
                                                ) || 'N/A'}
                                                %
                                            </Typography>
                                        </Grid>
                                    </Grid>
                                </Paper>
                            </Grid>

                            {/* Fairness Score Before Mitigation */}
                            <Grid item xs={12} flex={1}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        height: '100%',
                                        border: '1px solid #e0e0e0',
                                    }}
                                >
                                    <Typography
                                        variant="h5"
                                        sx={{
                                            mb: 2,
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        Fairness Score Before Mitigation
                                    </Typography>
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} sm={6}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Score
                                            </Typography>
                                            <Typography
                                                variant="h4"
                                                sx={{
                                                    color:
                                                        overview
                                                            ?.fairness_score_before
                                                            ?.color ||
                                                        '#d32f2f',
                                                    fontWeight: 'bold',
                                                }}
                                            >
                                                {overview?.fairness_score_before?.score?.toFixed(
                                                    1
                                                ) || 'N/A'}
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12} sm={6}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Grade
                                            </Typography>
                                            <Typography
                                                variant="h4"
                                                sx={{
                                                    color:
                                                        overview
                                                            ?.fairness_score_before
                                                            ?.color ||
                                                        '#d32f2f',
                                                    fontWeight: 'bold',
                                                }}
                                            >
                                                {overview?.fairness_score_before
                                                    ?.grade || 'N/A'}
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Assessment
                                            </Typography>
                                            <Typography
                                                variant="body2"
                                                sx={{
                                                    color: '#5f6368',
                                                    lineHeight: 1.5,
                                                }}
                                            >
                                                {overview?.fairness_score_before
                                                    ?.description || 'N/A'}
                                            </Typography>
                                        </Grid>
                                        <Grid item xs={12}>
                                            <Typography
                                                variant="subtitle2"
                                                color="text.secondary"
                                                sx={{ mb: 0.5 }}
                                            >
                                                Improvement Potential
                                            </Typography>
                                            <Typography
                                                variant="h6"
                                                sx={{
                                                    color: '#1a73e8',
                                                    fontWeight: 600,
                                                }}
                                            >
                                                {overview?.fairness_score_before?.improvement_potential?.toFixed(
                                                    1
                                                ) || 'N/A'}
                                                %
                                            </Typography>
                                        </Grid>
                                    </Grid>
                                </Paper>
                            </Grid>
                        </Grid>

                        {/* LLM Analysis Report */}
                        <Grid item xs={12} width="100%">
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        justifyContent: 'space-between',
                                        alignItems: 'center',
                                        mb: 2,
                                    }}
                                >
                                    <Typography
                                        variant="h5"
                                        sx={{
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        Detailed Analysis Report
                                    </Typography>
                                    {/* <Button
                                        variant="outlined"
                                        startIcon={<LightbulbIcon />}
                                        onClick={handleExplainWithAI}
                                        disabled={isLlmLoading}
                                        sx={{
                                            borderColor: 'primary.dark',
                                            color: 'primary.dark',
                                            '&:hover': {
                                                backgroundColor: 'primary.dark',
                                                borderColor: 'primary.dark',
                                            },
                                        }}
                                    >
                                        Explain with AI
                                    </Button> */}
                                    <Button
                                        variant="contained"
                                        startIcon={<LightbulbIcon />}
                                        onClick={handleExplainWithAI}
                                        disabled={isLlmLoading}
                                        sx={{
                                            textTransform: 'none',
                                            backgroundColor: '#333',
                                            '&:hover': {
                                                backgroundColor: '#555',
                                            },
                                        }}
                                    >
                                        Explain with AI
                                    </Button>
                                </Box>
                                <Divider
                                    sx={{ mb: 2, borderColor: '#f0f2f2' }}
                                />
                                {renderMarkdown(llmAnalysisReport)}
                            </Paper>
                        </Grid>

                        {/* Bias Detection Summary */}
                        <Grid item xs={12} md={6} width="100%">
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h5"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Bias Detection Summary (
                                    {features?.join(',')})
                                </Typography>
                                <Divider
                                    sx={{ mb: 2, borderColor: '#f0f2f2' }}
                                />
                                {features &&
                                features.length > 0 &&
                                metrics[features[0]]?.biasDetected?.length >
                                    0 ? (
                                    <Box sx={{ color: '#d32f2f' }}>
                                        <Typography
                                            variant="body1"
                                            sx={{ fontWeight: 'bold', mb: 1 }}
                                        >
                                            Significant Bias Detected!
                                        </Typography>
                                        <Typography
                                            variant="body2"
                                            sx={{ mb: 1 }}
                                        >
                                            The model exhibits bias in the{' '}
                                            <strong>{features[0]}</strong>{' '}
                                            feature, impacting fairness across
                                            groups. The following metrics
                                            indicate a deviation from fairness
                                            thresholds:
                                        </Typography>
                                        <ul
                                            style={{
                                                paddingLeft: '20px',
                                                margin: 0,
                                                listStyleType: 'disc',
                                            }}
                                        >
                                            {metrics[
                                                features[0]
                                            ]?.biasDetected.map(
                                                (bias, index) => (
                                                    <li key={index}>
                                                        <Typography variant="body2">
                                                            {bias.replace(
                                                                /_/g,
                                                                ' '
                                                            )}
                                                        </Typography>
                                                    </li>
                                                )
                                            )}
                                        </ul>
                                    </Box>
                                ) : (
                                    <Typography variant="body1" color="#388e3c">
                                        No significant biases detected for{' '}
                                        {selectedAttribute}.
                                    </Typography>
                                )}
                            </Paper>
                        </Grid>

                        {/* Compliance Status */}
                        {/* <Grid item xs={12} md={6} width="100%">
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h5"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Compliance Status ({features?.join(',')})
                                </Typography>
                                <Divider
                                    sx={{ mb: 2, borderColor: '#f0f2f2' }}
                                />
                                <Box sx={{ color: '#d32f2f' }}>
                                    <Typography
                                        variant="body1"
                                        sx={{ fontWeight: 'bold', mb: 1 }}
                                    >
                                        Compliance Failure:
                                    </Typography>
                                    <Typography variant="body2">
                                        The <strong>{selectedAttribute}</strong>{' '}
                                        group fails several key compliance
                                        rules, indicating potential legal or
                                        ethical concerns:
                                    </Typography>
                                    <ul
                                        style={{
                                            paddingLeft: '20px',
                                            margin: 0,
                                            listStyleType: 'disc',
                                        }}
                                    >
                                        <li>
                                            <Typography variant="body2">
                                                Four Fifths Rule
                                            </Typography>
                                        </li>
                                        <li>
                                            <Typography variant="body2">
                                                Demographic Parity Threshold
                                            </Typography>
                                        </li>
                                        <li>
                                            <Typography variant="body2">
                                                Equalized Odds Threshold
                                            </Typography>
                                        </li>
                                    </ul>
                                    <Typography
                                        variant="caption"
                                        display="block"
                                        sx={{ mt: 1, color: 'text.secondary' }}
                                    >
                                        Further investigation and mitigation
                                        efforts are highly recommended.
                                    </Typography>
                                </Box>
                            </Paper>
                        </Grid> */}
                    </Grid>
                </TabPanel>

                {/* Detailed Metrics Tab Content */}
                <TabPanel value="detailed_metrics" sx={{ p: 0 }}>
                    <Grid container spacing={3}>
                        {/* Performance Metrics Bar Charts */}
                        <Grid container spacing={3} width="100%">
                            <Grid item xs={12} flex={1}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        height: '100%',
                                        border: '1px solid #e0e0e0',
                                    }}
                                >
                                    <Typography
                                        variant="h6"
                                        sx={{
                                            mb: 2,
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        Overall Fairness Metrics Comparison by{' '}
                                        {features[0]}
                                    </Typography>

                                    <ResponsiveContainer
                                        width="100%"
                                        height={400}
                                    >
                                        <RadarChart data={radarChartData}>
                                            <PolarGrid />
                                            <PolarAngleAxis dataKey="metric" />
                                            <PolarRadiusAxis
                                                angle={30}
                                                domain={[0, 1]}
                                                tickFormatter={(tick) =>
                                                    `${(tick * 100).toFixed(0)}%`
                                                }
                                            />
                                            <Tooltip
                                                formatter={(val) =>
                                                    `${(val * 100).toFixed(2)}%`
                                                }
                                            />
                                            <Legend />
                                            <Radar
                                                name="Before Mitigation"
                                                dataKey="Before"
                                                stroke="#8884d8"
                                                fill="#8884d8"
                                                fillOpacity={0.6}
                                            />
                                            <Radar
                                                name="After Mitigation"
                                                dataKey="After"
                                                stroke="#82ca9d"
                                                fill="#82ca9d"
                                                fillOpacity={0.6}
                                            />
                                        </RadarChart>
                                    </ResponsiveContainer>
                                </Paper>
                            </Grid>
                            <Grid item xs={12} flex={1}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        height: '100%',
                                        border: '1px solid #e0e0e0',
                                    }}
                                >
                                    <Typography
                                        variant="h5"
                                        sx={{
                                            mb: 2,
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        Group-wise Fairness Metrics (
                                        {selectedAttribute})
                                    </Typography>

                                    <ResponsiveContainer
                                        width="100%"
                                        height={400}
                                    >
                                        <BarChart
                                            data={grpWisePerfornameChartData(
                                                metrics[features[0]]
                                                    ?.group_performance_before
                                            )}
                                            margin={{
                                                top: 20,
                                                right: 20,
                                                left: 0,
                                                bottom: 60,
                                            }}
                                        >
                                            <CartesianGrid strokeDasharray="3 3" />
                                            <XAxis
                                                dataKey="group"
                                                angle={-45}
                                                textAnchor="end"
                                                height={80}
                                            />
                                            <YAxis
                                                domain={[0, 1]}
                                                tickFormatter={(tick) =>
                                                    `${(tick * 100).toFixed(0)}%`
                                                }
                                            />
                                            <Tooltip
                                                formatter={(value) =>
                                                    `${(value * 100).toFixed(2)}%`
                                                }
                                            />
                                            <Legend
                                                wrapperStyle={{
                                                    paddingTop: '10px',
                                                }}
                                            />
                                            {/* Bars for each metric */}
                                            <Bar
                                                dataKey="Accuracy (Before)"
                                                fill="#3f51b5"
                                            />
                                            <Bar
                                                dataKey="Accuracy (After)"
                                                fill="#7986cb"
                                            />
                                            <Bar
                                                dataKey="Selection Rate (Before)"
                                                fill="#ff9800"
                                            />
                                            <Bar
                                                dataKey="Selection Rate (After)"
                                                fill="#ffb74d"
                                            />
                                            <Bar
                                                dataKey="TPR (Before)"
                                                fill="#673ab7"
                                            />
                                            <Bar
                                                dataKey="TPR (After)"
                                                fill="#9575cd"
                                            />
                                            <Bar
                                                dataKey="FPR (Before)"
                                                fill="#f44336"
                                            />
                                            <Bar
                                                dataKey="FPR (After)"
                                                fill="#e57373"
                                            />
                                        </BarChart>
                                    </ResponsiveContainer>
                                </Paper>
                            </Grid>
                        </Grid>
                        {/* Overall Fairness Metrics Table */}
                        <Grid item xs={12} sx={{ width: '100%' }}>
                            <Paper
                                elevation={0}
                                sx={{
                                    p: 3,
                                    borderRadius: '8px',
                                    height: '100%',
                                    border: '1px solid #e0e0e0',
                                }}
                            >
                                <Typography
                                    variant="h5"
                                    sx={{
                                        mb: 2,
                                        fontWeight: 600,
                                        color: '#232f3e',
                                    }}
                                >
                                    Overall Fairness Metrics Comparison
                                </Typography>
                                <TableContainer
                                    sx={{
                                        border: '1px solid #e0e0e0',
                                        borderRadius: '8px',
                                        overflow: 'hidden',
                                    }}
                                >
                                    <Table size="medium">
                                        <TableHead
                                            sx={{ backgroundColor: '#fafafa' }}
                                        >
                                            <TableRow>
                                                <TableCell
                                                    sx={{
                                                        fontWeight: 'bold',
                                                        color: '#232f3e',
                                                    }}
                                                >
                                                    Metric
                                                </TableCell>
                                                <TableCell
                                                    align="right"
                                                    sx={{
                                                        fontWeight: 'bold',
                                                        color: '#232f3e',
                                                    }}
                                                >
                                                    Before Mitigation
                                                </TableCell>
                                                <TableCell
                                                    align="right"
                                                    sx={{
                                                        fontWeight: 'bold',
                                                        color: '#232f3e',
                                                    }}
                                                >
                                                    After Mitigation
                                                </TableCell>
                                                <TableCell
                                                    align="right"
                                                    sx={{
                                                        fontWeight: 'bold',
                                                        color: '#232f3e',
                                                    }}
                                                >
                                                    Improvement (%)
                                                </TableCell>
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {Object.entries(
                                                metrics[features[0]]
                                                    ?.fairness_metrics_before ||
                                                    {}
                                            ).map(([metric, value]) => {
                                                const afterValue =
                                                    metrics[features[0]]
                                                        ?.fairness_metrics_after?.[
                                                        metric
                                                    ]
                                                const improvement =
                                                    value !== 0 &&
                                                    afterValue !== undefined
                                                        ? (
                                                              ((value -
                                                                  afterValue) /
                                                                  value) *
                                                              100
                                                          ).toFixed(2)
                                                        : 'N/A'
                                                return (
                                                    <TableRow
                                                        key={metric}
                                                        sx={{
                                                            '&:nth-of-type(odd)':
                                                                {
                                                                    backgroundColor:
                                                                        '#fdfdfd',
                                                                },
                                                            '&:last-child td, &:last-child th':
                                                                {
                                                                    borderBottom: 0,
                                                                },
                                                        }}
                                                    >
                                                        <TableCell
                                                            component="th"
                                                            scope="row"
                                                        >
                                                            {metric.replace(
                                                                /_/g,
                                                                ' '
                                                            )}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            {value?.toFixed(
                                                                4
                                                            ) || 'N/A'}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            {afterValue?.toFixed(
                                                                4
                                                            ) || 'N/A'}
                                                        </TableCell>
                                                        <TableCell align="right">
                                                            <Chip
                                                                label={
                                                                    improvement !==
                                                                    'N/A'
                                                                        ? `${improvement}%`
                                                                        : 'N/A'
                                                                }
                                                                color={
                                                                    improvement !==
                                                                    'N/A'
                                                                        ? getImprovementColor(
                                                                              parseFloat(
                                                                                  improvement
                                                                              )
                                                                          )
                                                                        : 'default'
                                                                }
                                                                size="small"
                                                                sx={{
                                                                    minWidth:
                                                                        '70px',
                                                                }}
                                                            />
                                                        </TableCell>
                                                    </TableRow>
                                                )
                                            })}
                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                        </Grid>
                        <Grid container spacing={3} width="100%">
                            <Grid item xs={12} md={6} flex={1}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        height: '100%',
                                        border: '1px solid #e0e0e0',
                                    }}
                                >
                                    <Typography
                                        variant="h6"
                                        sx={{
                                            mb: 2,
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        True Positive Rate (TPR) by{' '}
                                        {features[0]}
                                    </Typography>
                                    <ResponsiveContainer
                                        width="100%"
                                        height={250}
                                    >
                                        <BarChart data={tprChartData}>
                                            <XAxis
                                                dataKey="name"
                                                axisLine={false}
                                                tickLine={false}
                                            />
                                            <YAxis
                                                domain={[0, 1]}
                                                tickFormatter={(tick) =>
                                                    (tick * 100).toFixed(0) +
                                                    '%'
                                                }
                                            />
                                            <Tooltip
                                                formatter={(value) =>
                                                    (value * 100).toFixed(2) +
                                                    '%'
                                                }
                                            />
                                            <Legend
                                                wrapperStyle={{
                                                    paddingTop: '10px',
                                                }}
                                            />
                                            <Bar
                                                dataKey="Before Mitigation"
                                                fill="#673ab7"
                                                radius={[4, 4, 0, 0]}
                                            />{' '}
                                            {/* Deep Purple */}
                                            <Bar
                                                dataKey="After Mitigation"
                                                fill="#00bcd4"
                                                radius={[4, 4, 0, 0]}
                                            />{' '}
                                            {/* Cyan */}
                                        </BarChart>
                                    </ResponsiveContainer>
                                </Paper>
                            </Grid>
                            <Grid item xs={12} md={6} flex={1}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        p: 3,
                                        borderRadius: '8px',
                                        height: '100%',
                                        border: '1px solid #e0e0e0',
                                    }}
                                >
                                    <Typography
                                        variant="h6"
                                        sx={{
                                            mb: 2,
                                            fontWeight: 600,
                                            color: '#232f3e',
                                        }}
                                    >
                                        False Positive Rate (FPR) by{' '}
                                        {features[0]}
                                    </Typography>
                                    <ResponsiveContainer
                                        width="100%"
                                        height={250}
                                    >
                                        <BarChart data={fprChartData}>
                                            <XAxis
                                                dataKey="name"
                                                axisLine={false}
                                                tickLine={false}
                                            />
                                            <YAxis
                                                domain={[0, 1]}
                                                tickFormatter={(tick) =>
                                                    (tick * 100).toFixed(0) +
                                                    '%'
                                                }
                                            />
                                            <Tooltip
                                                formatter={(value) =>
                                                    (value * 100).toFixed(2) +
                                                    '%'
                                                }
                                            />
                                            <Legend
                                                wrapperStyle={{
                                                    paddingTop: '10px',
                                                }}
                                            />
                                            <Bar
                                                dataKey="Before Mitigation"
                                                fill="#795548"
                                                radius={[4, 4, 0, 0]}
                                            />{' '}
                                            {/* Brown */}
                                            <Bar
                                                dataKey="After Mitigation"
                                                fill="#607d8b"
                                                radius={[4, 4, 0, 0]}
                                            />{' '}
                                            {/* Blue Grey */}
                                        </BarChart>
                                    </ResponsiveContainer>
                                </Paper>
                            </Grid>
                        </Grid>

                        {/* Plots (Images) */}
                        <Grid container spacing={3} width="100%">
                            {plots?.before_mitigation?.accuracy_plot && (
                                <Grid item xs={12} md={6} flex={1}>
                                    <Paper
                                        elevation={0}
                                        sx={{
                                            p: 3,
                                            borderRadius: '8px',
                                            height: '100%',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            border: '1px solid #e0e0e0',
                                        }}
                                    >
                                        <Typography
                                            variant="h6"
                                            sx={{
                                                mb: 2,
                                                fontWeight: 600,
                                                color: '#232f3e',
                                            }}
                                        >
                                            Accuracy Plot (Before Mitigation)
                                        </Typography>
                                        <img
                                            src={`data:image/png;base64,${plots.before_mitigation.accuracy_plot}`}
                                            alt="Accuracy Plot Before Mitigation"
                                            style={{
                                                maxWidth: '100%',
                                                height: 'auto',
                                                borderRadius: '4px',
                                                border: '1px solid #ddd',
                                            }}
                                        />
                                    </Paper>
                                </Grid>
                            )}
                            {plots?.after_mitigation?.accuracy_plot && (
                                <Grid item xs={12} md={6} flex={1}>
                                    <Paper
                                        elevation={0}
                                        sx={{
                                            p: 3,
                                            borderRadius: '8px',
                                            height: '100%',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            border: '1px solid #e0e0e0',
                                        }}
                                    >
                                        <Typography
                                            variant="h6"
                                            sx={{
                                                mb: 2,
                                                fontWeight: 600,
                                                color: '#232f3e',
                                            }}
                                        >
                                            Accuracy Plot (After Mitigation)
                                        </Typography>
                                        <img
                                            src={`data:image/png;base64,${plots.after_mitigation.accuracy_plot}`}
                                            alt="Accuracy Plot After Mitigation"
                                            style={{
                                                maxWidth: '100%',
                                                height: 'auto',
                                                borderRadius: '4px',
                                                border: '1px solid #ddd',
                                            }}
                                        />
                                    </Paper>
                                </Grid>
                            )}
                        </Grid>
                        <Grid container spacing={3} width="100%">
                            {' '}
                            {plots?.before_mitigation?.selection_rate_plot && (
                                <Grid item xs={12} md={6} flex={1}>
                                    <Paper
                                        elevation={0}
                                        sx={{
                                            p: 3,
                                            borderRadius: '8px',
                                            height: '100%',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            border: '1px solid #e0e0e0',
                                        }}
                                    >
                                        <Typography
                                            variant="h6"
                                            sx={{
                                                mb: 2,
                                                fontWeight: 600,
                                                color: '#232f3e',
                                            }}
                                        >
                                            Selection Rate Plot (Before
                                            Mitigation)
                                        </Typography>
                                        <img
                                            src={`data:image/png;base64,${plots.before_mitigation.selection_rate_plot}`}
                                            alt="Selection Rate Plot Before Mitigation"
                                            style={{
                                                maxWidth: '100%',
                                                height: 'auto',
                                                borderRadius: '4px',
                                                border: '1px solid #ddd',
                                            }}
                                        />
                                    </Paper>
                                </Grid>
                            )}
                            {plots?.after_mitigation?.selection_rate_plot && (
                                <Grid item xs={12} md={6} flex={1}>
                                    <Paper
                                        elevation={0}
                                        sx={{
                                            p: 3,
                                            borderRadius: '8px',
                                            height: '100%',
                                            display: 'flex',
                                            flexDirection: 'column',
                                            alignItems: 'center',
                                            border: '1px solid #e0e0e0',
                                        }}
                                    >
                                        <Typography
                                            variant="h6"
                                            sx={{
                                                mb: 2,
                                                fontWeight: 600,
                                                color: '#232f3e',
                                            }}
                                        >
                                            Selection Rate Plot (After
                                            Mitigation)
                                        </Typography>
                                        <img
                                            src={`data:image/png;base64,${plots.after_mitigation.selection_rate_plot}`}
                                            alt="Selection Rate Plot After Mitigation"
                                            style={{
                                                maxWidth: '100%',
                                                height: 'auto',
                                                borderRadius: '4px',
                                                border: '1px solid #ddd',
                                            }}
                                        />
                                    </Paper>
                                </Grid>
                            )}
                        </Grid>
                    </Grid>
                </TabPanel>

                {/* Mitigation Tab Content */}
                <TabPanel value="mitigation" sx={{ p: 0 }}>
                    <Grid container spacing={3}>
                        {/* Bias Mitigation Strategies */}
                        <Grid item xs={12} width="100%">
                            <Paper
                                elevation={1}
                                sx={{
                                    p: 3,
                                    borderRadius: 3,
                                    boxShadow: '0 2px 8px rgba(0,0,0,0.06)',
                                    backgroundColor: '#fff',
                                    border: '1px solid #f1f3f5',
                                }}
                            >
                                <Typography
                                    variant="h6"
                                    fontWeight={700}
                                    sx={{ mb: 1.5, color: '#1a1a1a' }}
                                >
                                    Bias Mitigation Strategies Overview
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{ mb: 3 }}
                                >
                                    Techniques applied at different stages to
                                    reduce algorithmic bias.
                                </Typography>
                                <Grid container spacing={4}>
                                    {[
                                        {
                                            title: 'Pre-processing Techniques',
                                            items: [
                                                {
                                                    label: 'Reweighing samples',
                                                    status: 'Implemented',
                                                },
                                                {
                                                    label: 'Disparate impact remover',
                                                    status: 'Implemented',
                                                },
                                                {
                                                    label: 'Data augmentation',
                                                    status: 'Implemented',
                                                },
                                            ],
                                            color: '#388e3c',
                                            bg: '#e8f5e9',
                                            border: '#c8e6c9',
                                        },
                                        {
                                            title: 'In-processing Techniques',
                                            items: [
                                                {
                                                    label: 'Fairness constraints',
                                                    status: 'Under Review',
                                                },
                                                {
                                                    label: 'Adversarial debiasing',
                                                    status: 'Under Review',
                                                },
                                                {
                                                    label: 'Fair representation learning',
                                                    status: 'Under Review',
                                                },
                                            ],
                                            color: '#0277bd',
                                            bg: '#e1f5fe',
                                            border: '#b3e5fc',
                                        },
                                        {
                                            title: 'Post-processing Techniques',
                                            items: [
                                                {
                                                    label: 'Threshold optimization',
                                                    status: 'Implemented',
                                                },
                                                {
                                                    label: 'Calibrated equalized odds',
                                                    status: 'Implemented',
                                                },
                                                {
                                                    label: 'Output modification',
                                                    status: 'Implemented',
                                                },
                                            ],
                                            color: '#388e3c',
                                            bg: '#e8f5e9',
                                            border: '#c8e6c9',
                                        },
                                    ].map((section, index) => (
                                        <Grid
                                            item
                                            xs={12}
                                            md={4}
                                            key={index}
                                            sx={{
                                                flex: 1,
                                                border: '2px dotted grey',
                                                padding: '1rem',
                                                borderRadius: '8px',
                                            }}
                                        >
                                            <Typography
                                                variant="subtitle1"
                                                fontWeight={600}
                                                gutterBottom
                                            >
                                                {section.title}
                                            </Typography>
                                            <Stack spacing={1}>
                                                {section.items.map(
                                                    (item, idx) => (
                                                        <Stack
                                                            key={idx}
                                                            direction="row"
                                                            alignItems="center"
                                                            spacing={1}
                                                            sx={{
                                                                display: 'flex',
                                                                flexDirection:
                                                                    'row',
                                                                justifyContent:
                                                                    'space-between',
                                                            }}
                                                        >
                                                            <Typography variant="body2">
                                                                {item.label}
                                                            </Typography>
                                                            <Chip
                                                                label={
                                                                    item.status
                                                                }
                                                                size="small"
                                                                variant="outlined"
                                                                sx={{
                                                                    fontSize:
                                                                        '0.75rem',
                                                                    color: section.color,
                                                                    backgroundColor:
                                                                        section.bg,
                                                                    borderColor:
                                                                        section.border,
                                                                    fontWeight: 500,
                                                                }}
                                                            />
                                                        </Stack>
                                                    )
                                                )}
                                            </Stack>
                                        </Grid>
                                    ))}
                                </Grid>
                            </Paper>
                        </Grid>

                        {/* Fairness Metrics Table and Recommendations Side by Side */}
                        <Grid item xs={12} sx={{ width: '100%' }}>
                            <Grid container spacing={3}>
                                {/* Table */}
                                <Grid item xs={12} md={6} flex={1}>
                                    <Paper
                                        elevation={1}
                                        sx={{
                                            p: 3,
                                            borderRadius: 3,
                                            boxShadow:
                                                '0 2px 8px rgba(0,0,0,0.06)',
                                            backgroundColor: '#fff',
                                            border: '1px solid #f1f3f5',
                                            height: '100%',
                                        }}
                                    >
                                        <Typography
                                            variant="h6"
                                            fontWeight={700}
                                            sx={{ mb: 1.5, color: '#1a1a1a' }}
                                        >
                                            Impact of Mitigation on Overall
                                            Fairness Metrics
                                        </Typography>
                                        <TableContainer>
                                            <Table size="medium">
                                                <TableHead
                                                    sx={{
                                                        backgroundColor:
                                                            '#f9f9f9',
                                                    }}
                                                >
                                                    <TableRow>
                                                        {[
                                                            'Metric',
                                                            'Before',
                                                            'After',
                                                            'Improvement (%)',
                                                        ].map((head, idx) => (
                                                            <TableCell
                                                                key={idx}
                                                                sx={{
                                                                    fontWeight: 600,
                                                                }}
                                                            >
                                                                {head}
                                                            </TableCell>
                                                        ))}
                                                    </TableRow>
                                                </TableHead>
                                                <TableBody>
                                                    {Object.entries(
                                                        metrics[features[0]]
                                                            ?.fairness_metrics_before ||
                                                            {}
                                                    ).map(([metric, value]) => {
                                                        const after =
                                                            metrics[features[0]]
                                                                ?.fairness_metrics_after?.[
                                                                metric
                                                            ]
                                                        const improvement =
                                                            value !== 0 &&
                                                            after !== undefined
                                                                ? (
                                                                      ((value -
                                                                          after) /
                                                                          value) *
                                                                      100
                                                                  ).toFixed(2)
                                                                : 'N/A'
                                                        const isPositive =
                                                            improvement !==
                                                                'N/A' &&
                                                            parseFloat(
                                                                improvement
                                                            ) > 0

                                                        return (
                                                            <TableRow
                                                                key={metric}
                                                                hover
                                                            >
                                                                <TableCell>
                                                                    {metric.replace(
                                                                        /_/g,
                                                                        ' '
                                                                    )}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    {value?.toFixed(
                                                                        4
                                                                    )}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    {after?.toFixed(
                                                                        4
                                                                    )}
                                                                </TableCell>
                                                                <TableCell align="right">
                                                                    <Chip
                                                                        label={`${improvement}%`}
                                                                        size="small"
                                                                        sx={{
                                                                            color: isPositive
                                                                                ? '#2e7d32'
                                                                                : '#c62828',
                                                                            backgroundColor:
                                                                                isPositive
                                                                                    ? '#e8f5e9'
                                                                                    : '#ffebee',
                                                                            fontWeight: 600,
                                                                            fontSize:
                                                                                '0.75rem',
                                                                        }}
                                                                    />
                                                                </TableCell>
                                                            </TableRow>
                                                        )
                                                    })}
                                                </TableBody>
                                            </Table>
                                        </TableContainer>
                                    </Paper>
                                </Grid>

                                {/* Recommendations */}
                                <Grid item xs={12} md={6} flex={1}>
                                    <Paper
                                        elevation={1}
                                        sx={{
                                            p: 3,
                                            borderRadius: 3,
                                            boxShadow:
                                                '0 2px 8px rgba(0,0,0,0.06)',
                                            backgroundColor: '#fff',
                                            border: '1px solid #f1f3f5',
                                            height: '100%',
                                        }}
                                    >
                                        <Typography
                                            variant="h6"
                                            fontWeight={700}
                                            sx={{ mb: 1.5, color: '#1a1a1a' }}
                                        >
                                            Recommended Strategies Based on
                                            Analysis
                                        </Typography>

                                        {metrics[features[0]]?.recommendations
                                            ?.length > 0 ? (
                                            <Stack spacing={3}>
                                                {metrics[
                                                    features[0]
                                                ].recommendations.map(
                                                    (rec, index) => (
                                                        <Box key={index}>
                                                            <Typography
                                                                variant="subtitle2"
                                                                fontWeight={600}
                                                            >
                                                                Affected Metric:{' '}
                                                                <Chip
                                                                    label={rec.metric.replace(
                                                                        /_/g,
                                                                        ' '
                                                                    )}
                                                                    size="small"
                                                                    sx={{
                                                                        ml: 1,
                                                                        backgroundColor:
                                                                            '#eceff1',
                                                                        fontWeight: 500,
                                                                    }}
                                                                />
                                                            </Typography>
                                                            <Typography
                                                                variant="body2"
                                                                color="text.secondary"
                                                                sx={{ mt: 0.5 }}
                                                            >
                                                                <strong>
                                                                    Issue
                                                                    Identified:
                                                                </strong>{' '}
                                                                {rec.issue}
                                                            </Typography>
                                                            <Typography
                                                                variant="body2"
                                                                fontWeight={600}
                                                                sx={{ mt: 1 }}
                                                            >
                                                                Suggested
                                                                Strategies:
                                                            </Typography>
                                                            <ul
                                                                style={{
                                                                    paddingLeft:
                                                                        '20px',
                                                                    margin: 0,
                                                                }}
                                                            >
                                                                {rec.strategies.map(
                                                                    (
                                                                        strategy,
                                                                        sIndex
                                                                    ) => (
                                                                        <li
                                                                            key={
                                                                                sIndex
                                                                            }
                                                                        >
                                                                            <Typography variant="body2">
                                                                                {
                                                                                    strategy
                                                                                }
                                                                            </Typography>
                                                                        </li>
                                                                    )
                                                                )}
                                                            </ul>
                                                        </Box>
                                                    )
                                                )}
                                            </Stack>
                                        ) : (
                                            <Typography
                                                variant="body2"
                                                color="text.secondary"
                                            >
                                                No specific recommendations
                                                available based on current
                                                analysis.
                                            </Typography>
                                        )}
                                    </Paper>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Grid>
                </TabPanel>
            </TabContext>

            {/* LLM Explanation Modal */}
            <Dialog
                open={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                maxWidth="md"
                fullWidth
                PaperProps={{
                    sx: { borderRadius: '8px', border: '1px solid #e0e0e0' },
                }}
            >
                <DialogTitle
                    sx={{
                        pb: 1,
                        backgroundColor: '#fdfdfd',
                        borderBottom: '1px solid #e0e0e0',
                        color: '#232f3e',
                        fontWeight: 600,
                    }}
                >
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <LightbulbIcon sx={{ mr: 1, color: '#ff9900' }} />
                        AI Explanation
                    </Box>
                </DialogTitle>
                <DialogContent dividers sx={{ p: 3 }}>
                    {isLlmLoading ? (
                        <Box
                            sx={{
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'center',
                                alignItems: 'center',
                                minHeight: 200,
                            }}
                        >
                            <CircularProgress
                                sx={{ mb: 2, color: '#ff9900' }}
                            />
                            <Typography variant="body1" color="text.secondary">
                                Generating explanation, please wait...
                            </Typography>
                            <LinearProgress
                                sx={{ width: '80%', mt: 3, color: '#ff9900' }}
                            />
                        </Box>
                    ) : (
                        <Typography
                            component="div"
                            sx={{
                                whiteSpace: 'pre-wrap',
                                fontSize: '0.9rem',
                                color: '#232f3e',
                            }}
                        >
                            {renderMarkdown(llmExplanation)}
                        </Typography>
                    )}
                </DialogContent>
                <DialogActions
                    sx={{
                        pt: 2,
                        pb: 2,
                        pr: 3,
                        backgroundColor: '#fdfdfd',
                        borderTop: '1px solid #e0e0e0',
                    }}
                >
                    <Button
                        onClick={() => setIsModalOpen(false)}
                        variant="outlined"
                        sx={{
                            borderColor: '#d5dbdb',
                            color: '#232f3e',
                            '&:hover': { backgroundColor: '#f0f2f2' },
                        }}
                    >
                        Close
                    </Button>
                </DialogActions>
            </Dialog>
        </Container>
    )
}

export default FairnessDashboard
