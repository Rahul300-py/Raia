import {
    BrowserRouter as Router,
    Routes,
    Route,
    useLocation,
} from 'react-router-dom'
import LandingPage from './pages/LandingPage'
import LoginPage from './pages/LoginPage'
import HomePage from './pages/HomePage'
import SignupPage from './pages/SignupPage'
import NewAnalysis from './pages/NewAnalysis'
import ModelEvaluationTabs from './pages/ModelEvaluationDashboard'
import Header from './components/Header'
import DashboardNavBar from './components/DashboardNavbar'
import XAIDashboardPage from './pages/XAIDashboardPage'

function AppContent() {
    const location = useLocation()
    const PrivateHeader = [
        '/dashboard',
        '/new-analysis',
        '/home',
        '/demo',
    ].includes(location.pathname)
    const PublicHeader = ['/'].includes(location.pathname)

    return (
        <>
            {PrivateHeader && <DashboardNavBar />}
            {PublicHeader && <Header />}
            <Routes>
                <Route path="/" element={<LandingPage />} />
                <Route path="/login" element={<LoginPage />} />
                <Route path="/dashboard" element={<XAIDashboardPage />} />
                <Route path="/demo" element={<ModelEvaluationTabs />} />
                <Route path="/new-analysis" element={<NewAnalysis />} />
                <Route path="/signup" element={<SignupPage />} />
                <Route path="/home" element={<HomePage />} />
                <Route path="*" element={<h2>404 - Not Found</h2>} />
            </Routes>
        </>
    )
}

function App() {
    return (
        <Router>
            <AppContent />
        </Router>
    )
}

export default App
