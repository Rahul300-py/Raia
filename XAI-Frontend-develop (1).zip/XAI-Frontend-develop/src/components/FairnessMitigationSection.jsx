import React from 'react'
import {
    Box,
    Typography,
    Paper,
    Grid,
    Container,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import BalanceIcon from '@mui/icons-material/Balance'
import SecurityIcon from '@mui/icons-material/Security'

const explainabilityFeatures = [
    {
        icon: <BalanceIcon />,
        title: 'Bias Detection',
        subtitle: 'Identify and quantify bias across protected attributes',
        points: [
            'Demographic parity analysis',
            'Equalized odds assessment',
            'Individual fairness metrics',
            'Intersectional bias detection',
        ],
    },
    {
        icon: <SecurityIcon />,
        title: 'Bias Mitigation',
        subtitle: 'Active strategies to reduce and eliminate bias',
        points: [
            'Pre-processing debiasing',
            'In-processing fairness constraints',
            'Post-processing calibration',
            'Adversarial debiasing',
        ],
    },
]

const FairnessMitigationSection = () => {
    return (
        <Box
            sx={{
                color: '#fff',
                py: 8,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="h3"
                    sx={{
                        color: '#B4A3FF',
                        fontWeight: 700,
                        mb: 2,
                        textAlign: 'center',
                    }}
                >
                    AI Fairness & Bias Mitigation
                </Typography>
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'center',
                        maxWidth: '600px',
                        mx: 'auto',
                    }}
                >
                    AI Fairness & Bias Mitigation
                </Typography>

                <Grid container spacing={4}>
                    {explainabilityFeatures.map((feature, index) => (
                        <Grid item xs={12} sm={6} md={4} key={index}>
                            <Paper
                                elevation={0}
                                sx={{
                                    // backgroundColor: '#111827',
                                    border: '1px solid rgb(158, 180, 211)',
                                    borderRadius: '16px',
                                    p: 4,
                                    height: '100%',
                                    maxWidth: '450px',
                                    cursor: 'pointer',
                                    transition: 'all 0.3s ease',
                                    '&:hover': {
                                        boxShadow:
                                            '0 6px 20px rgba(0,0,0,0.08)',
                                        transform: 'translateY(-3px)',
                                    },
                                }}
                            >
                                {/* <Box
                                    sx={{
                                        background:
                                            'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
                                        borderRadius: '12px',
                                        width: 50,
                                        height: 50,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        fontSize: '26px',
                                        mb: 2,
                                    }}
                                >
                                    {feature.icon}
                                </Box> */}
                                <Typography
                                    variant="h6"
                                    sx={{
                                        fontWeight: 700,

                                        mb: 1,
                                    }}
                                >
                                    {feature.icon} {feature.title}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        mb: 2,
                                    }}
                                >
                                    {feature.subtitle}
                                </Typography>

                                <List dense>
                                    {feature.points.map((point, i) => (
                                        <ListItem key={i} disableGutters>
                                            <ListItemIcon
                                                sx={{
                                                    minWidth: '30px',
                                                    color: '#22C55E',
                                                }}
                                            >
                                                <CheckCircleIcon fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText primary={point} />
                                        </ListItem>
                                    ))}
                                </List>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>
            </Container>
        </Box>
    )
}

export default FairnessMitigationSection
