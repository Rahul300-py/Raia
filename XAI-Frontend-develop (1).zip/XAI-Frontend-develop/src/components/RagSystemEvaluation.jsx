import React from 'react'
import {
    Box,
    Container,
    Grid,
    Paper,
    Typography,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'
import StorageIcon from '@mui/icons-material/Storage'
import LinkIcon from '@mui/icons-material/Link'
import AssessmentIcon from '@mui/icons-material/Assessment'
import SecurityIcon from '@mui/icons-material/Security'

const ragSections = [
    {
        title: 'Retrieval Quality Assessment',
        icon: <StorageIcon />,
        description: 'Evaluate the effectiveness of your retrieval pipeline',
        items: [
            ['Relevance@K', 'Top-K retrieval accuracy measurement'],
            ['Mean Reciprocal Rank (MRR)', 'Ranking quality assessment'],
            ['Coverage Analysis', 'Knowledge base utilization metrics'],
            ['Latency Profiling', 'Retrieval speed optimization'],
            ['Embedding Quality', 'Semantic similarity validation'],
        ],
    },
    {
        title: 'Context Integration',
        icon: <LinkIcon />,
        description: 'Measure how well LLMs utilize retrieved information',
        items: [
            ['Context Utilization Rate', 'Percentage of relevant context used'],
            ['Faithfulness Score', 'Answer grounding in retrieved documents'],
            ['Context Relevance', 'Precision of retrieved information'],
            ['Answer Attribution', 'Source-claim alignment verification'],
            [
                'Contradiction Detection',
                'Identify conflicting information handling',
            ],
        ],
    },
    {
        title: 'End-to-End RAG Metrics',
        icon: <AssessmentIcon />,
        description: 'Holistic evaluation of RAG system performance',
        items: [
            ['Answer Correctness', 'Factual accuracy with source verification'],
            ['Response Completeness', 'Information coverage assessment'],
            ['Noise Robustness', 'Performance with irrelevant retrievals'],
            ['Query Understanding', 'Intent recognition accuracy'],
            ['Hybrid Scoring', 'Combined retrieval and generation quality'],
        ],
    },
    {
        title: 'RAG Optimization Tools',
        icon: <SecurityIcon />,
        description: 'Advanced tools for improving RAG system performance',
        items: [
            ['Chunk Size Optimization', 'Automatic context window tuning'],
            ['Reranking Strategies', 'Multi-stage retrieval enhancement'],
            ['Query Expansion', 'Automatic query reformulation'],
            ['Index Quality', 'Vector database optimization'],
            ['A/B Testing Framework', 'Compare RAG configurations'],
        ],
    },
]
const RagSystemEvaluation = () => {
    return (
        <Box
            sx={{
                color: '#fff',
                py: 8,
            }}
        >
            <Container maxWidth="lg">
                <Typography
                    variant="subtitle1"
                    sx={{
                        color: 'rgba(0, 0, 0, 0.7)',
                        mb: 5,
                        textAlign: 'left',
                        maxWidth: '600px',
                    }}
                >
                    🔍 RAG System Evaluation
                </Typography>

                {/*  Large Language Model Evaluation */}
                <Grid container spacing={3}>
                    {ragSections.map((section, idx) => (
                        <Grid item xs={12} md={4} key={idx}>
                            <Paper
                                elevation={0}
                                sx={{
                                    border: '1px solid rgb(16, 17, 17)',
                                    borderRadius: '16px',
                                    p: 3,
                                    height: '100%',
                                    maxWidth: '360px',
                                }}
                            >
                                <Box
                                    sx={{
                                        display: 'flex',
                                        alignItems: 'center',
                                        gap: 1,
                                        mb: 2,
                                    }}
                                >
                                    <Box
                                        sx={{
                                            background:
                                                'linear-gradient(135deg, #8B5CF6, #6366F1)',
                                            borderRadius: '10px',
                                            p: 1,
                                            display: 'flex',
                                        }}
                                    >
                                        {section.icon}
                                    </Box>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{ fontWeight: 700 }}
                                    >
                                        {section.title}
                                    </Typography>
                                </Box>
                                <Typography
                                    variant="body2"
                                    sx={{
                                        mb: 2,
                                    }}
                                >
                                    {section.description}
                                </Typography>
                                <List dense>
                                    {section.items.map(([label, text], i) => (
                                        <ListItem key={i} disableGutters>
                                            <ListItemIcon
                                                sx={{
                                                    minWidth: '30px',
                                                }}
                                            >
                                                <CheckCircleIcon fontSize="small" />
                                            </ListItemIcon>
                                            <ListItemText
                                                primary={
                                                    <Box component="span">
                                                        <Typography
                                                            component="span"
                                                            sx={{
                                                                fontWeight: 600,
                                                            }}
                                                        >
                                                            {label}:{' '}
                                                        </Typography>
                                                        <Typography
                                                            component="span"
                                                            sx={{}}
                                                        >
                                                            {text}
                                                        </Typography>
                                                    </Box>
                                                }
                                            />
                                        </ListItem>
                                    ))}
                                </List>
                            </Paper>
                        </Grid>
                    ))}
                </Grid>

                {/* RAG System Evaluation */}
            </Container>
        </Box>
    )
}

export default RagSystemEvaluation
