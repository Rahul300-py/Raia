import React, { useState } from 'react'
import {
    Box,
    Container,
    Typography,
    Paper,
    Tabs,
    Tab,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'

const tabContent = [
    {
        label: 'Hallucination Detection',
        title: 'Hallucination Detection Framework',
        description:
            'Our state-of-the-art hallucination detection system employs multiple strategies:',
        items: [
            'Self-Consistency Checking: Generate multiple responses and check for contradictions',
            'Claim Verification: Extract claims and verify against trusted knowledge bases',
            'Uncertainty Quantification: Measure model confidence in generated content',
            'Attention Analysis: Examine attention patterns for unsupported claims',
            'Real-time Scoring: Provide hallucination risk scores for each response',
        ],
        output: {
            heading: 'Example Output',
            fields: [
                'Hallucination Score: 0.15 (Low Risk)',
                'Factual Accuracy: 94%',
                'Unsupported Claims: 2 detected',
                'Recommendation: Review claims about "quantum computing applications"',
            ],
        },
    },
    {
        label: 'RAG Evaluation',
        title: 'Retrieval-Augmented Generation Evaluation',
        description:
            'Evaluate grounding quality between retrieved context and generated response:',
        items: [
            'Context Relevance Scoring',
            'Context-Response Alignment Analysis',
            'Claim-to-Context Grounding',
            'Reference Coverage Measurement',
            'Real-time Feedback Integration',
        ],
        output: {
            heading: 'RAG Performance Metrics',
            fields: [
                'Retrieval Accuracy: 89.3%',
                'Context Utilization: 76%',
                'Answer Faithfulness: 92%',
                'Average Latency: 287ms',
                'Recommendation: Optimize embedding model for better retrieval',
            ],
        },
    },
    {
        label: 'Safety Analysis',
        title: 'Model Safety and Toxicity Evaluation',
        description:
            'Ensure generated content adheres to ethical and safety standards:',
        items: [
            'Toxicity and Bias Detection',
            'Profanity and Hate Speech Filtering',
            'Sensitive Topic Identification',
            'Adversarial Prompt Resistance Testing',
            'Red-teaming Simulation Analysis',
        ],
        output: {
            heading: 'Safety Assessment',
            fields: [
                'Overall Safety Score: 96/100',
                'Toxicity Level: Minimal (0.02)',
                'Bias Detection: Low risk',
                'Security Vulnerabilities: None detected',
                'Status: ✓ Safe for production deployment',
            ],
        },
    },
    {
        label: 'Benchmark Suite',
        title: 'Benchmarking with Standard Datasets',
        description:
            'Evaluate model performance across industry-standard benchmarks:',
        items: [
            'OpenQA (Natural Questions, TriviaQA)',
            'Summarization (CNN/DM, XSum)',
            'Commonsense (PIQA, Social IQa)',
            'Reasoning (ARC, GSM8K)',
            'Conversational Benchmarks (CoQA, MultiWOZ)',
        ],
        output: {
            heading: 'Benchmark Results',
            fields: [
                'MMLU Score: 87.3% (Top 5%)',
                'HumanEval Pass@1: 74.2%',
                'GSM8K Accuracy: 91.5%',
                'Average Reasoning: 85.7%',
                'Comparison: Outperforms GPT-3.5 on 8/10 benchmarks',
            ],
        },
    },
]

const InteractiveEvaluation = () => {
    const [activeTab, setActiveTab] = useState(0)

    const current = tabContent[activeTab]

    return (
        <Box sx={{ mt: 3, mb: 3 }}>
            <Container maxWidth="lg">
                <Typography
                    variant="h5"
                    sx={{
                        mb: 5,
                        textAlign: 'left',
                        mx: 'auto',
                    }}
                >
                    Interactive Evaluation Demo
                </Typography>

                <Tabs
                    value={activeTab}
                    onChange={(e, newValue) => setActiveTab(newValue)}
                    textColor="inherit"
                    indicatorColor="secondary"
                    sx={{
                        mb: 3,
                        '& .MuiTab-root': {
                            color: '#000',
                            textTransform: 'none',
                            fontWeight: 600,
                            borderRadius: '8px',
                            minWidth: '130px',
                        },
                        '& .Mui-selected': {
                            background:
                                'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
                            color: 'white',
                        },
                    }}
                >
                    {tabContent.map((tab, index) => (
                        <Tab key={index} label={tab.label} />
                    ))}
                </Tabs>

                <Paper
                    elevation={0}
                    sx={{
                        border: '1px solid #1F2937',
                        borderRadius: '16px',
                        p: 2,
                        mt: 1,
                    }}
                >
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
                        {current.title}
                    </Typography>
                    <Typography variant="body2" sx={{ mb: 2 }}>
                        {current.description}
                    </Typography>

                    <List dense>
                        {current.items.map((item, i) => (
                            <ListItem key={i} disableGutters>
                                <ListItemIcon
                                    sx={{
                                        minWidth: '30px',
                                    }}
                                >
                                    <CheckCircleIcon fontSize="small" />
                                </ListItemIcon>
                                <ListItemText primary={item} />
                            </ListItem>
                        ))}
                    </List>
                    {current.output && (
                        <Box
                            sx={{
                                p: 2,
                                borderRadius: '10px',
                                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                            }}
                        >
                            <Typography variant="subtitle1" fontWeight={600}>
                                {current.output.heading}
                            </Typography>
                            <List dense>
                                {current.output.fields.map((line, i) => (
                                    <ListItem key={i} sx={{ py: 0 }}>
                                        <ListItemText primary={line} />
                                    </ListItem>
                                ))}
                            </List>
                        </Box>
                    )}
                </Paper>
            </Container>
        </Box>
    )
}

export default InteractiveEvaluation
