/* eslint-disable no-unused-vars */
import * as React from 'react'
import { styled, alpha } from '@mui/material/styles'
import AppBar from '@mui/material/AppBar'
import Box from '@mui/material/Box'
import Toolbar from '@mui/material/Toolbar'
import IconButton from '@mui/material/IconButton'
import Typography from '@mui/material/Typography'
import InputBase from '@mui/material/InputBase'
import MenuItem from '@mui/material/MenuItem'
import Menu from '@mui/material/Menu'
import AccountCircle from '@mui/icons-material/AccountCircle'
import MoreIcon from '@mui/icons-material/MoreVert'
import SearchIcon from '@mui/icons-material/Search'
import SettingsIcon from '@mui/icons-material/Settings'
import { useNavigate } from 'react-router-dom'
import { useState } from 'react'
import { Button, Drawer, TextField } from '@mui/material'
import ChatIcon from '@mui/icons-material/Chat'
import CloseIcon from '@mui/icons-material/Close'
const logoSrc = '/logo-nav.png' // Adjust path if using assets folder and import

const Search = styled('div')(({ theme }) => ({
    position: 'relative',
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha('#ebedf3', 0.75),
    '&:hover': {
        backgroundColor: alpha('#ebedf3', 1),
    },
    marginRight: theme.spacing(2),
    marginLeft: theme.spacing(2),
    width: '100%',
    maxWidth: 300,
    [theme.breakpoints.up('sm')]: {
        width: 'auto',
    },
}))

const SearchIconWrapper = styled('div')(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: '100%',
    position: 'absolute',
    pointerEvents: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
}))

const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: 'inherit',
    '& .MuiInputBase-input': {
        padding: theme.spacing(1, 1, 1, 0),
        paddingLeft: `calc(1em + ${theme.spacing(4)})`,
        transition: theme.transitions.create('width'),
        width: '100%',
    },
}))

export default function DashboardNavBar() {
    const [anchorEl, setAnchorEl] = React.useState(null)
    const [mobileMoreAnchorEl, setMobileMoreAnchorEl] = React.useState(null)
    const navigate = useNavigate()
    const [chatMessages, setChatMessages] = useState([])
    const [chatInput, setChatInput] = useState('')
    const [showChatBot, setShowChatBot] = useState(false)
    const isMenuOpen = Boolean(anchorEl)
    const isMobileMenuOpen = Boolean(mobileMoreAnchorEl)

    const handleProfileMenuOpen = (event) => setAnchorEl(event.currentTarget)
    const handleMobileMenuClose = () => setMobileMoreAnchorEl(null)
    const handleMenuClose = () => {
        setAnchorEl(null)
        handleMobileMenuClose()
    }
    const handleMobileMenuOpen = (event) =>
        setMobileMoreAnchorEl(event.currentTarget)
    const goBack = () => navigate('/')

    const menuId = 'primary-search-account-menu'
    const renderMenu = (
        <Menu
            anchorEl={anchorEl}
            anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            id={menuId}
            keepMounted
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            open={isMenuOpen}
            onClose={handleMenuClose}
        >
            <MenuItem onClick={handleMenuClose}>Profile</MenuItem>
            <MenuItem onClick={handleMenuClose}>My account</MenuItem>
        </Menu>
    )

    const mobileMenuId = 'primary-search-account-menu-mobile'
    const renderMobileMenu = (
        <Menu
            anchorEl={mobileMoreAnchorEl}
            anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
            id={mobileMenuId}
            keepMounted
            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
            open={isMobileMenuOpen}
            onClose={handleMobileMenuClose}
        >
            <MenuItem onClick={handleProfileMenuOpen}>
                <IconButton size="large" color="inherit">
                    <AccountCircle />
                </IconButton>
                <p>Profile</p>
            </MenuItem>
            <MenuItem>
                <IconButton size="large" color="inherit">
                    <SettingsIcon />
                </IconButton>
                <p>Settings</p>
            </MenuItem>
        </Menu>
    )

    return (
        <Box sx={{ flexGrow: 1 }}>
            <AppBar
                position="static"
                elevation={0}
                sx={{ backgroundColor: '#fff', color: '#000' }}
            >
                <Toolbar sx={{ justifyContent: 'space-between' }}>
                    <img
                        onClick={goBack}
                        src={logoSrc}
                        alt="XAI Logo"
                        style={{
                            width: '100px',
                            marginRight: '10px',
                            cursor: 'pointer',
                        }}
                    />
                    {/* <Typography
                        onClick={goBack}
                        variant="h6"
                        noWrap
                        sx={{
                            display: { xs: 'none', sm: 'block' },
                            cursor: 'pointer',
                            fontWeight: 600,
                        }}
                    >
                        XAI
                    </Typography> */}

                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Search>
                            <SearchIconWrapper>
                                <SearchIcon />
                            </SearchIconWrapper>
                            <StyledInputBase
                                placeholder="Search…"
                                inputProps={{ 'aria-label': 'search' }}
                            />
                        </Search>

                        <IconButton size="large" color="inherit">
                            <SettingsIcon />
                        </IconButton>

                        <IconButton
                            size="large"
                            edge="end"
                            color="inherit"
                            aria-controls={menuId}
                            aria-haspopup="true"
                            onClick={handleProfileMenuOpen}
                        >
                            <AccountCircle />
                        </IconButton>
                        {/* <Box
                            onClick={() => setShowChatBot(true)}
                            sx={{
                                position: 'fixed',
                                bottom: 20,
                                right: 20,
                                display: 'flex',
                                flexDirection: 'row',
                                alignItems: 'center',
                                bgcolor: '#1976d2',
                                borderRadius: 2,
                                padding: '2px 10px 2px 10px',
                                cursor: 'pointer',
                            }}
                        >
                            <Typography sx={{ color: '#fff' }}>
                                Explain with AI
                            </Typography>
                            <IconButton
                                sx={{
                                    bgcolor: '#1976d2',
                                    color: 'white',
                                    '&:hover': { bgcolor: '#115293' },
                                    zIndex: 1000,
                                }}
                                aria-label="open chat"
                            >
                                <ChatIcon />
                            </IconButton>
                        </Box> */}
                        <Box sx={{ display: { xs: 'flex', md: 'none' } }}>
                            <IconButton
                                size="large"
                                aria-label="show more"
                                aria-controls={mobileMenuId}
                                aria-haspopup="true"
                                onClick={handleMobileMenuOpen}
                                color="inherit"
                            >
                                <MoreIcon />
                            </IconButton>
                        </Box>
                    </Box>
                </Toolbar>
            </AppBar>
            {renderMobileMenu}
            {renderMenu}
            {showChatBot && (
                <Drawer
                    variant="permanent"
                    anchor="right"
                    sx={{
                        width: showChatBot ? 500 : 0,
                        flexShrink: 0,
                        whiteSpace: 'nowrap',
                        transition: 'width 0.3s',
                        [`& .MuiDrawer-paper`]: {
                            width: showChatBot ? 500 : 0,
                            transition: 'width 0.3s',
                            overflowX: 'hidden',
                            boxSizing: 'border-box',
                            color: '#000',
                            bgcolor: '#f0f0f0',
                        },
                    }}
                >
                    {' '}
                    <Box
                        sx={{
                            p: 2,
                            bgcolor: '#1976d2',
                            color: 'white',
                            display: 'flex',
                            justifyContent: 'space-between',
                            alignItems: 'center',
                        }}
                    >
                        <Typography variant="h6">XAI Companion</Typography>
                        <IconButton
                            onClick={() => setShowChatBot(false)}
                            sx={{ color: 'white' }}
                        >
                            <CloseIcon />
                        </IconButton>
                    </Box>
                    <Box
                        sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            gap: 2,
                            mt: 1,
                            height: 'calc(100% - 80px)',
                            mb: 1,
                        }}
                    >
                        <Box
                            sx={{
                                borderRadius: 2,
                                p: 2,
                                height: '100%',
                                overflowY: 'auto',
                                width: '100%',
                            }}
                        >
                            {chatMessages.map((msg, i) => (
                                <Box
                                    key={i}
                                    sx={{
                                        textAlign:
                                            msg.sender === 'user'
                                                ? 'right'
                                                : 'left',
                                        mb: 1,
                                    }}
                                >
                                    <Box
                                        sx={{
                                            display: 'inline-block',
                                            px: 2,
                                            py: 1,
                                            borderRadius: 2,
                                            bgcolor:
                                                msg.sender === 'user'
                                                    ? '#1976d2'
                                                    : '#eee',
                                            color:
                                                msg.sender === 'user'
                                                    ? '#fff'
                                                    : '#333',
                                            maxWidth: '80%', // ✅ changed from 'fit-content'
                                            wordWrap: 'break-word', // ✅ added
                                            overflowWrap: 'break-word', // ✅ added
                                            whiteSpace: 'pre-wrap', // ✅ to preserve line breaks
                                        }}
                                    >
                                        {msg.text}
                                    </Box>
                                </Box>
                            ))}
                        </Box>
                    </Box>
                    <Box
                        sx={{
                            display: 'flex',
                            gap: 1,
                            width: '100%',
                            minWidth: '500px',
                            p: 1, // ✅ added some padding
                        }}
                    >
                        <TextField
                            placeholder="Describe the role you want..."
                            fullWidth
                            size="medium"
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            // onKeyDown={(e) => {
                            //     if (e.key === 'Enter') handleAIMessageSend()
                            // }}
                        />
                        <Button
                            sx={{ mr: '10px' }}
                            variant="contained"
                            size="medium"
                            // onClick={handleAIMessageSend}
                        >
                            Send
                        </Button>
                    </Box>
                </Drawer>
            )}
        </Box>
    )
}
