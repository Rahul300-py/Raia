import React, { useState } from 'react'
import {
    Box,
    Container,
    Typography,
    Paper,
    Tabs,
    Tab,
    List,
    ListItem,
    ListItemIcon,
    ListItemText,
} from '@mui/material'
import CheckCircleIcon from '@mui/icons-material/CheckCircle'

const tabContent = [
    {
        label: 'Data Drift',
        items: [
            'Feature distribution changes over time',
            'Covariate shift detection using KS and Chi-square tests',
            'Multivariate drift analysis with MMD and Wasserstein distance',
            'Automated alerting with severity levels',
            'Root cause analysis for drift sources',
        ],
    },
    {
        label: 'Model Drift',
        items: [
            'Prediction performance degradation monitoring',
            'Concept drift detection using PSI and KL divergence',
            'Class-wise and global drift tracking',
            'Dynamic model retraining triggers',
            'Version comparison dashboards',
        ],
    },
    {
        label: 'Performance Monitoring',
        items: [
            'Real-time latency and throughput monitoring',
            'Error rate and exception tracking',
            'Service health and uptime reports',
            'Customizable alert thresholds',
            'End-to-end operational metrics',
        ],
    },
]

const RealTimeMonitoringSection = () => {
    const [activeTab, setActiveTab] = useState(0)

    return (
        <Box sx={{ mt: 3 }}>
            <Container maxWidth="lg">
                <Typography
                    variant="h4"
                    sx={{
                        color: '#B4A3FF',
                        fontWeight: 700,
                        mb: 2,
                        textAlign: 'center',
                    }}
                >
                    Real-Time Monitoring & Drift Detection
                </Typography>
                <Typography
                    variant="subtitle1"
                    sx={{
                        mb: 5,
                        textAlign: 'center',
                        maxWidth: '650px',
                        mx: 'auto',
                    }}
                >
                    Stay ahead of model degradation with intelligent monitoring
                </Typography>

                <Tabs
                    value={activeTab}
                    onChange={(e, newValue) => setActiveTab(newValue)}
                    textColor="inherit"
                    indicatorColor="secondary"
                    sx={{
                        mb: 3,
                        '& .MuiTab-root': {
                            color: '#000',
                            textTransform: 'none',
                            fontWeight: 600,
                            borderRadius: '8px',
                            minWidth: '130px',
                        },
                        '& .Mui-selected': {
                            background:
                                'linear-gradient(135deg, #6366F1 0%, #8B5CF6 100%)',
                            color: 'white',
                        },
                    }}
                >
                    {tabContent.map((tab, index) => (
                        <Tab key={index} label={tab.label} />
                    ))}
                </Tabs>

                <Paper
                    elevation={0}
                    sx={{
                        border: '1px solid #1F2937',
                        borderRadius: '16px',
                        p: 4,
                        mt: 2,
                    }}
                >
                    <Typography variant="h6" sx={{ fontWeight: 700, mb: 2 }}>
                        {tabContent[activeTab].label} Detection
                    </Typography>
                    <Typography variant="body2">
                        Our advanced {tabContent[activeTab].label.toLowerCase()}{' '}
                        detection system continuously monitors:
                    </Typography>

                    <List dense>
                        {tabContent[activeTab].items.map((item, i) => (
                            <ListItem key={i} disableGutters>
                                <ListItemIcon sx={{ minWidth: '30px' }}>
                                    <CheckCircleIcon fontSize="small" />
                                </ListItemIcon>
                                <ListItemText primary={item} />
                            </ListItem>
                        ))}
                    </List>
                </Paper>
            </Container>
        </Box>
    )
}

export default RealTimeMonitoringSection
