import React from 'react'
import {
    Box,
    Typography,
    Button,
    Container,
    Card,
    CardContent,
    CardMedia,
    Stack,
} from '@mui/material'

const projects = [
    {
        title: 'Survival Prediction',
        description: 'Predicting survival on the Titanic',
        image: 'https://via.placeholder.com/140x100?text=Chart+1',
        link: '/dashboard',
        banner: 'https://static.vecteezy.com/system/resources/thumbnails/000/701/690/small/abstract-polygonal-banner-background.jpg',
    },
    {
        title: 'Fraud Detection in Transactions',
        description:
            'Dataset: Transaction records with features like amount, time, and location',
        image: 'https://via.placeholder.com/140x100?text=Chart+2',
        link: '/dashboard',
        banner: 'https://img.freepik.com/free-vector/half-tone-blue-abstract-background-with-text-space_1017-41428.jpg?semt=ais_hybrid&w=740',
    },
    {
        title: 'Medical Diagnosis Assistant',
        description:
            'Dataset: Patient health records with symptoms and diagnostic outcomes',
        image: 'https://via.placeholder.com/140x100?text=Chart+3',
        link: '/dashboard',
        banner: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRRmROKpsU7zzS5NbbfOTdAQbADSBQgk_gYGw&s',
    },
]

function HomePage() {
    return (
        <Box>
            <Container maxWidth="md" sx={{ mt: 6 }}>
                {/* Top Banner (Centered Card) */}

                <Card
                    sx={{
                        borderRadius: 4,
                        background:
                            'linear-gradient(to right, #9CA38F, #646A57)',
                        color: 'white',
                        p: { xs: 4, sm: 6 },
                        mb: 6,
                    }}
                >
                    <Typography
                        variant="h4"
                        sx={{ fontWeight: 'bold' }}
                        gutterBottom
                    >
                        Welcome back, Abhishek!
                    </Typography>
                    <Typography variant="body1" sx={{ maxWidth: 500 }}>
                        Dive back into your projects or start a new analysis to
                        uncover insights from your data.
                    </Typography>
                    <Button
                        variant="contained"
                        sx={{
                            mt: 3,
                            bgcolor: '#dae4ef',
                            color: '#000',
                            fontWeight: 'bold',
                            '&:hover': { bgcolor: '#cbd8e2' },
                        }}
                        href="/new-analysis"
                    >
                        Start New Analysis
                    </Button>
                </Card>

                {/* Recent Projects */}
                <Typography
                    variant="h6"
                    gutterBottom
                    sx={{ fontWeight: 'bold' }}
                >
                    Recent Projects
                </Typography>
                <Stack spacing={3} mt={2}>
                    {projects.map((project, index) => (
                        <Card
                            key={index}
                            elevation={0}
                            sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                p: 2,
                            }}
                        >
                            <Box>
                                <Typography
                                    variant="subtitle1"
                                    sx={{ fontWeight: 'medium' }}
                                >
                                    {project.title}
                                </Typography>
                                <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{ mt: 0.5 }}
                                >
                                    {project.description}
                                </Typography>
                                <Button
                                    variant="outlined"
                                    size="small"
                                    sx={{
                                        mt: 1,
                                        bgcolor: '#dae4ef',
                                        color: '#000',
                                        textTransform: 'none',
                                    }}
                                    href={project.link}
                                >
                                    View Project
                                </Button>
                            </Box>
                            <CardMedia
                                component="img"
                                image={project.banner}
                                alt={project.title}
                                sx={{
                                    width: 140,
                                    height: 100,
                                    borderRadius: 2,
                                    objectFit: 'cover',
                                }}
                            />
                        </Card>
                    ))}
                </Stack>
            </Container>
        </Box>
    )
}

export default HomePage
