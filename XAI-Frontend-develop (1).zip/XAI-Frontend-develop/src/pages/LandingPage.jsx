// src/App.js
import React from 'react'
import { Box } from '@mui/material'
import Header from '../components/Header'
import HeroSection from '../components/HeroSection'
import ContentPreviewSection from '../components/ContentPreviewSection'
import StatsSection from '../components/StatsSection'
import WhyAIFailsSection from '../components/WhyAIFailsSection'
import LLMEvaluationPlatformSection from '../components/LLMEvaluationPlatformSection'
import LLMEvalsSection from '../components/LLMEvalsSection'
import UseCasesSection from '../components/UseCasesSection'
import TestimonialsSection from '../components/TestimonialsSection'
import Footer from '../components/Footer'
import { Link } from 'react-router-dom'
import ExplainabilitySuiteSection from '../components/ExplainabilitySuiteSection'
import ComprehensiveModelEvalute from '../components/comprehensiveModelEvalute'
import RealTimeMonitoringSection from '../components/RealTimeMonitoringSection'
import RagEvaluationFramework from '../components/ragEvauationFramework'
import RagSystemEvaluation from '../components/RagSystemEvaluation'
import SupportedLLMFramework from '../components/SupportedLLMFramework'
import InteractiveEvaluation from '../components/InteractiveEvaluation'
import FairnessMitigationSection from '../components/FairnessMitigationSection'

function LandingPage() {
    return (
        <Box
            sx={{
                fontFamily: '"Inter", sans-serif',
                minHeight: '100vh',
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                backgroundColor: '#fff',
                overflowX: 'hidden',
                width: '100%',
            }}
        >
            {/* Top Banner (from first screenshot) */}

            {/* <Header /> */}
            <Box
                sx={{
                    background:
                        'radial-gradient(ellipse at center, rgba(230,247,250,1) 0%, rgba(240,230,250,1) 50%, rgba(255,255,255,0) 100%)',
                    backgroundSize: 'contain',
                    backgroundRepeat: 'no-repeat',
                    width: '100%',
                }}
            >
                {' '}
                <HeroSection />
                <ContentPreviewSection />
            </Box>
            <ExplainabilitySuiteSection />
            <ComprehensiveModelEvalute />
            <Box
                sx={{
                    background:
                        'radial-gradient(ellipse at center, rgba(230,247,250,1) 0%, rgba(240,230,250,1) 50%, rgba(255,255,255,0) 100%)',
                    backgroundSize: 'contain',
                    backgroundRepeat: 'no-repeat',
                    width: '100%',
                }}
            >
                <RealTimeMonitoringSection />
                <RagEvaluationFramework />
                <RagSystemEvaluation />
                <SupportedLLMFramework />

                <InteractiveEvaluation />
            </Box>
            <FairnessMitigationSection />
            <StatsSection />
            <WhyAIFailsSection />
            <LLMEvaluationPlatformSection />
            <LLMEvalsSection />
            <UseCasesSection />
            <TestimonialsSection />
            <Footer />
        </Box>
    )
}

export default LandingPage
